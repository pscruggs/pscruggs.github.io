webpackJsonp([29],{

/***/ 261:
/***/ (function(module, exports) {

module.exports = "/clear-vue-laravel/public/fonts/Simple-Line-Icons.eot?f33df365d6d0255b586f2920355e94d7";

/***/ }),

/***/ 281:
/***/ (function(module, exports) {

module.exports = "/clear-vue-laravel/public/fonts/Simple-Line-Icons.svg?2fe2efe63441d830b1acd106c1fe8734";

/***/ }),

/***/ 282:
/***/ (function(module, exports) {

module.exports = "/clear-vue-laravel/public/fonts/Simple-Line-Icons.ttf?d2285965fe34b05465047401b8595dd0";

/***/ }),

/***/ 283:
/***/ (function(module, exports) {

module.exports = "/clear-vue-laravel/public/fonts/Simple-Line-Icons.woff2?0cb0b9c589c0624c9c78dd3d83e946f6";

/***/ }),

/***/ 284:
/***/ (function(module, exports) {

module.exports = "/clear-vue-laravel/public/fonts/Simple-Line-Icons.woff?78f07e2c2a535c26ef21d95e41bd7175";

/***/ }),

/***/ 380:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
    name: "font_icons", // Name is optional, When name isn’t specified use the filename as the component name.
    mounted: function mounted() {},
    destroyed: function destroyed() {}
});

/***/ }),

/***/ 547:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)();
exports.push([module.i, "\n.icon_set > .row > div {\n    font-size : 18px;\n    padding   : 20px 15px;\n}\n.icon_group {\n    position         : relative;\n    background-color : #ffffff;\n}\n.icon_set,\n.icon_cover {\n    height : 330px;\n    width  : 100%;\n}\n.right-side.strech .icon_set ul li {\n    padding : 20px 35px;\n}\n.icon_cover a {\n    position  : relative;\n    top       : 50%;\n    -webkit-transform : translateY(-50%);\n            transform : translateY(-50%);\n}\n.iconset_name {\n    padding-left : 15px;\n}\n.icon_set {\n    color : #6699cc;\n}\n.icon_set:hover + .icon_cover,\n.icon_cover:hover {\n    -webkit-transform  : scale(1);\n            transform  : scale(1);\n    transition : all 0.5s;\n}\n.icon_cover {\n    position         : absolute;\n    top              : 0;\n    left             : 0;\n    background-color : rgba(79, 193, 233, 0.2);\n    transition       : all 0.5s;\n    -webkit-transform        : scale(0);\n            transform        : scale(0);\n}\n", ""]);

/***/ }),

/***/ 548:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)();
exports.push([module.i, "\n@font-face {\n  font-family: 'simple-line-icons';\n  src: url("+__webpack_require__(261)+");\n  src: url("+__webpack_require__(261)+"#iefix) format('embedded-opentype'), url("+__webpack_require__(283)+") format('woff2'), url("+__webpack_require__(282)+") format('truetype'), url("+__webpack_require__(284)+") format('woff'), url("+__webpack_require__(281)+"#simple-line-icons) format('svg');\n  font-weight: normal;\n  font-style: normal;\n}\n/*\n Use the following CSS code if you want to have a class per icon.\n Instead of a list of all class selectors, you can use the generic [class*=\"icon-\"] selector, but it's slower:\n*/\n.icon-user,\n.icon-people,\n.icon-user-female,\n.icon-user-follow,\n.icon-user-following,\n.icon-user-unfollow,\n.icon-login,\n.icon-logout,\n.icon-emotsmile,\n.icon-phone,\n.icon-call-end,\n.icon-call-in,\n.icon-call-out,\n.icon-map,\n.icon-location-pin,\n.icon-direction,\n.icon-directions,\n.icon-compass,\n.icon-layers,\n.icon-menu,\n.icon-list,\n.icon-options-vertical,\n.icon-options,\n.icon-arrow-down,\n.icon-arrow-left,\n.icon-arrow-right,\n.icon-arrow-up,\n.icon-arrow-up-circle,\n.icon-arrow-left-circle,\n.icon-arrow-right-circle,\n.icon-arrow-down-circle,\n.icon-check,\n.icon-clock,\n.icon-plus,\n.icon-minus,\n.icon-close,\n.icon-event,\n.icon-exclamation,\n.icon-organization,\n.icon-trophy,\n.icon-screen-smartphone,\n.icon-screen-desktop,\n.icon-plane,\n.icon-notebook,\n.icon-mustache,\n.icon-mouse,\n.icon-magnet,\n.icon-energy,\n.icon-disc,\n.icon-cursor,\n.icon-cursor-move,\n.icon-crop,\n.icon-chemistry,\n.icon-speedometer,\n.icon-shield,\n.icon-screen-tablet,\n.icon-magic-wand,\n.icon-hourglass,\n.icon-graduation,\n.icon-ghost,\n.icon-game-controller,\n.icon-fire,\n.icon-eyeglass,\n.icon-envelope-open,\n.icon-envelope-letter,\n.icon-bell,\n.icon-badge,\n.icon-anchor,\n.icon-wallet,\n.icon-vector,\n.icon-speech,\n.icon-puzzle,\n.icon-printer,\n.icon-present,\n.icon-playlist,\n.icon-pin,\n.icon-picture,\n.icon-handbag,\n.icon-globe-alt,\n.icon-globe,\n.icon-folder-alt,\n.icon-folder,\n.icon-film,\n.icon-feed,\n.icon-drop,\n.icon-drawer,\n.icon-docs,\n.icon-doc,\n.icon-diamond,\n.icon-cup,\n.icon-calculator,\n.icon-bubbles,\n.icon-briefcase,\n.icon-book-open,\n.icon-basket-loaded,\n.icon-basket,\n.icon-bag,\n.icon-action-undo,\n.icon-action-redo,\n.icon-wrench,\n.icon-umbrella,\n.icon-trash,\n.icon-tag,\n.icon-support,\n.icon-frame,\n.icon-size-fullscreen,\n.icon-size-actual,\n.icon-shuffle,\n.icon-share-alt,\n.icon-share,\n.icon-rocket,\n.icon-question,\n.icon-pie-chart,\n.icon-pencil,\n.icon-note,\n.icon-loop,\n.icon-home,\n.icon-grid,\n.icon-graph,\n.icon-microphone,\n.icon-music-tone-alt,\n.icon-music-tone,\n.icon-earphones-alt,\n.icon-earphones,\n.icon-equalizer,\n.icon-like,\n.icon-dislike,\n.icon-control-start,\n.icon-control-rewind,\n.icon-control-play,\n.icon-control-pause,\n.icon-control-forward,\n.icon-control-end,\n.icon-volume-1,\n.icon-volume-2,\n.icon-volume-off,\n.icon-calendar,\n.icon-bulb,\n.icon-chart,\n.icon-ban,\n.icon-bubble,\n.icon-camrecorder,\n.icon-camera,\n.icon-cloud-download,\n.icon-cloud-upload,\n.icon-envelope,\n.icon-eye,\n.icon-flag,\n.icon-heart,\n.icon-info,\n.icon-key,\n.icon-link,\n.icon-lock,\n.icon-lock-open,\n.icon-magnifier,\n.icon-magnifier-add,\n.icon-magnifier-remove,\n.icon-paper-clip,\n.icon-paper-plane,\n.icon-power,\n.icon-refresh,\n.icon-reload,\n.icon-settings,\n.icon-star,\n.icon-symbol-female,\n.icon-symbol-male,\n.icon-target,\n.icon-credit-card,\n.icon-paypal,\n.icon-social-tumblr,\n.icon-social-twitter,\n.icon-social-facebook,\n.icon-social-instagram,\n.icon-social-linkedin,\n.icon-social-pinterest,\n.icon-social-github,\n.icon-social-google,\n.icon-social-reddit,\n.icon-social-skype,\n.icon-social-dribbble,\n.icon-social-behance,\n.icon-social-foursqare,\n.icon-social-soundcloud,\n.icon-social-spotify,\n.icon-social-stumbleupon,\n.icon-social-youtube,\n.icon-social-dropbox,\n.icon-social-vkontakte,\n.icon-social-steam {\n  font-family: 'simple-line-icons';\n  speak: none;\n  font-style: normal;\n  font-weight: normal;\n  font-variant: normal;\n  text-transform: none;\n  line-height: 1;\n  /* Better Font Rendering =========== */\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n.icon-user:before {\n  content: \"\\e005\";\n}\n.icon-people:before {\n  content: \"\\e001\";\n}\n.icon-user-female:before {\n  content: \"\\e000\";\n}\n.icon-user-follow:before {\n  content: \"\\e002\";\n}\n.icon-user-following:before {\n  content: \"\\e003\";\n}\n.icon-user-unfollow:before {\n  content: \"\\e004\";\n}\n.icon-login:before {\n  content: \"\\e066\";\n}\n.icon-logout:before {\n  content: \"\\e065\";\n}\n.icon-emotsmile:before {\n  content: \"\\e021\";\n}\n.icon-phone:before {\n  content: \"\\e600\";\n}\n.icon-call-end:before {\n  content: \"\\e048\";\n}\n.icon-call-in:before {\n  content: \"\\e047\";\n}\n.icon-call-out:before {\n  content: \"\\e046\";\n}\n.icon-map:before {\n  content: \"\\e033\";\n}\n.icon-location-pin:before {\n  content: \"\\e096\";\n}\n.icon-direction:before {\n  content: \"\\e042\";\n}\n.icon-directions:before {\n  content: \"\\e041\";\n}\n.icon-compass:before {\n  content: \"\\e045\";\n}\n.icon-layers:before {\n  content: \"\\e034\";\n}\n.icon-menu:before {\n  content: \"\\e601\";\n}\n.icon-list:before {\n  content: \"\\e067\";\n}\n.icon-options-vertical:before {\n  content: \"\\e602\";\n}\n.icon-options:before {\n  content: \"\\e603\";\n}\n.icon-arrow-down:before {\n  content: \"\\e604\";\n}\n.icon-arrow-left:before {\n  content: \"\\e605\";\n}\n.icon-arrow-right:before {\n  content: \"\\e606\";\n}\n.icon-arrow-up:before {\n  content: \"\\e607\";\n}\n.icon-arrow-up-circle:before {\n  content: \"\\e078\";\n}\n.icon-arrow-left-circle:before {\n  content: \"\\e07a\";\n}\n.icon-arrow-right-circle:before {\n  content: \"\\e079\";\n}\n.icon-arrow-down-circle:before {\n  content: \"\\e07b\";\n}\n.icon-check:before {\n  content: \"\\e080\";\n}\n.icon-clock:before {\n  content: \"\\e081\";\n}\n.icon-plus:before {\n  content: \"\\e095\";\n}\n.icon-minus:before {\n  content: \"\\e615\";\n}\n.icon-close:before {\n  content: \"\\e082\";\n}\n.icon-event:before {\n  content: \"\\e619\";\n}\n.icon-exclamation:before {\n  content: \"\\e617\";\n}\n.icon-organization:before {\n  content: \"\\e616\";\n}\n.icon-trophy:before {\n  content: \"\\e006\";\n}\n.icon-screen-smartphone:before {\n  content: \"\\e010\";\n}\n.icon-screen-desktop:before {\n  content: \"\\e011\";\n}\n.icon-plane:before {\n  content: \"\\e012\";\n}\n.icon-notebook:before {\n  content: \"\\e013\";\n}\n.icon-mustache:before {\n  content: \"\\e014\";\n}\n.icon-mouse:before {\n  content: \"\\e015\";\n}\n.icon-magnet:before {\n  content: \"\\e016\";\n}\n.icon-energy:before {\n  content: \"\\e020\";\n}\n.icon-disc:before {\n  content: \"\\e022\";\n}\n.icon-cursor:before {\n  content: \"\\e06e\";\n}\n.icon-cursor-move:before {\n  content: \"\\e023\";\n}\n.icon-crop:before {\n  content: \"\\e024\";\n}\n.icon-chemistry:before {\n  content: \"\\e026\";\n}\n.icon-speedometer:before {\n  content: \"\\e007\";\n}\n.icon-shield:before {\n  content: \"\\e00e\";\n}\n.icon-screen-tablet:before {\n  content: \"\\e00f\";\n}\n.icon-magic-wand:before {\n  content: \"\\e017\";\n}\n.icon-hourglass:before {\n  content: \"\\e018\";\n}\n.icon-graduation:before {\n  content: \"\\e019\";\n}\n.icon-ghost:before {\n  content: \"\\e01a\";\n}\n.icon-game-controller:before {\n  content: \"\\e01b\";\n}\n.icon-fire:before {\n  content: \"\\e01c\";\n}\n.icon-eyeglass:before {\n  content: \"\\e01d\";\n}\n.icon-envelope-open:before {\n  content: \"\\e01e\";\n}\n.icon-envelope-letter:before {\n  content: \"\\e01f\";\n}\n.icon-bell:before {\n  content: \"\\e027\";\n}\n.icon-badge:before {\n  content: \"\\e028\";\n}\n.icon-anchor:before {\n  content: \"\\e029\";\n}\n.icon-wallet:before {\n  content: \"\\e02a\";\n}\n.icon-vector:before {\n  content: \"\\e02b\";\n}\n.icon-speech:before {\n  content: \"\\e02c\";\n}\n.icon-puzzle:before {\n  content: \"\\e02d\";\n}\n.icon-printer:before {\n  content: \"\\e02e\";\n}\n.icon-present:before {\n  content: \"\\e02f\";\n}\n.icon-playlist:before {\n  content: \"\\e030\";\n}\n.icon-pin:before {\n  content: \"\\e031\";\n}\n.icon-picture:before {\n  content: \"\\e032\";\n}\n.icon-handbag:before {\n  content: \"\\e035\";\n}\n.icon-globe-alt:before {\n  content: \"\\e036\";\n}\n.icon-globe:before {\n  content: \"\\e037\";\n}\n.icon-folder-alt:before {\n  content: \"\\e039\";\n}\n.icon-folder:before {\n  content: \"\\e089\";\n}\n.icon-film:before {\n  content: \"\\e03a\";\n}\n.icon-feed:before {\n  content: \"\\e03b\";\n}\n.icon-drop:before {\n  content: \"\\e03e\";\n}\n.icon-drawer:before {\n  content: \"\\e03f\";\n}\n.icon-docs:before {\n  content: \"\\e040\";\n}\n.icon-doc:before {\n  content: \"\\e085\";\n}\n.icon-diamond:before {\n  content: \"\\e043\";\n}\n.icon-cup:before {\n  content: \"\\e044\";\n}\n.icon-calculator:before {\n  content: \"\\e049\";\n}\n.icon-bubbles:before {\n  content: \"\\e04a\";\n}\n.icon-briefcase:before {\n  content: \"\\e04b\";\n}\n.icon-book-open:before {\n  content: \"\\e04c\";\n}\n.icon-basket-loaded:before {\n  content: \"\\e04d\";\n}\n.icon-basket:before {\n  content: \"\\e04e\";\n}\n.icon-bag:before {\n  content: \"\\e04f\";\n}\n.icon-action-undo:before {\n  content: \"\\e050\";\n}\n.icon-action-redo:before {\n  content: \"\\e051\";\n}\n.icon-wrench:before {\n  content: \"\\e052\";\n}\n.icon-umbrella:before {\n  content: \"\\e053\";\n}\n.icon-trash:before {\n  content: \"\\e054\";\n}\n.icon-tag:before {\n  content: \"\\e055\";\n}\n.icon-support:before {\n  content: \"\\e056\";\n}\n.icon-frame:before {\n  content: \"\\e038\";\n}\n.icon-size-fullscreen:before {\n  content: \"\\e057\";\n}\n.icon-size-actual:before {\n  content: \"\\e058\";\n}\n.icon-shuffle:before {\n  content: \"\\e059\";\n}\n.icon-share-alt:before {\n  content: \"\\e05a\";\n}\n.icon-share:before {\n  content: \"\\e05b\";\n}\n.icon-rocket:before {\n  content: \"\\e05c\";\n}\n.icon-question:before {\n  content: \"\\e05d\";\n}\n.icon-pie-chart:before {\n  content: \"\\e05e\";\n}\n.icon-pencil:before {\n  content: \"\\e05f\";\n}\n.icon-note:before {\n  content: \"\\e060\";\n}\n.icon-loop:before {\n  content: \"\\e064\";\n}\n.icon-home:before {\n  content: \"\\e069\";\n}\n.icon-grid:before {\n  content: \"\\e06a\";\n}\n.icon-graph:before {\n  content: \"\\e06b\";\n}\n.icon-microphone:before {\n  content: \"\\e063\";\n}\n.icon-music-tone-alt:before {\n  content: \"\\e061\";\n}\n.icon-music-tone:before {\n  content: \"\\e062\";\n}\n.icon-earphones-alt:before {\n  content: \"\\e03c\";\n}\n.icon-earphones:before {\n  content: \"\\e03d\";\n}\n.icon-equalizer:before {\n  content: \"\\e06c\";\n}\n.icon-like:before {\n  content: \"\\e068\";\n}\n.icon-dislike:before {\n  content: \"\\e06d\";\n}\n.icon-control-start:before {\n  content: \"\\e06f\";\n}\n.icon-control-rewind:before {\n  content: \"\\e070\";\n}\n.icon-control-play:before {\n  content: \"\\e071\";\n}\n.icon-control-pause:before {\n  content: \"\\e072\";\n}\n.icon-control-forward:before {\n  content: \"\\e073\";\n}\n.icon-control-end:before {\n  content: \"\\e074\";\n}\n.icon-volume-1:before {\n  content: \"\\e09f\";\n}\n.icon-volume-2:before {\n  content: \"\\e0a0\";\n}\n.icon-volume-off:before {\n  content: \"\\e0a1\";\n}\n.icon-calendar:before {\n  content: \"\\e075\";\n}\n.icon-bulb:before {\n  content: \"\\e076\";\n}\n.icon-chart:before {\n  content: \"\\e077\";\n}\n.icon-ban:before {\n  content: \"\\e07c\";\n}\n.icon-bubble:before {\n  content: \"\\e07d\";\n}\n.icon-camrecorder:before {\n  content: \"\\e07e\";\n}\n.icon-camera:before {\n  content: \"\\e07f\";\n}\n.icon-cloud-download:before {\n  content: \"\\e083\";\n}\n.icon-cloud-upload:before {\n  content: \"\\e084\";\n}\n.icon-envelope:before {\n  content: \"\\e086\";\n}\n.icon-eye:before {\n  content: \"\\e087\";\n}\n.icon-flag:before {\n  content: \"\\e088\";\n}\n.icon-heart:before {\n  content: \"\\e08a\";\n}\n.icon-info:before {\n  content: \"\\e08b\";\n}\n.icon-key:before {\n  content: \"\\e08c\";\n}\n.icon-link:before {\n  content: \"\\e08d\";\n}\n.icon-lock:before {\n  content: \"\\e08e\";\n}\n.icon-lock-open:before {\n  content: \"\\e08f\";\n}\n.icon-magnifier:before {\n  content: \"\\e090\";\n}\n.icon-magnifier-add:before {\n  content: \"\\e091\";\n}\n.icon-magnifier-remove:before {\n  content: \"\\e092\";\n}\n.icon-paper-clip:before {\n  content: \"\\e093\";\n}\n.icon-paper-plane:before {\n  content: \"\\e094\";\n}\n.icon-power:before {\n  content: \"\\e097\";\n}\n.icon-refresh:before {\n  content: \"\\e098\";\n}\n.icon-reload:before {\n  content: \"\\e099\";\n}\n.icon-settings:before {\n  content: \"\\e09a\";\n}\n.icon-star:before {\n  content: \"\\e09b\";\n}\n.icon-symbol-female:before {\n  content: \"\\e09c\";\n}\n.icon-symbol-male:before {\n  content: \"\\e09d\";\n}\n.icon-target:before {\n  content: \"\\e09e\";\n}\n.icon-credit-card:before {\n  content: \"\\e025\";\n}\n.icon-paypal:before {\n  content: \"\\e608\";\n}\n.icon-social-tumblr:before {\n  content: \"\\e00a\";\n}\n.icon-social-twitter:before {\n  content: \"\\e009\";\n}\n.icon-social-facebook:before {\n  content: \"\\e00b\";\n}\n.icon-social-instagram:before {\n  content: \"\\e609\";\n}\n.icon-social-linkedin:before {\n  content: \"\\e60a\";\n}\n.icon-social-pinterest:before {\n  content: \"\\e60b\";\n}\n.icon-social-github:before {\n  content: \"\\e60c\";\n}\n.icon-social-google:before {\n  content: \"\\e60d\";\n}\n.icon-social-reddit:before {\n  content: \"\\e60e\";\n}\n.icon-social-skype:before {\n  content: \"\\e60f\";\n}\n.icon-social-dribbble:before {\n  content: \"\\e00d\";\n}\n.icon-social-behance:before {\n  content: \"\\e610\";\n}\n.icon-social-foursqare:before {\n  content: \"\\e611\";\n}\n.icon-social-soundcloud:before {\n  content: \"\\e612\";\n}\n.icon-social-spotify:before {\n  content: \"\\e613\";\n}\n.icon-social-stumbleupon:before {\n  content: \"\\e614\";\n}\n.icon-social-youtube:before {\n  content: \"\\e008\";\n}\n.icon-social-dropbox:before {\n  content: \"\\e00c\";\n}\n.icon-social-vkontakte:before {\n  content: \"\\e618\";\n}\n.icon-social-steam:before {\n  content: \"\\e620\";\n}\n", ""]);

/***/ }),

/***/ 73:
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(901)
__webpack_require__(900)

var Component = __webpack_require__(3)(
  /* script */
  __webpack_require__(380),
  /* template */
  __webpack_require__(789),
  /* scopeId */
  null,
  /* cssModules */
  null
)
Component.options.__file = "/var/www/html/clear-vue-laravel/resources/assets/components/font_icons.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] font_icons.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-45025b2c", Component.options)
  } else {
    hotAPI.reload("data-v-45025b2c", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),

/***/ 789:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('h4', [_vm._v("You can use different sets of icon fonts:")]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-md-6 col-sm-6"
  }, [_c('div', {
    staticClass: "panel"
  }, [_vm._m(0), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('div', {
    staticClass: "icon_group"
  }, [_vm._m(1), _vm._v(" "), _c('div', {
    staticClass: "icon_cover text-center"
  }, [_c('router-link', {
    staticClass: "btn btn-primary",
    attrs: {
      "to": "/themify_icons"
    }
  }, [_vm._v("View All\n                            ")])], 1)])])])]), _vm._v(" "), _c('div', {
    staticClass: "col-md-6 col-sm-6"
  }, [_c('div', {
    staticClass: "panel"
  }, [_vm._m(2), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('div', {
    staticClass: "icon_group"
  }, [_vm._m(3), _vm._v(" "), _c('div', {
    staticClass: "icon_cover text-center"
  }, [_c('router-link', {
    staticClass: "btn btn-primary",
    attrs: {
      "to": "/fontawesome_icons"
    }
  }, [_vm._v("View All\n                            ")])], 1)])])])]), _vm._v(" "), _c('div', {
    staticClass: "col-md-6 col-sm-6 m-t-10"
  }, [_c('div', {
    staticClass: "panel"
  }, [_vm._m(4), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('div', {
    staticClass: "icon_group"
  }, [_vm._m(5), _vm._v(" "), _c('div', {
    staticClass: "icon_cover text-center"
  }, [_c('router-link', {
    staticClass: "btn btn-primary",
    attrs: {
      "to": "/glyphicons"
    }
  }, [_vm._v("View All\n                            ")])], 1)])])])]), _vm._v(" "), _c('div', {
    staticClass: "col-md-6 col-sm-6 m-t-10"
  }, [_c('div', {
    staticClass: "panel"
  }, [_vm._m(6), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('div', {
    staticClass: "icon_group"
  }, [_vm._m(7), _vm._v(" "), _c('div', {
    staticClass: "icon_cover text-center"
  }, [_c('router-link', {
    staticClass: "btn btn-primary",
    attrs: {
      "to": "/simple_line_icons"
    }
  }, [_vm._v("View All\n                            ")])], 1)])])])])])])
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "panel-heading"
  }, [_c('h4', {
    staticClass: "iconset_name"
  }, [_vm._v("Themify Icons")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "icon_set text-center"
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-wand icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-save icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-direction icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-link icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-unlink icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-target icons"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-spray icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-signal icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-shopping-cart-full icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-settings icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-back-left icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-facebook icons"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-map-alt icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-bar-chart-alt icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-vector icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-control-record icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-ink-pen icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-help-alt icons"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-face-sad icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-new-window icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-rss-alt icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-control-stop icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-control-shuffle icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-paragraph icons"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-paragraph icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-underline icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-quote-right icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-layout-column2 icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-instagram icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "ti-twitter icons"
  })])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "panel-heading"
  }, [_c('h4', {
    staticClass: "iconset_name"
  }, [_vm._v("Font Awesome Icons")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "icon_set fontawesome_icons text-center"
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-bolt"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-bullhorn"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-clock-o"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-cloud-upload"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-cog"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-compass"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-edit"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-female"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-frown-o"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-legal"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-mail-reply-all"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-mail-forward"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-phone-square"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-plus-circle"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-rss-square"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-signal"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-smile-o"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-spinner"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-thumbs-o-up"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-ticket"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-close removepanel clickable"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-toggle-down"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-trash-o"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-users"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-copy"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-list-ul"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-list-alt"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-arrow-circle-down"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-caret-square-o-down"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "fa fa-fw fa-chevron-right"
  })])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "panel-heading"
  }, [_c('h4', {
    staticClass: "iconset_name"
  }, [_vm._v("Glyphicons")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "icon_set glyphicon_icons text-center"
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-briefcase"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-check"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-dashboard"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-credit-card"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-euro"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-eye-open"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-floppy-open"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-fire"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-forward"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-hd-video"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-header"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-heart"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-globe"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-headphones"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-off"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-plane"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-plus"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-pushpin"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-remove"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-retweet"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-saved"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-sound-6-1"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-th-large"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-tower"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-tree-deciduous"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-trash"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-user"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-warning-sign"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-star"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('span', {
    staticClass: "glyphicon glyphicon-signal"
  })])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "panel-heading"
  }, [_c('h4', {
    staticClass: "iconset_name"
  }, [_vm._v("Simple Line Icons")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "icon_set text-center"
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-compass icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-directions icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-earphones-alt icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-equalizer icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-dislike icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-mustache icons"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-cursor-move icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-folder icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-ghost icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-present icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-grid icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-social-linkedin icons"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-symbol-female icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-social-behance icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-settings icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-paper-plane icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-lock icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-camrecorder icons"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-magnifier-remove icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-calendar icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-control-play icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-social-twitter icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-social-facebook icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-social-dropbox icons"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-social-vkontakte icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-social-google icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-cloud-upload icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-control-rewind icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-size-fullscreen icons"
  })]), _vm._v(" "), _c('div', {
    staticClass: "col-xs-2"
  }, [_c('i', {
    staticClass: "icon-diamond icons"
  })])])])
}]}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-45025b2c", module.exports)
  }
}

/***/ }),

/***/ 900:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(547);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("dcd0fa08", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../../node_modules/css-loader/index.js!../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-45025b2c\",\"scoped\":false,\"hasInlineConfig\":true}!./fonts.css", function() {
     var newContent = require("!!../../../../../node_modules/css-loader/index.js!../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-45025b2c\",\"scoped\":false,\"hasInlineConfig\":true}!./fonts.css");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 901:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(548);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("54b55ef8", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../../node_modules/css-loader/index.js!../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-45025b2c\",\"scoped\":false,\"hasInlineConfig\":true}!./simple-line-icons.css", function() {
     var newContent = require("!!../../../../../node_modules/css-loader/index.js!../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-45025b2c\",\"scoped\":false,\"hasInlineConfig\":true}!./simple-line-icons.css");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ })

});