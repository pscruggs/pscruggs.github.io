webpackJsonp([69],{

/***/ 387:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
    name: "general_components",
    mounted: function mounted() {},
    destroyed: function destroyed() {}
});

/***/ }),

/***/ 554:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)();
exports.push([module.i, "\n.alert-message[data-v-48526b4f] {\n    margin      : 13px 0;\n    padding     : 20px;\n    border-left : 3px solid #eee;\n}\n.alert-message h4[data-v-48526b4f] {\n    margin-top    : 0;\n    margin-bottom : 5px;\n}\n.alert-message p[data-v-48526b4f]:last-child {\n    margin-bottom : 0;\n}\n.alert-message code[data-v-48526b4f] {\n    background-color : #fff;\n    border-radius    : 3px;\n}\n.alert-message-success[data-v-48526b4f] {\n    background-color : #F4FDF0;\n    border-color     : #22d69d;\n}\n.alert-message-success h4[data-v-48526b4f] {\n    color : #22d69d;\n}\n.alert-message-danger[data-v-48526b4f] {\n    background-color : #fdf7f7;\n    border-color     : #fb8678;\n}\n.alert-message-danger h4[data-v-48526b4f] {\n    color : #fb8678;\n}\n.alert-message-warning[data-v-48526b4f] {\n    background-color : #fcf8f2;\n    border-color     : #ffb65f;\n}\n.alert-message-warning h4[data-v-48526b4f] {\n    color : #ffb65f;\n}\n.alert-message-info[data-v-48526b4f] {\n    background-color : #f4f8fa;\n    border-color     : #4fc1e9;\n}\n.alert-message-info h4[data-v-48526b4f] {\n    color : #4fc1e9;\n}\n.alert-message-default[data-v-48526b4f] {\n    background-color : #EEE;\n    border-color     : #dcdcdc;\n}\n.alert-message-notice[data-v-48526b4f] {\n    background-color : #FCFCDD;\n    border-color     : #BDBD89;\n}\n.alert-message-notice h4[data-v-48526b4f] {\n    color : #444;\n}\n/*list styles*/\n.styled-ul[data-v-48526b4f] {\n    list-style: disc;\n}\n.styled-ul li ul[data-v-48526b4f] {\n    list-style-type: circle;\n}\n/*breadcrumbs*/\n.breadcrumb1 > li + li[data-v-48526b4f]:before {\n    content: \"\\00BB\";\n}\n.breadcrumb2 > li + li[data-v-48526b4f]:before {\n    content: \"\\203A\";\n}\n.breadcrumb3 > li + li[data-v-48526b4f]:before {\n    content: \"\\2013 \";\n}\n/*progress bar*/\n.box-body .progress[data-v-48526b4f] {\n    margin-top :4px;\n}", ""]);

/***/ }),

/***/ 793:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _vm._m(0)
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-md-6"
  }, [_c('div', {
    staticClass: "panel "
  }, [_c('div', {
    staticClass: "panel-heading"
  }, [_c('h3', {
    staticClass: "panel-title"
  }, [_c('i', {
    staticClass: "ti-headphone-alt"
  }), _vm._v(" Wells\n                        ")]), _vm._v(" "), _c('span', {
    staticClass: "pull-right"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-angle-up clickable"
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-fw ti-close removepanel clickable"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('div', [_c('div', {
    staticClass: "well well-sm"
  }, [_vm._v("\n                            Look, I'm in a small well!\n                        ")]), _vm._v(" "), _c('div', {
    staticClass: "well"
  }, [_vm._v("\n                            Look, I'm in a well!\n                        ")]), _vm._v(" "), _c('div', {
    staticClass: "well well-lg"
  }, [_vm._v("\n                            Look, I'm in a large well!\n                        ")])])])])]), _vm._v(" "), _c('div', {
    staticClass: "col-md-6"
  }, [_c('div', {
    staticClass: "panel "
  }, [_c('div', {
    staticClass: "panel-heading"
  }, [_c('h3', {
    staticClass: "panel-title"
  }, [_c('i', {
    staticClass: "ti-angle-double-right"
  }), _vm._v(" Breadcrumbs\n                        ")]), _vm._v(" "), _c('span', {
    staticClass: "pull-right"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-angle-up clickable"
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-fw ti-close removepanel clickable"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('div', {
    staticClass: "bs-example"
  }, [_c('ul', {
    staticClass: "breadcrumb"
  }, [_c('li', {
    staticClass: "next"
  }, [_c('a', {
    attrs: {
      "href": "#"
    }
  }, [_vm._v("Home")])]), _vm._v(" "), _c('li', {
    staticClass: "next"
  }, [_c('a', {
    attrs: {
      "href": "#"
    }
  }, [_vm._v("\n                                        UI Features\n                                    ")])]), _vm._v(" "), _c('li', [_vm._v("Pickers")])]), _vm._v(" "), _c('ul', {
    staticClass: "breadcrumb breadcrumb1"
  }, [_c('li', {
    staticClass: "next1"
  }, [_c('a', {
    attrs: {
      "href": "#"
    }
  }, [_vm._v("Dashboard")])]), _vm._v(" "), _c('li', {
    staticClass: "next1"
  }, [_c('a', {
    attrs: {
      "href": "#"
    }
  }, [_vm._v("Charts")])]), _vm._v(" "), _c('li', [_vm._v("\n                                Flot Charts\n                            ")])]), _vm._v(" "), _c('ul', {
    staticClass: "breadcrumb breadcrumb2",
    staticStyle: {
      "margin-bottom": "20px"
    }
  }, [_c('li', {
    staticClass: "next2"
  }, [_c('a', {
    attrs: {
      "href": "#"
    }
  }, [_vm._v("Dashboard")])]), _vm._v(" "), _c('li', {
    staticClass: "next2"
  }, [_c('a', {
    attrs: {
      "href": "#"
    }
  }, [_vm._v("Tables")])]), _vm._v(" "), _c('li', [_vm._v("\n                                Data Tables\n                            ")])]), _vm._v(" "), _c('ul', {
    staticClass: "breadcrumb breadcrumb3",
    staticStyle: {
      "margin-bottom": "15px"
    }
  }, [_c('li', {
    staticClass: "next"
  }, [_c('a', {
    attrs: {
      "href": "#"
    }
  }, [_vm._v("Dashboard")])]), _vm._v(" "), _c('li', {
    staticClass: "next1"
  }, [_c('a', {
    attrs: {
      "href": "#"
    }
  }, [_vm._v("Forms")])]), _vm._v(" "), _c('li', [_vm._v("\n                                Form Elements\n                            ")])])])])])])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-sm-6 col-md-4"
  }, [_c('div', {
    staticClass: "panel panel-primary"
  }, [_c('div', {
    staticClass: "panel-heading"
  }, [_c('h3', {
    staticClass: "panel-title"
  }, [_vm._v("\n                            Panel Primary\n                        ")])]), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('p', [_vm._v("Lorem Ipsum is simply dummy text of the printing and typesetting industry.")])])])]), _vm._v(" "), _c('div', {
    staticClass: "col-sm-6 col-md-4"
  }, [_c('div', {
    staticClass: "panel panel-success"
  }, [_c('div', {
    staticClass: "panel-heading"
  }, [_c('h3', {
    staticClass: "panel-title"
  }, [_vm._v("\n                            Panel Success\n                        ")])]), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('p', [_vm._v("Lorem Ipsum is simply dummy text of the printing and typesetting industry.")])])])]), _vm._v(" "), _c('div', {
    staticClass: "col-sm-6 col-md-4"
  }, [_c('div', {
    staticClass: "panel panel-warning"
  }, [_c('div', {
    staticClass: "panel-heading"
  }, [_c('h3', {
    staticClass: "panel-title"
  }, [_vm._v("\n                            Panel Warning\n                        ")])]), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('p', [_vm._v("Lorem Ipsum is simply dummy text of the printing and typesetting industry.")])])])]), _vm._v(" "), _c('div', {
    staticClass: "col-sm-6 col-md-4"
  }, [_c('div', {
    staticClass: "panel panel-danger"
  }, [_c('div', {
    staticClass: "panel-heading"
  }, [_c('h3', {
    staticClass: "panel-title"
  }, [_vm._v("\n                            Panel Danger\n                        ")])]), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('p', [_vm._v("Lorem Ipsum is simply dummy text of the printing and typesetting industry.")])])])]), _vm._v(" "), _c('div', {
    staticClass: "col-sm-6 col-md-4"
  }, [_c('div', {
    staticClass: "panel panel-info"
  }, [_c('div', {
    staticClass: "panel-heading"
  }, [_c('h3', {
    staticClass: "panel-title"
  }, [_vm._v("Panel Info")])]), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('p', [_vm._v("Lorem Ipsum is simply dummy text of the printing and typesetting industry.")])])])]), _vm._v(" "), _c('div', {
    staticClass: "col-sm-6 col-md-4"
  }, [_c('div', {
    staticClass: "panel panel-default"
  }, [_c('div', {
    staticClass: "panel-heading"
  }, [_c('h3', {
    staticClass: "panel-title"
  }, [_vm._v("\n                            Panel Default\n                        ")])]), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('p', [_vm._v("Lorem Ipsum is simply dummy text of the printing and typesetting industry.")])])])])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-md-6"
  }, [_c('div', {
    staticClass: "panel "
  }, [_c('div', {
    staticClass: "panel-heading"
  }, [_c('h3', {
    staticClass: "panel-title"
  }, [_c('i', {
    staticClass: "ti-layers"
  }), _vm._v("Tabbed Panel")])]), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('div', {
    staticClass: "nav-tabs-custom"
  }, [_c('ul', {
    staticClass: "nav nav-tabs"
  }, [_c('li', {
    staticClass: "active"
  }, [_c('a', {
    attrs: {
      "href": "#tab_1",
      "data-toggle": "tab"
    }
  }, [_vm._v("Tab 1")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "#tab_2",
      "data-toggle": "tab"
    }
  }, [_vm._v("Tab 2")])]), _vm._v(" "), _c('li', {
    staticClass: "pull-right"
  }, [_c('a', {
    staticClass: "text-muted",
    attrs: {
      "href": "#"
    }
  }, [_c('i', {
    staticClass: "ti-settings"
  })])])]), _vm._v(" "), _c('div', {
    staticClass: "tab-content",
    attrs: {
      "id": "slim1"
    }
  }, [_c('div', {
    staticClass: "tab-pane active",
    attrs: {
      "id": "tab_1"
    }
  }, [_c('br'), _vm._v(" "), _c('p', [_vm._v("Lorem Ipsum is simply dummy text of the printing and typesetting industry. When an unknown printer took a galley of type and scrambled it to make a type specimenbook.\n                                ")]), _vm._v(" "), _c('p', [_vm._v("It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.\n                                ")]), _vm._v(" "), _c('p', [_vm._v("It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and software like Aldus PageMaker.\n                                ")])]), _vm._v(" "), _c('div', {
    staticClass: "tab-pane",
    attrs: {
      "id": "tab_2"
    }
  }, [_c('br'), _vm._v(" "), _c('p', [_vm._v("\n                                    It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal.\n                                ")]), _vm._v(" "), _c('p', [_vm._v("Distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.\n                                ")]), _vm._v(" "), _c('p', [_vm._v("\n                                    model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years.\n                                ")])])])])])])]), _vm._v(" "), _c('div', {
    staticClass: "col-md-6"
  }, [_c('div', {
    staticClass: "panel "
  }, [_c('div', {
    staticClass: "panel-heading"
  }, [_c('h3', {
    staticClass: "panel-title"
  }, [_c('i', {
    staticClass: "ti-menu"
  }), _vm._v("Progress Bars\n                        ")]), _vm._v(" "), _c('span', {
    staticClass: "pull-right"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-angle-up clickable"
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-fw ti-close removepanel clickable"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('div', {
    staticClass: "box-body"
  }, [_vm._v("\n                        Default\n                        "), _c('div', {
    staticClass: "progress"
  }, [_c('div', {
    staticClass: "progress-bar progress-bar-success",
    staticStyle: {
      "width": "40%"
    },
    attrs: {
      "role": "progressbar",
      "aria-valuenow": "40",
      "aria-valuemin": "0",
      "aria-valuemax": "100"
    }
  }, [_c('span', {
    staticClass: "sr-only"
  }, [_vm._v("\n                                            40% Complete (success)\n                                        ")])])]), _vm._v("\n                        Class:\n                        "), _c('code', [_vm._v(".progress-striped")]), _vm._v(" "), _c('div', {
    staticClass: "progress progress-striped"
  }, [_c('div', {
    staticClass: "progress-bar progress-bar-primary",
    staticStyle: {
      "width": "40%"
    },
    attrs: {
      "role": "progressbar",
      "aria-valuenow": "40",
      "aria-valuemin": "0",
      "aria-valuemax": "100"
    }
  }, [_c('span', {
    staticClass: "sr-only"
  }, [_vm._v("\n                                            40% Complete (success)\n                                        ")])])]), _vm._v("\n                        Class:\n                        "), _c('code', [_vm._v(".sm .active")]), _vm._v(" "), _c('div', {
    staticClass: "progress sm progress-striped active"
  }, [_c('div', {
    staticClass: "progress-bar progress-bar-success",
    staticStyle: {
      "width": "20%"
    },
    attrs: {
      "role": "progressbar",
      "aria-valuenow": "20",
      "aria-valuemin": "0",
      "aria-valuemax": "100"
    }
  }, [_c('span', {
    staticClass: "sr-only"
  }, [_vm._v("\n                                            20% Complete\n                                        ")])])]), _vm._v("\n                        Class:\n                        "), _c('code', [_vm._v(".xs")]), _vm._v(" "), _c('div', {
    staticClass: "progress progress-xs progress_task progress-striped"
  }, [_c('div', {
    staticClass: "progress-bar progress-bar-warning",
    staticStyle: {
      "width": "60%"
    },
    attrs: {
      "role": "progressbar",
      "aria-valuenow": "60",
      "aria-valuemin": "0",
      "aria-valuemax": "100"
    }
  }, [_c('span', {
    staticClass: "sr-only"
  }, [_vm._v("\n                                            60% Complete (warning)\n                                        ")])])])])])])])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-md-6"
  }, [_c('div', {
    staticClass: "panel "
  }, [_c('div', {
    staticClass: "panel-heading"
  }, [_c('h3', {
    staticClass: "panel-title"
  }, [_c('i', {
    staticClass: "ti-alert"
  }), _vm._v(" Alerts\n                        ")]), _vm._v(" "), _c('span', {
    staticClass: "pull-right"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-angle-up clickable"
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-fw ti-close removepanel clickable"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('div', {
    staticClass: "alert alert-success"
  }, [_c('p', [_vm._v("\n                            Well done! You are reading a default Alert message.\n                        ")])]), _vm._v(" "), _c('div', {
    staticClass: "alert alert-danger"
  }, [_c('strong', [_vm._v("Oh! You can")]), _vm._v(" "), _c('a', {
    staticClass: "alert-link",
    attrs: {
      "href": "#"
    }
  }, [_vm._v("\n                                Redirect to me\n                            ")]), _vm._v(" clicking the link on the Alert.\n                    ")]), _vm._v(" "), _c('div', {
    staticClass: "alert alert-info alert-dismissable"
  }, [_c('button', {
    staticClass: "close",
    attrs: {
      "type": "button",
      "data-dismiss": "alert",
      "aria-hidden": "true"
    }
  }, [_vm._v("×")]), _vm._v(" "), _c('strong', [_vm._v("Heads up!")]), _vm._v(" You are looking at a Dismissable Alert.\n                    ")]), _vm._v(" "), _c('div', {
    staticClass: "alert alert-warning fade in"
  }, [_c('button', {
    staticClass: "close",
    attrs: {
      "type": "button",
      "data-dismiss": "alert",
      "aria-hidden": "true"
    }
  }, [_vm._v("×")]), _vm._v("\n                        Hey! You are looking at Dismissable Alert with animation.\n                    ")])])])]), _vm._v(" "), _c('div', {
    staticClass: "col-md-6"
  }, [_c('div', {
    staticClass: "panel "
  }, [_c('div', {
    staticClass: "panel-heading"
  }, [_c('h3', {
    staticClass: "panel-title"
  }, [_c('i', {
    staticClass: "ti-notepad"
  }), _vm._v(" Notes\n                        ")]), _vm._v(" "), _c('span', {
    staticClass: "pull-right"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-angle-up clickable"
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-fw ti-close removepanel clickable"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('div', {
    staticClass: "alert-message alert-message-success"
  }, [_c('h4', [_vm._v("\n                                Alert Message Success\n                            ")]), _vm._v(" "), _c('p', [_vm._v("\n                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.\n                            "), _c('strong', [_vm._v("\n                                    strong message\n                                ")]), _vm._v(" .\n                        ")])]), _vm._v(" "), _c('div', {
    staticClass: "alert-message alert-message-default"
  }, [_c('h4', [_vm._v("\n                                Alert Message Default\n                            ")]), _vm._v(" "), _c('p', [_vm._v("\n                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.\n                            "), _c('strong', [_vm._v("\n                                    strong message\n                                ")]), _vm._v(" .\n                        ")])])])])])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-md-6"
  }, [_c('div', {
    staticClass: "panel "
  }, [_c('div', {
    staticClass: "panel-heading"
  }, [_c('h3', {
    staticClass: "panel-title"
  }, [_c('i', {
    staticClass: "ti-settings"
  }), _vm._v(" Typography Heading\n                        ")]), _vm._v(" "), _c('span', {
    staticClass: "pull-right"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-angle-up clickable"
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-fw ti-close removepanel clickable"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('div', {
    staticClass: "box-body text-center"
  }, [_c('h1', [_vm._v("\n                                h1. Bootstrap heading\n                            ")]), _vm._v(" "), _c('h2', [_vm._v("\n                                h2. Bootstrap heading\n                            ")]), _vm._v(" "), _c('h3', [_vm._v("\n                                h3. Bootstrap heading\n                            ")]), _vm._v(" "), _c('h4', [_vm._v("\n                                h4. Bootstrap heading\n                            ")]), _vm._v(" "), _c('h5', [_vm._v("\n                                h5. Bootstrap heading\n                            ")]), _vm._v(" "), _c('h6', [_vm._v("\n                                h6. Bootstrap heading\n                            ")])])])])]), _vm._v(" "), _c('div', {
    staticClass: "col-md-6"
  }, [_c('div', {
    staticClass: "panel "
  }, [_c('div', {
    staticClass: "panel-heading"
  }, [_c('h3', {
    staticClass: "panel-title"
  }, [_c('i', {
    staticClass: "ti-menu"
  }), _vm._v(" Horizontal Description\n                        ")]), _vm._v(" "), _c('span', {
    staticClass: "pull-right"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-angle-up clickable"
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-fw ti-close removepanel clickable"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('div', {
    staticClass: "box-body"
  }, [_c('dl', {
    staticClass: "dl-horizontal"
  }, [_c('dt', [_vm._v("\n                                Description lists\n                            ")]), _vm._v(" "), _c('dd', [_vm._v("\n                                A description list is perfect for defining terms.\n                            ")]), _vm._v(" "), _c('dt', [_vm._v("Question")]), _vm._v(" "), _c('dd', [_vm._v("\n                                Vestibulum id ligula porta felis euismod semper eget lacinia odio.\n                            ")]), _vm._v(" "), _c('dt', [_vm._v("\n                                Progress bar\n                            ")]), _vm._v(" "), _c('dd', [_vm._v("\n                                Etiam porta sem malesuada magna mollis euismod.\n                            ")]), _vm._v(" "), _c('dt', [_vm._v("Answer")]), _vm._v(" "), _c('dd', [_vm._v("\n                                Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, justo sit amet risus.\n                            ")]), _vm._v(" "), _c('dt', [_vm._v("\n                                Description lists\n                            ")]), _vm._v(" "), _c('dd', [_vm._v("\n                                A description list is perfect for defining terms.\n                            ")]), _vm._v(" "), _c('dt', [_vm._v("Question")]), _vm._v(" "), _c('dd', [_vm._v("\n                                Vestibulum id ligula porta felis euismod semper.\n                            ")]), _vm._v(" "), _c('dt', [_vm._v("Answer")]), _vm._v(" "), _c('dd', [_vm._v("\n                                Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, justo sit amet risus.\n                            ")])])])])])])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "col-md-4"
  }, [_c('div', {
    staticClass: "panel "
  }, [_c('div', {
    staticClass: "panel-heading"
  }, [_c('h3', {
    staticClass: "panel-title"
  }, [_c('i', {
    staticClass: "ti-view-list-alt"
  }), _vm._v(" Unstyled List\n                        ")]), _vm._v(" "), _c('span', {
    staticClass: "pull-right"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-angle-up clickable"
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-fw ti-close removepanel clickable"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('div', {
    staticClass: "box-body"
  }, [_c('ul', {
    staticClass: "list-unstyled"
  }, [_c('li', [_vm._v("\n                                Lorem ipsum dolor sit amet\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Consectetur adipiscing elit\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Integer molestie lorem at massa\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Facilisis in pretium nisl aliquet\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Nulla volutpat aliquam velit\n                                "), _c('ul', [_c('li', [_vm._v("\n                                        Phasellus iaculis neque\n                                    ")]), _vm._v(" "), _c('li', [_vm._v("\n                                        Purus sodales ultricies\n                                    ")]), _vm._v(" "), _c('li', [_vm._v("\n                                        Vestibulum laoreet porttitor sem\n                                    ")]), _vm._v(" "), _c('li', [_vm._v("\n                                        Ac tristique libero volutpat at\n                                    ")])])]), _vm._v(" "), _c('li', [_vm._v("\n                                Faucibus porta lacus fringilla vel\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Aenean sit amet erat nunc\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Eget porttitor lorem\n                            ")])])])])])]), _vm._v(" "), _c('div', {
    staticClass: "col-md-4"
  }, [_c('div', {
    staticClass: "panel "
  }, [_c('div', {
    staticClass: "panel-heading"
  }, [_c('h3', {
    staticClass: "panel-title"
  }, [_c('i', {
    staticClass: "ti-list"
  }), _vm._v(" Unordered List\n                        ")]), _vm._v(" "), _c('span', {
    staticClass: "pull-right"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-angle-up clickable"
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-fw ti-close removepanel clickable"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('div', {
    staticClass: "box-body"
  }, [_c('ul', {
    staticClass: "styled-ul"
  }, [_c('li', [_vm._v("\n                                Lorem ipsum dolor sit amet\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Consectetur adipiscing elit\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Integer molestie lorem at massa\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Facilisis in pretium nisl aliquet\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Nulla volutpat aliquam velit\n                                "), _c('ul', [_c('li', [_vm._v("\n                                        Phasellus iaculis neque\n                                    ")]), _vm._v(" "), _c('li', [_vm._v("\n                                        Purus sodales ultricies\n                                    ")]), _vm._v(" "), _c('li', [_vm._v("\n                                        Vestibulum laoreet porttitor sem\n                                    ")]), _vm._v(" "), _c('li', [_vm._v("\n                                        Ac tristique libero volutpat at\n                                    ")])])]), _vm._v(" "), _c('li', [_vm._v("\n                                Faucibus porta lacus fringilla vel\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Aenean sit amet erat nunc\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Eget porttitor lorem\n                            ")])])])])])]), _vm._v(" "), _c('div', {
    staticClass: "col-md-4"
  }, [_c('div', {
    staticClass: "panel "
  }, [_c('div', {
    staticClass: "panel-heading"
  }, [_c('h3', {
    staticClass: "panel-title"
  }, [_c('i', {
    staticClass: "ti-list-ol"
  }), _vm._v(" Ordered Lists\n                        ")]), _vm._v(" "), _c('span', {
    staticClass: "pull-right"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-angle-up clickable"
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-fw ti-close removepanel clickable"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "panel-body"
  }, [_c('div', {
    staticClass: "box-body"
  }, [_c('ol', [_c('li', [_vm._v("\n                                Lorem ipsum dolor sit amet\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Consectetur adipiscing elit\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Integer molestie lorem at massa\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Facilisis in pretium nisl aliquet\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Nulla volutpat aliquam velit\n                                "), _c('ol', [_c('li', [_vm._v("\n                                        Phasellus iaculis neque\n                                    ")]), _vm._v(" "), _c('li', [_vm._v("\n                                        Purus sodales ultricies\n                                    ")]), _vm._v(" "), _c('li', [_vm._v("\n                                        Vestibulum laoreet porttitor sem\n                                    ")]), _vm._v(" "), _c('li', [_vm._v("\n                                        Ac tristique libero volutpat at\n                                    ")])])]), _vm._v(" "), _c('li', [_vm._v("\n                                Faucibus porta lacus fringilla vel\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Aenean sit amet erat nunc\n                            ")]), _vm._v(" "), _c('li', [_vm._v("\n                                Eget porttitor lorem\n                            ")])])])])])])])])
}]}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-48526b4f", module.exports)
  }
}

/***/ }),

/***/ 80:
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(907)

var Component = __webpack_require__(3)(
  /* script */
  __webpack_require__(387),
  /* template */
  __webpack_require__(793),
  /* scopeId */
  "data-v-48526b4f",
  /* cssModules */
  null
)
Component.options.__file = "/var/www/html/clear-vue-laravel/resources/assets/components/general_components.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] general_components.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-48526b4f", Component.options)
  } else {
    hotAPI.reload("data-v-48526b4f", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),

/***/ 907:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(554);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("69b188dc", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../node_modules/css-loader/index.js!../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-48526b4f\",\"scoped\":true,\"hasInlineConfig\":true}!./alertmessage.css", function() {
     var newContent = require("!!../../../../node_modules/css-loader/index.js!../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-48526b4f\",\"scoped\":true,\"hasInlineConfig\":true}!./alertmessage.css");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ })

});