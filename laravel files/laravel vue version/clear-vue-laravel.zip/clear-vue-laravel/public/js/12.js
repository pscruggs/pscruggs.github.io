webpackJsonp([12],{

/***/ 121:
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(878)
__webpack_require__(877)

var Component = __webpack_require__(3)(
  /* script */
  __webpack_require__(432),
  /* template */
  __webpack_require__(775),
  /* scopeId */
  null,
  /* cssModules */
  null
)
Component.options.__file = "/var/www/html/clear-vue-laravel/resources/assets/layout.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] layout.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-27913e91", Component.options)
  } else {
    hotAPI.reload("data-v-27913e91", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),

/***/ 239:
/***/ (function(module, exports) {

module.exports = "/clear-vue-laravel/public/images/brick-wall.png?effad1520fc39d8897385d7004d2dbf4";

/***/ }),

/***/ 242:
/***/ (function(module, exports) {

module.exports = "/clear-vue-laravel/public/images/avatar.jpg?411dee33b51de39bfbcda58698b02382";

/***/ }),

/***/ 244:
/***/ (function(module, exports) {

module.exports = "/clear-vue-laravel/public/images/avatar2.jpg?c880ad025efbef8ee5ae438b9799636f";

/***/ }),

/***/ 245:
/***/ (function(module, exports) {

module.exports = "/clear-vue-laravel/public/images/avatar3.jpg?5cc977990977a9c107216d8366aba18f";

/***/ }),

/***/ 247:
/***/ (function(module, exports) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/
var stylesInDom = {},
	memoize = function(fn) {
		var memo;
		return function () {
			if (typeof memo === "undefined") memo = fn.apply(this, arguments);
			return memo;
		};
	},
	isOldIE = memoize(function() {
		return /msie [6-9]\b/.test(self.navigator.userAgent.toLowerCase());
	}),
	getHeadElement = memoize(function () {
		return document.head || document.getElementsByTagName("head")[0];
	}),
	singletonElement = null,
	singletonCounter = 0,
	styleElementsInsertedAtTop = [];

module.exports = function(list, options) {
	if(typeof DEBUG !== "undefined" && DEBUG) {
		if(typeof document !== "object") throw new Error("The style-loader cannot be used in a non-browser environment");
	}

	options = options || {};
	// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
	// tags it will allow on a page
	if (typeof options.singleton === "undefined") options.singleton = isOldIE();

	// By default, add <style> tags to the bottom of <head>.
	if (typeof options.insertAt === "undefined") options.insertAt = "bottom";

	var styles = listToStyles(list);
	addStylesToDom(styles, options);

	return function update(newList) {
		var mayRemove = [];
		for(var i = 0; i < styles.length; i++) {
			var item = styles[i];
			var domStyle = stylesInDom[item.id];
			domStyle.refs--;
			mayRemove.push(domStyle);
		}
		if(newList) {
			var newStyles = listToStyles(newList);
			addStylesToDom(newStyles, options);
		}
		for(var i = 0; i < mayRemove.length; i++) {
			var domStyle = mayRemove[i];
			if(domStyle.refs === 0) {
				for(var j = 0; j < domStyle.parts.length; j++)
					domStyle.parts[j]();
				delete stylesInDom[domStyle.id];
			}
		}
	};
}

function addStylesToDom(styles, options) {
	for(var i = 0; i < styles.length; i++) {
		var item = styles[i];
		var domStyle = stylesInDom[item.id];
		if(domStyle) {
			domStyle.refs++;
			for(var j = 0; j < domStyle.parts.length; j++) {
				domStyle.parts[j](item.parts[j]);
			}
			for(; j < item.parts.length; j++) {
				domStyle.parts.push(addStyle(item.parts[j], options));
			}
		} else {
			var parts = [];
			for(var j = 0; j < item.parts.length; j++) {
				parts.push(addStyle(item.parts[j], options));
			}
			stylesInDom[item.id] = {id: item.id, refs: 1, parts: parts};
		}
	}
}

function listToStyles(list) {
	var styles = [];
	var newStyles = {};
	for(var i = 0; i < list.length; i++) {
		var item = list[i];
		var id = item[0];
		var css = item[1];
		var media = item[2];
		var sourceMap = item[3];
		var part = {css: css, media: media, sourceMap: sourceMap};
		if(!newStyles[id])
			styles.push(newStyles[id] = {id: id, parts: [part]});
		else
			newStyles[id].parts.push(part);
	}
	return styles;
}

function insertStyleElement(options, styleElement) {
	var head = getHeadElement();
	var lastStyleElementInsertedAtTop = styleElementsInsertedAtTop[styleElementsInsertedAtTop.length - 1];
	if (options.insertAt === "top") {
		if(!lastStyleElementInsertedAtTop) {
			head.insertBefore(styleElement, head.firstChild);
		} else if(lastStyleElementInsertedAtTop.nextSibling) {
			head.insertBefore(styleElement, lastStyleElementInsertedAtTop.nextSibling);
		} else {
			head.appendChild(styleElement);
		}
		styleElementsInsertedAtTop.push(styleElement);
	} else if (options.insertAt === "bottom") {
		head.appendChild(styleElement);
	} else {
		throw new Error("Invalid value for parameter 'insertAt'. Must be 'top' or 'bottom'.");
	}
}

function removeStyleElement(styleElement) {
	styleElement.parentNode.removeChild(styleElement);
	var idx = styleElementsInsertedAtTop.indexOf(styleElement);
	if(idx >= 0) {
		styleElementsInsertedAtTop.splice(idx, 1);
	}
}

function createStyleElement(options) {
	var styleElement = document.createElement("style");
	styleElement.type = "text/css";
	insertStyleElement(options, styleElement);
	return styleElement;
}

function createLinkElement(options) {
	var linkElement = document.createElement("link");
	linkElement.rel = "stylesheet";
	insertStyleElement(options, linkElement);
	return linkElement;
}

function addStyle(obj, options) {
	var styleElement, update, remove;

	if (options.singleton) {
		var styleIndex = singletonCounter++;
		styleElement = singletonElement || (singletonElement = createStyleElement(options));
		update = applyToSingletonTag.bind(null, styleElement, styleIndex, false);
		remove = applyToSingletonTag.bind(null, styleElement, styleIndex, true);
	} else if(obj.sourceMap &&
		typeof URL === "function" &&
		typeof URL.createObjectURL === "function" &&
		typeof URL.revokeObjectURL === "function" &&
		typeof Blob === "function" &&
		typeof btoa === "function") {
		styleElement = createLinkElement(options);
		update = updateLink.bind(null, styleElement);
		remove = function() {
			removeStyleElement(styleElement);
			if(styleElement.href)
				URL.revokeObjectURL(styleElement.href);
		};
	} else {
		styleElement = createStyleElement(options);
		update = applyToTag.bind(null, styleElement);
		remove = function() {
			removeStyleElement(styleElement);
		};
	}

	update(obj);

	return function updateStyle(newObj) {
		if(newObj) {
			if(newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap)
				return;
			update(obj = newObj);
		} else {
			remove();
		}
	};
}

var replaceText = (function () {
	var textStore = [];

	return function (index, replacement) {
		textStore[index] = replacement;
		return textStore.filter(Boolean).join('\n');
	};
})();

function applyToSingletonTag(styleElement, index, remove, obj) {
	var css = remove ? "" : obj.css;

	if (styleElement.styleSheet) {
		styleElement.styleSheet.cssText = replaceText(index, css);
	} else {
		var cssNode = document.createTextNode(css);
		var childNodes = styleElement.childNodes;
		if (childNodes[index]) styleElement.removeChild(childNodes[index]);
		if (childNodes.length) {
			styleElement.insertBefore(cssNode, childNodes[index]);
		} else {
			styleElement.appendChild(cssNode);
		}
	}
}

function applyToTag(styleElement, obj) {
	var css = obj.css;
	var media = obj.media;

	if(media) {
		styleElement.setAttribute("media", media)
	}

	if(styleElement.styleSheet) {
		styleElement.styleSheet.cssText = css;
	} else {
		while(styleElement.firstChild) {
			styleElement.removeChild(styleElement.firstChild);
		}
		styleElement.appendChild(document.createTextNode(css));
	}
}

function updateLink(linkElement, obj) {
	var css = obj.css;
	var sourceMap = obj.sourceMap;

	if(sourceMap) {
		// http://stackoverflow.com/a/26603875
		css += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + " */";
	}

	var blob = new Blob([css], { type: "text/css" });

	var oldSrc = linkElement.href;

	linkElement.href = URL.createObjectURL(blob);

	if(oldSrc)
		URL.revokeObjectURL(oldSrc);
}


/***/ }),

/***/ 251:
/***/ (function(module, exports) {

module.exports = "/clear-vue-laravel/public/images/avatar4.jpg?b8f96d84f21362b28c3784deeccd6aab";

/***/ }),

/***/ 259:
/***/ (function(module, exports) {

module.exports = "/clear-vue-laravel/public/images/avatar5.jpg?dd46e2e2d1f85d751bf6a5990d05678b";

/***/ }),

/***/ 260:
/***/ (function(module, exports) {

module.exports = "/clear-vue-laravel/public/images/avatar7.jpg?ccdd6115cac1528731d3400efd86d19d";

/***/ }),

/***/ 267:
/***/ (function(module, exports) {

module.exports = "/clear-vue-laravel/public/images/avatar6.jpg?71bfec8fc58afc8a950d31fa2414525c";

/***/ }),

/***/ 320:
/***/ (function(module, exports) {

module.exports = "/clear-vue-laravel/public/images/logo.png?a3b6fa986bbad5d807994d16c98b497e";

/***/ }),

/***/ 397:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function($) {Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
    name: "header",
    methods: {
        //Enable sidebar toggle
        toggle_left: function toggle_left() {
            //If window is small enough, enable sidebar push menu
            if ($(window).width() <= 992) {
                $('.row-offcanvas').toggleClass('active').toggleClass("relative");
                $('.left-side').removeClass("collapse-left");
                $(".right-side").removeClass("strech");
            } else {
                if (!$("body").hasClass("mini_sidebar")) {
                    //Else, enable content streching
                    $('.left-side').toggleClass("collapse-left");
                    $(".right-side").toggleClass("strech");
                }
            }
        },
        toggle_right: function toggle_right() {
            switch (true) {
                // Close right panel
                case $("body").hasClass("sidebar-right-opened"):
                    {
                        $("body").removeClass("sidebar-right-opened");
                        if ($("body").hasClass("boxed")) {
                            $('#right').css('right', '-270px');
                        }
                        break;
                    }
                default:
                    // Open right panel
                    {
                        $("body").addClass("sidebar-right-opened");
                        this.adjust_boxright();
                        $('.navbar-nav>.dropdown').removeClass("open");
                    }
            }
        },
        adjust_boxright: function adjust_boxright() {
            if ($('body').hasClass('boxed') && $("body").hasClass("sidebar-right-opened")) {
                var window_w = $(window).width();
                var body_w = $('body').width();
                var margin_right = (window_w - body_w) / 2;
                $('#right').css('right', margin_right);
            }
        }
    }
});
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(0)))

/***/ }),

/***/ 398:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
    name: "left-side"
});

/***/ }),

/***/ 399:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function($) {Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
    name: "right-side",
    methods: {
        change_skin: function change_skin() {
            var cls = $("input[name='skins']:checked");
            $("body").removeClass("skin-default skin-mint skin-grape skin-lavender skin-pink skin-sunflower").addClass(cls.val());
            $('#skin').appendTo("head").attr('href', '/static/skins/' + cls.val() + '.css');
            $('#slim_t3').find('.setting-color label').removeClass('active-color');
            $(cls).parent("label").addClass('active-color');
        }
    }
});
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(0)))

/***/ }),

/***/ 432:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function($) {Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_layout_clear_header__ = __webpack_require__(754);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_layout_clear_header___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__components_layout_clear_header__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_layout_left_side__ = __webpack_require__(755);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_layout_left_side___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__components_layout_left_side__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__components_layout_right_side__ = __webpack_require__(756);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__components_layout_right_side___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__components_layout_right_side__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__vendors_jquery_nicescroll_jquery_nicescroll_min_js__ = __webpack_require__(467);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__vendors_jquery_nicescroll_jquery_nicescroll_min_js___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__vendors_jquery_nicescroll_jquery_nicescroll_min_js__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_bootstrap_switch__ = __webpack_require__(485);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_bootstrap_switch___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_bootstrap_switch__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_jquery_slimscroll__ = __webpack_require__(737);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_jquery_slimscroll___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_jquery_slimscroll__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__assets_js_metisMenu_js__ = __webpack_require__(441);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__assets_js_metisMenu_js___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6__assets_js_metisMenu_js__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__assets_js_custom_js_leftmenu_js__ = __webpack_require__(438);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__assets_js_custom_js_leftmenu_js___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__assets_js_custom_js_leftmenu_js__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__assets_js_custom_js_rightside_bar_js__ = __webpack_require__(439);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__assets_js_custom_js_rightside_bar_js___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8__assets_js_custom_js_rightside_bar_js__);
//
//
//
//
//
//
//
//
//
//
//
//






__webpack_require__(741);




/* harmony default export */ __webpack_exports__["default"] = ({
    name: 'layout1',
    components: {
        clear_header: __WEBPACK_IMPORTED_MODULE_0__components_layout_clear_header___default.a,
        left_side: __WEBPACK_IMPORTED_MODULE_1__components_layout_left_side___default.a,
        right_side: __WEBPACK_IMPORTED_MODULE_2__components_layout_right_side___default.a
    },
    created: function created() {
        // window.$ = window.jQuery = require('jquery');
    },
    mounted: function mounted() {
        /*
         * Make sure that the sidebar is streched full height
         * ---------------------------------------------
         * We are gonna assign a min-height value every time the
         * wrapper gets resized and upon page load. We will use
         * Ben Alman's method for detecting the resize event.
         *
         **/
        // left full width code start
        function _fix() {
            //Get window height and the wrapper height
            var height = $(window).height() - $("body > .header").height();
            $(".wrapper").css("min-height", height + "px");
            var content = $(".wrapper").height();
            //If the wrapper height is greater than the window
            if ($(window).width() > 992) {
                if ($("body").hasClass("movable-header")) {
                    if (content > height) {
                        //then set sidebar height to the wrapper
                        $(".left-side, html, body").css("min-height", content + "px");
                    } else {
                        //Otherwise, set the sidebar to the height of the window
                        $(".left-side, html, body").css("min-height", height + "px");
                    }
                } else {
                    if (content > height) {
                        //then set sidebar height to the wrapper
                        $(".left-side, html, body").css("min-height", content - 50 + "px");
                    } else {
                        //Otherwise, set the sidebar to the height of the window
                        $(".left-side, html, body").css("min-height", height - 50 + "px");
                    }
                }
            } else {
                if (content > height) {
                    //then set sidebar height to the wrapper
                    $(".left-side, html, body").css("min-height", content + 1 + "px");
                } else {
                    //Otherwise, set the sidebar to the height of the window
                    $(".left-side, html, body").css("min-height", height + 1 + "px");
                }
            }
        }

        //     //Fire upon load Clear
        _fix();
        //     //Fire when wrapper is resized
        $(".wrapper").on('resize', function () {
            _fix();
            fix_sidebar();
        });

        //     //Fix the fixed layout sidebar scroll bug
        fix_sidebar();

        function fix_sidebar() {
            //Make sure the body tag has the .fixed class
            if (!$("body").hasClass("fixed-menu")) {
                return;
            }
            //Add slimscroll
            if ($(window).width() <= 992 && $(window).width() >= 561) {
                $(".left_slim").slimscroll({
                    height: $(window).height() - $(".header").height() + "px",
                    color: "rgba(0,0,0,0.2)"
                });
            } else if ($(window).width() <= 560) {
                $(".left_slim").slimscroll({
                    height: $(window).height() - $(".header").height() + 104 + "px",
                    color: "rgba(0,0,0,0.2)"
                });
            } else {
                $(".left_slim").slimscroll({
                    height: $(window).height() - $(".header>nav").height() + "px",
                    color: "rgba(0,0,0,0.2)"
                });
            }
        }

        // =================nice scroll below 560px for nav dropdown===========//
        function fix_dropdown() {
            if ($(window).height() <= 560) {
                $(".navbar .dropdown .dropdown-menu.dropdown-messages").addClass("nice_dropdown").niceScroll({
                    cursorcolor: "rgba(0,0,0,0)",
                    cursorborder: "none"
                });
            } else {
                $(".navbar .dropdown .dropdown-menu.dropdown-messages").removeClass("nice_dropdown");
            }
        }
        fix_dropdown();
        $(window).on("resize", fix_dropdown);
        // =================nice scroll below 560px for nav dropdown ends===========//

        // left full width code end
        if (!$('#right').length) {
            $('.toggle-right').addClass('hidden');
        }
        $("#slim_t3").find(" [name='my-checkbox']").bootstrapSwitch("size", 'mini');
        //slim scroll for right side bar
        $('#right-slim').slimscroll({
            height: '100vh',
            size: '3px',
            color: '#6699cc',
            opacity: .4
        });
    },
    methods: {
        right_close: function right_close() {
            $("body").removeClass("sidebar-right-opened");
            if ($("body").hasClass("boxed")) {
                $('#right').css('right', '-270px');
            }
        }
    }
});
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(0)))

/***/ }),

/***/ 438:
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function($, jQuery) {//var left_side_width = 220; //Sidebar width in pixels


$(function () {

    //Add hover support for touch devices
    $('.btn').on('touchstart', function () {
        $(this).addClass('hover');
    }).on('touchend', function () {
        $(this).removeClass('hover');
    });

    //Activate tooltips
    $("[data-toggle='tooltip']").tooltip();

    /*
     * ADD SLIMSCROLL TO THE TOP NAV DROPDOWNS
     * ---------------------------------------
     */
    $(".navbar .menu").slimscroll({
        height: "200px",
        alwaysVisible: true,
        size: "3px"
    }).css("width", "100%");

    /*
     * INITIALIZE BUTTON TOGGLE
     * ------------------------
     */

    $('.btn-group[data-toggle="btn-toggle"]').on('each', function () {
        var group = $(this);
        $(this).find(".btn").on('click', function (e) {
            group.find(".btn.active").removeClass("active");
            e.preventDefault();
        });
    });
});
/*END DEMO*/

//  jQuery resize event - v1.1 - 3/14/2010
(function ($, h, c) {
    var a = $([]),
        e = $.resize = $.extend($.resize, {}),
        i,
        k = "setTimeout",
        j = "resize",
        d = j + "-special-event",
        b = "delay",
        f = "throttleWindow";
    e[b] = 250;
    e[f] = true;
    $.event.special[j] = {
        setup: function setup() {
            if (!e[f] && this[k]) {
                return false;
            }
            var l = $(this);
            a = a.add(l);
            $.data(this, d, { w: l.width(), h: l.height() });
            if (a.length === 1) {
                g();
            }
        },
        teardown: function teardown() {
            if (!e[f] && this[k]) {
                return false;
            }
            var l = $(this);
            a = a.not(l);
            l.removeData(d);
            if (!a.length) {
                clearTimeout(i);
            }
        },
        add: function add(l) {
            if (!e[f] && this[k]) {
                return false;
            }
            var n;

            function m(s, o, p) {
                var q = $(this),
                    r = $.data(this, d);
                r.w = o !== c ? o : q.width();
                r.h = p !== c ? p : q.height();
                n.apply(this, arguments);
            }

            if ($.isFunction(l)) {
                n = l;
                return m;
            } else {
                n = l.handler;
                l.handler = m;
            }
        }
    };

    function g() {
        i = setTimeout(function () {
            a.each(function () {
                var n = $(this),
                    m = n.width(),
                    l = n.height(),
                    o = $.data(this, d);
                if (m !== o.w || l !== o.h) {
                    n.trigger(j, [o.w = m, o.h = l]);
                }
            });
            g();
        }, e[b]);
    }
})(jQuery, this);

//Code for collpasing panels

$(document).on('click', '.panel-heading .removepanel', function () {
    var $this = $(this);
    $this.parents('.panel').hide("slow");
});
//panel hide
$('.showhide').attr('title', 'Hide Panel content');
$(document).on('click', '.panel-heading .clickable', function (e) {
    var $this = $(this);
    if (!$this.hasClass('panel-collapsed')) {
        $this.parents('.panel').find('.panel-body').slideUp();
        $this.addClass('panel-collapsed').removeClass('ti-angle-up').addClass('ti-angle-down');
        $('.showhide').attr('title', 'Show Panel content');
    } else {
        $this.parents('.panel').find('.panel-body').slideDown();
        $this.removeClass('panel-collapsed').removeClass('ti-angle-down').addClass('ti-angle-up');
        $('.showhide').attr('title', 'Hide Panel content');
    }
});
//leftmenu init
$(function () {
    $('#menu').metisMenu();
});
//boxed code
$('.boxed .boxedli a').on('click', function () {
    $('body').addClass('container');
});
//fixed top
$('.sub-menu .fixedtop a').on('click', function () {
    $('.navbar').addClass('navbar-fixed-top');
});
//fixedtop and menu
$('.sub-menu .fixedtop-menu a').on('click', function () {
    $('.sidebar').addClass('affix');
    $('.navbar').addClass('navbar-fixed-top');
    $('.content-header').addClass('padding-top');
});
//top color


$('.collapse').on('shown.bs.collapse', function () {
    $(this).parent().find(".glyphicon-plus").removeClass("glyphicon-plus").addClass("glyphicon-minus");
}).on('hidden.bs.collapse', function () {
    $(this).parent().find(".glyphicon-minus").removeClass("glyphicon-minus").addClass("glyphicon-plus");
});
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(0), __webpack_require__(0)))

/***/ }),

/***/ 439:
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(jQuery, $) {

(function (window) {
    // Is Modernizr defined on the global scope
    var Modernizr = typeof Modernizr !== "undefined" ? Modernizr : false,

    // whether or not is a touch device
    isTouchDevice = Modernizr ? Modernizr.touch : !!('ontouchstart' in window || 'onmsgesturechange' in window),

    // Are we expecting a touch or a click?
    buttonPressedEvent = isTouchDevice ? 'touch' : 'click',
        clearui = function clearui() {
        this.init();
    };
    // Initialization method
    clearui.prototype.init = function () {
        this.isTouchDevice = isTouchDevice;
        this.buttonPressedEvent = buttonPressedEvent;
    };
    clearui.prototype.getViewportHeight = function () {
        var docElement = document.documentElement,
            client = docElement.clientHeight,
            inner = window.innerHeight;
        if (client < inner) return inner;else return client;
    };
    clearui.prototype.getViewportWidth = function () {
        var docElement = document.documentElement,
            client = docElement.clientWidth,
            inner = window.innerWidth;
        if (client < inner) return inner;else return client;
    };
    // Creates a clear object.
    window.clearui = new clearui();
})(window);
(function ($) {
    var $navBar = $('nav.navbar'),
        $body = $('body'),
        $menu = $('#menu');

    function getHeight(el) {
        return el.outerHeight();
    }

    function init() {
        var isFixedNav = $navBar.hasClass('navbar-fixed-top');
        var bodyPadTop = isFixedNav ? $navBar.outerHeight(true) : 0;
        $body.css('padding-top', bodyPadTop);
    }

    clearui.navBar = function () {
        var resizeTimer;
        init();
        $(window).on('resize', function () {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(init(), 250);
        });
    };
    return clearui;
})(jQuery);
(function ($, clearui) {
    clearui.clearAnimatePanel = function () {};
    return clearui;
})(jQuery, clearui || {});

(function ($) {
    $(document).ready(function () {
        $('[data-toggle="tooltip"]').tooltip();
        clearui.navBar();
        clearui.clearAnimatePanel();
    });
})(jQuery);

$('.navbar-nav>.dropdown').on('click', function () {
    $('body').removeClass("sidebar-right-opened");
    if ($("body").hasClass("boxed")) {
        $('#right').css('right', '-270px');
    }
});

$(document).ready(function () {

    //=================Preloader===========//
    $(window).on('load', function () {
        $('.preloader img').fadeOut();
        $('.preloader').fadeOut();
    });
    //=================end of Preloader===========//
});
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(0), __webpack_require__(0)))

/***/ }),

/***/ 441:
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(jQuery) {/*
 * metismenu - v1.1.1
 * Easy menu jQuery plugin for Twitter Bootstrap 3
 * https://github.com/onokumus/metisMenu
 *
 * Made by Osman Nuri Okumus
 * Under MIT License
 */
;(function ($, window, document, undefined) {

    var pluginName = "metisMenu",
        defaults = {
        toggle: true,
        doubleTapToGo: false
    };

    function Plugin(element, options) {
        this.element = $(element);
        this.settings = $.extend({}, defaults, options);
        this._defaults = defaults;
        this._name = pluginName;
        this.init();
    }

    Plugin.prototype = {
        init: function init() {

            var $this = this.element,
                $toggle = this.settings.toggle,
                obj = this;

            if (this.isIE() <= 9) {
                $this.find("li.active").has("ul").children("ul").collapse("show");
                $this.find("li").not(".active").has("ul").children("ul").collapse("hide");
            } else {
                $this.find("li.active").has("ul").children("ul").addClass("collapse in");
                $this.find("li").not(".active").has("ul").children("ul").addClass("collapse");
            }

            //add the "doubleTapToGo" class to active items if needed
            if (obj.settings.doubleTapToGo) {
                $this.find("li.active").has("ul").children("a").addClass("doubleTapToGo");
            }

            $this.find("li").has("ul").children("a").on("click" + "." + pluginName, function (e) {
                e.preventDefault();

                //Do we need to enable the double tap
                if (obj.settings.doubleTapToGo) {

                    //if we hit a second time on the link and the href is valid, navigate to that url
                    if (obj.doubleTapToGo($(this)) && $(this).attr("href") !== "#" && $(this).attr("href") !== "") {
                        e.stopPropagation();
                        document.location = $(this).attr("href");
                        return;
                    }
                }

                $(this).parent("li").toggleClass("active").children("ul").collapse("toggle");

                if ($toggle) {
                    $(this).parent("li").siblings().removeClass("active").children("ul.in").collapse("hide");
                }
            });
        },

        isIE: function isIE() {
            //https://gist.github.com/padolsey/527683
            var undef,
                v = 3,
                div = document.createElement("div"),
                all = div.getElementsByTagName("i");

            while (div.innerHTML = "<!--[if gt IE " + ++v + "]><i></i><![endif]-->", all[0]) {
                return v > 4 ? v : undef;
            }
        },

        //Enable the link on the second click.
        doubleTapToGo: function doubleTapToGo(elem) {
            var $this = this.element;

            //if the class "doubleTapToGo" exists, remove it and return
            if (elem.hasClass("doubleTapToGo")) {
                elem.removeClass("doubleTapToGo");
                return true;
            }

            //does not exists, add a new class and return false
            if (elem.parent().children("ul").length) {
                //first remove all other class
                $this.find(".doubleTapToGo").removeClass("doubleTapToGo");
                //add the class on the current element
                elem.addClass("doubleTapToGo");
                return false;
            }
        },

        remove: function remove() {
            this.element.off("." + pluginName);
            this.element.removeData(pluginName);
        }

    };

    $.fn[pluginName] = function (options) {
        this.each(function () {
            var el = $(this);
            if (el.data(pluginName)) {
                el.data(pluginName).remove();
            }
            el.data(pluginName, new Plugin(this, options));
        });
        return this;
    };
})(jQuery, window, document);
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(0)))

/***/ }),

/***/ 467:
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

/* jquery.nicescroll 3.6.0 InuYaksa*2014 MIT http://nicescroll.areaaperta.com */(function (f) {
   true ? !(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(0)], __WEBPACK_AMD_DEFINE_FACTORY__ = (f),
				__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
				(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)) : f(jQuery);
})(function (f) {
  var y = !1,
      D = !1,
      N = 0,
      O = 2E3,
      x = 0,
      H = ["webkit", "ms", "moz", "o"],
      s = window.requestAnimationFrame || !1,
      t = window.cancelAnimationFrame || !1;if (!s) for (var P in H) {
    var E = H[P];s || (s = window[E + "RequestAnimationFrame"]);t || (t = window[E + "CancelAnimationFrame"] || window[E + "CancelRequestAnimationFrame"]);
  }var v = window.MutationObserver || window.WebKitMutationObserver || !1,
      I = { zindex: "auto", cursoropacitymin: 0, cursoropacitymax: 1, cursorcolor: "#424242",
    cursorwidth: "5px", cursorborder: "1px solid #fff", cursorborderradius: "5px", scrollspeed: 60, mousescrollstep: 24, touchbehavior: !1, hwacceleration: !0, usetransition: !0, boxzoom: !1, dblclickzoom: !0, gesturezoom: !0, grabcursorenabled: !0, autohidemode: !0, background: "", iframeautoresize: !0, cursorminheight: 32, preservenativescrolling: !0, railoffset: !1, railhoffset: !1, bouncescroll: !0, spacebarenabled: !0, railpadding: { top: 0, right: 0, left: 0, bottom: 0 }, disableoutline: !0, horizrailenabled: !0, railalign: "right", railvalign: "bottom",
    enabletranslate3d: !0, enablemousewheel: !0, enablekeyboard: !0, smoothscroll: !0, sensitiverail: !0, enablemouselockapi: !0, cursorfixedheight: !1, directionlockdeadzone: 6, hidecursordelay: 400, nativeparentscrolling: !0, enablescrollonselection: !0, overflowx: !0, overflowy: !0, cursordragspeed: .3, rtlmode: "auto", cursordragontouch: !1, oneaxismousemode: "auto", scriptpath: function () {
      var f = document.getElementsByTagName("script"),
          f = f[f.length - 1].src.split("?")[0];return 0 < f.split("/").length ? f.split("/").slice(0, -1).join("/") + "/" : "";
    }(), preventmultitouchscrolling: !0 },
      F = !1,
      Q = function Q() {
    if (F) return F;var f = document.createElement("DIV"),
        c = f.style,
        h = navigator.userAgent,
        m = navigator.platform,
        d = { haspointerlock: "pointerLockElement" in document || "webkitPointerLockElement" in document || "mozPointerLockElement" in document };d.isopera = "opera" in window;d.isopera12 = d.isopera && "getUserMedia" in navigator;d.isoperamini = "[object OperaMini]" === Object.prototype.toString.call(window.operamini);d.isie = "all" in document && "attachEvent" in f && !d.isopera;
    d.isieold = d.isie && !("msInterpolationMode" in c);d.isie7 = d.isie && !d.isieold && (!("documentMode" in document) || 7 == document.documentMode);d.isie8 = d.isie && "documentMode" in document && 8 == document.documentMode;d.isie9 = d.isie && "performance" in window && 9 <= document.documentMode;d.isie10 = d.isie && "performance" in window && 10 == document.documentMode;d.isie11 = "msRequestFullscreen" in f && 11 <= document.documentMode;d.isie9mobile = /iemobile.9/i.test(h);d.isie9mobile && (d.isie9 = !1);d.isie7mobile = !d.isie9mobile && d.isie7 && /iemobile/i.test(h);
    d.ismozilla = "MozAppearance" in c;d.iswebkit = "WebkitAppearance" in c;d.ischrome = "chrome" in window;d.ischrome22 = d.ischrome && d.haspointerlock;d.ischrome26 = d.ischrome && "transition" in c;d.cantouch = "ontouchstart" in document.documentElement || "ontouchstart" in window;d.hasmstouch = window.MSPointerEvent || !1;d.hasw3ctouch = window.PointerEvent || !1;d.ismac = /^mac$/i.test(m);d.isios = d.cantouch && /iphone|ipad|ipod/i.test(m);d.isios4 = d.isios && !("seal" in Object);d.isios7 = d.isios && "webkitHidden" in document;d.isandroid = /android/i.test(h);
    d.haseventlistener = "addEventListener" in f;d.trstyle = !1;d.hastransform = !1;d.hastranslate3d = !1;d.transitionstyle = !1;d.hastransition = !1;d.transitionend = !1;m = ["transform", "msTransform", "webkitTransform", "MozTransform", "OTransform"];for (h = 0; h < m.length; h++) {
      if ("undefined" != typeof c[m[h]]) {
        d.trstyle = m[h];break;
      }
    }d.hastransform = !!d.trstyle;d.hastransform && (c[d.trstyle] = "translate3d(1px,2px,3px)", d.hastranslate3d = /translate3d/.test(c[d.trstyle]));d.transitionstyle = !1;d.prefixstyle = "";d.transitionend = !1;for (var m = "transition webkitTransition msTransition MozTransition OTransition OTransition KhtmlTransition".split(" "), n = " -webkit- -ms- -moz- -o- -o -khtml-".split(" "), p = "transitionend webkitTransitionEnd msTransitionEnd transitionend otransitionend oTransitionEnd KhtmlTransitionEnd".split(" "), h = 0; h < m.length; h++) {
      if (m[h] in c) {
        d.transitionstyle = m[h];d.prefixstyle = n[h];d.transitionend = p[h];break;
      }
    }d.ischrome26 && (d.prefixstyle = n[1]);d.hastransition = d.transitionstyle;a: {
      h = ["-webkit-grab", "-moz-grab", "grab"];if (d.ischrome && !d.ischrome22 || d.isie) h = [];for (m = 0; m < h.length; m++) {
        if (n = h[m], c.cursor = n, c.cursor == n) {
          c = n;break a;
        }
      }c = "url(//mail.google.com/mail/images/2/openhand.cur),n-resize";
    }d.cursorgrabvalue = c;d.hasmousecapture = "setCapture" in f;d.hasMutationObserver = !1 !== v;return F = d;
  },
      R = function R(k, c) {
    function h() {
      var b = a.doc.css(e.trstyle);return b && "matrix" == b.substr(0, 6) ? b.replace(/^.*\((.*)\)$/g, "$1").replace(/px/g, "").split(/, +/) : !1;
    }function m() {
      var b = a.win;if ("zIndex" in b) return b.zIndex();for (; 0 < b.length && 9 != b[0].nodeType;) {
        var g = b.css("zIndex");if (!isNaN(g) && 0 != g) return parseInt(g);b = b.parent();
      }return !1;
    }function d(b, g, q) {
      g = b.css(g);b = parseFloat(g);return isNaN(b) ? (b = w[g] || 0, q = 3 == b ? q ? a.win.outerHeight() - a.win.innerHeight() : a.win.outerWidth() - a.win.innerWidth() : 1, a.isie8 && b && (b += 1), q ? b : 0) : b;
    }function n(b, g, q, c) {
      a._bind(b, g, function (a) {
        a = a ? a : window.event;var c = { original: a, target: a.target || a.srcElement, type: "wheel", deltaMode: "MozMousePixelScroll" == a.type ? 0 : 1, deltaX: 0, deltaZ: 0, preventDefault: function preventDefault() {
            a.preventDefault ? a.preventDefault() : a.returnValue = !1;return !1;
          }, stopImmediatePropagation: function stopImmediatePropagation() {
            a.stopImmediatePropagation ? a.stopImmediatePropagation() : a.cancelBubble = !0;
          } };"mousewheel" == g ? (c.deltaY = -.025 * a.wheelDelta, a.wheelDeltaX && (c.deltaX = -.025 * a.wheelDeltaX)) : c.deltaY = a.detail;return q.call(b, c);
      }, c);
    }function p(b, g, c) {
      var d, e;0 == b.deltaMode ? (d = -Math.floor(a.opt.mousescrollstep / 54 * b.deltaX), e = -Math.floor(a.opt.mousescrollstep / 54 * b.deltaY)) : 1 == b.deltaMode && (d = -Math.floor(b.deltaX * a.opt.mousescrollstep), e = -Math.floor(b.deltaY * a.opt.mousescrollstep));
      g && a.opt.oneaxismousemode && 0 == d && e && (d = e, e = 0, c && (0 > d ? a.getScrollLeft() >= a.page.maxw : 0 >= a.getScrollLeft()) && (e = d, d = 0));d && (a.scrollmom && a.scrollmom.stop(), a.lastdeltax += d, a.debounced("mousewheelx", function () {
        var b = a.lastdeltax;a.lastdeltax = 0;a.rail.drag || a.doScrollLeftBy(b);
      }, 15));if (e) {
        if (a.opt.nativeparentscrolling && c && !a.ispage && !a.zoomactive) if (0 > e) {
          if (a.getScrollTop() >= a.page.maxh) return !0;
        } else if (0 >= a.getScrollTop()) return !0;a.scrollmom && a.scrollmom.stop();a.lastdeltay += e;a.debounced("mousewheely", function () {
          var b = a.lastdeltay;a.lastdeltay = 0;a.rail.drag || a.doScrollBy(b);
        }, 15);
      }b.stopImmediatePropagation();return b.preventDefault();
    }var a = this;this.version = "3.6.0";this.name = "nicescroll";this.me = c;this.opt = { doc: f("body"), win: !1 };f.extend(this.opt, I);this.opt.snapbackspeed = 80;if (k) for (var G in a.opt) {
      "undefined" != typeof k[G] && (a.opt[G] = k[G]);
    }this.iddoc = (this.doc = a.opt.doc) && this.doc[0] ? this.doc[0].id || "" : "";this.ispage = /^BODY|HTML/.test(a.opt.win ? a.opt.win[0].nodeName : this.doc[0].nodeName);this.haswrapper = !1 !== a.opt.win;this.win = a.opt.win || (this.ispage ? f(window) : this.doc);this.docscroll = this.ispage && !this.haswrapper ? f(window) : this.win;this.body = f("body");this.iframe = this.isfixed = this.viewport = !1;this.isiframe = "IFRAME" == this.doc[0].nodeName && "IFRAME" == this.win[0].nodeName;this.istextarea = "TEXTAREA" == this.win[0].nodeName;this.forcescreen = !1;this.canshowonmouseevent = "scroll" != a.opt.autohidemode;this.page = this.view = this.onzoomout = this.onzoomin = this.onscrollcancel = this.onscrollend = this.onscrollstart = this.onclick = this.ongesturezoom = this.onkeypress = this.onmousewheel = this.onmousemove = this.onmouseup = this.onmousedown = !1;this.scroll = { x: 0, y: 0 };this.scrollratio = { x: 0, y: 0 };this.cursorheight = 20;this.scrollvaluemax = 0;this.isrtlmode = "auto" == this.opt.rtlmode ? "rtl" == (this.win[0] == window ? this.body : this.win).css("direction") : !0 === this.opt.rtlmode;this.observerbody = this.observerremover = this.observer = this.scrollmom = this.scrollrunning = !1;do {
      this.id = "ascrail" + O++;
    } while (document.getElementById(this.id));this.hasmousefocus = this.hasfocus = this.zoomactive = this.zoom = this.selectiondrag = this.cursorfreezed = this.cursor = this.rail = !1;this.visibility = !0;this.hidden = this.locked = this.railslocked = !1;this.cursoractive = !0;this.wheelprevented = !1;this.overflowx = a.opt.overflowx;this.overflowy = a.opt.overflowy;this.nativescrollingarea = !1;this.checkarea = 0;this.events = [];this.saved = {};this.delaylist = {};this.synclist = {};this.lastdeltay = this.lastdeltax = 0;this.detected = Q();var e = f.extend({}, this.detected);this.ishwscroll = (this.canhwscroll = e.hastransform && a.opt.hwacceleration) && a.haswrapper;this.hasreversehr = this.isrtlmode && !e.iswebkit;this.istouchcapable = !1;!e.cantouch || e.isios || e.isandroid || !e.iswebkit && !e.ismozilla || (this.istouchcapable = !0, e.cantouch = !1);a.opt.enablemouselockapi || (e.hasmousecapture = !1, e.haspointerlock = !1);this.debounced = function (b, g, c) {
      var d = a.delaylist[b];a.delaylist[b] = g;d || setTimeout(function () {
        var g = a.delaylist[b];a.delaylist[b] = !1;g.call(a);
      }, c);
    };var r = !1;this.synched = function (b, g) {
      a.synclist[b] = g;(function () {
        r || (s(function () {
          r = !1;for (var b in a.synclist) {
            var g = a.synclist[b];g && g.call(a);a.synclist[b] = !1;
          }
        }), r = !0);
      })();return b;
    };this.unsynched = function (b) {
      a.synclist[b] && (a.synclist[b] = !1);
    };this.css = function (b, g) {
      for (var c in g) {
        a.saved.css.push([b, c, b.css(c)]), b.css(c, g[c]);
      }
    };this.scrollTop = function (b) {
      return "undefined" == typeof b ? a.getScrollTop() : a.setScrollTop(b);
    };this.scrollLeft = function (b) {
      return "undefined" == typeof b ? a.getScrollLeft() : a.setScrollLeft(b);
    };var A = function A(a, g, c, d, e, f, h) {
      this.st = a;this.ed = g;this.spd = c;this.p1 = d || 0;this.p2 = e || 1;this.p3 = f || 0;this.p4 = h || 1;this.ts = new Date().getTime();this.df = this.ed - this.st;
    };A.prototype = { B2: function B2(a) {
        return 3 * a * a * (1 - a);
      }, B3: function B3(a) {
        return 3 * a * (1 - a) * (1 - a);
      }, B4: function B4(a) {
        return (1 - a) * (1 - a) * (1 - a);
      }, getNow: function getNow() {
        var a = 1 - (new Date().getTime() - this.ts) / this.spd,
            g = this.B2(a) + this.B3(a) + this.B4(a);return 0 > a ? this.ed : this.st + Math.round(this.df * g);
      }, update: function update(a, g) {
        this.st = this.getNow();this.ed = a;this.spd = g;this.ts = new Date().getTime();this.df = this.ed - this.st;return this;
      } };
    if (this.ishwscroll) {
      this.doc.translate = { x: 0, y: 0, tx: "0px", ty: "0px" };e.hastranslate3d && e.isios && this.doc.css("-webkit-backface-visibility", "hidden");this.getScrollTop = function (b) {
        if (!b) {
          if (b = h()) return 16 == b.length ? -b[13] : -b[5];if (a.timerscroll && a.timerscroll.bz) return a.timerscroll.bz.getNow();
        }return a.doc.translate.y;
      };this.getScrollLeft = function (b) {
        if (!b) {
          if (b = h()) return 16 == b.length ? -b[12] : -b[4];if (a.timerscroll && a.timerscroll.bh) return a.timerscroll.bh.getNow();
        }return a.doc.translate.x;
      };this.notifyScrollEvent = function (a) {
        var g = document.createEvent("UIEvents");g.initUIEvent("scroll", !1, !0, window, 1);g.niceevent = !0;a.dispatchEvent(g);
      };var K = this.isrtlmode ? 1 : -1;e.hastranslate3d && a.opt.enabletranslate3d ? (this.setScrollTop = function (b, g) {
        a.doc.translate.y = b;a.doc.translate.ty = -1 * b + "px";a.doc.css(e.trstyle, "translate3d(" + a.doc.translate.tx + "," + a.doc.translate.ty + ",0px)");g || a.notifyScrollEvent(a.win[0]);
      }, this.setScrollLeft = function (b, g) {
        a.doc.translate.x = b;a.doc.translate.tx = b * K + "px";a.doc.css(e.trstyle, "translate3d(" + a.doc.translate.tx + "," + a.doc.translate.ty + ",0px)");g || a.notifyScrollEvent(a.win[0]);
      }) : (this.setScrollTop = function (b, g) {
        a.doc.translate.y = b;a.doc.translate.ty = -1 * b + "px";a.doc.css(e.trstyle, "translate(" + a.doc.translate.tx + "," + a.doc.translate.ty + ")");g || a.notifyScrollEvent(a.win[0]);
      }, this.setScrollLeft = function (b, g) {
        a.doc.translate.x = b;a.doc.translate.tx = b * K + "px";a.doc.css(e.trstyle, "translate(" + a.doc.translate.tx + "," + a.doc.translate.ty + ")");g || a.notifyScrollEvent(a.win[0]);
      });
    } else this.getScrollTop = function () {
      return a.docscroll.scrollTop();
    }, this.setScrollTop = function (b) {
      return a.docscroll.scrollTop(b);
    }, this.getScrollLeft = function () {
      return a.detected.ismozilla && a.isrtlmode ? Math.abs(a.docscroll.scrollLeft()) : a.docscroll.scrollLeft();
    }, this.setScrollLeft = function (b) {
      return a.docscroll.scrollLeft(a.detected.ismozilla && a.isrtlmode ? -b : b);
    };this.getTarget = function (a) {
      return a ? a.target ? a.target : a.srcElement ? a.srcElement : !1 : !1;
    };this.hasParent = function (a, g) {
      if (!a) return !1;for (var c = a.target || a.srcElement || a || !1; c && c.id != g;) {
        c = c.parentNode || !1;
      }return !1 !== c;
    };var w = { thin: 1, medium: 3, thick: 5 };this.getDocumentScrollOffset = function () {
      return { top: window.pageYOffset || document.documentElement.scrollTop, left: window.pageXOffset || document.documentElement.scrollLeft };
    };this.getOffset = function () {
      if (a.isfixed) {
        var b = a.win.offset(),
            g = a.getDocumentScrollOffset();b.top -= g.top;b.left -= g.left;return b;
      }b = a.win.offset();if (!a.viewport) return b;g = a.viewport.offset();return { top: b.top - g.top, left: b.left - g.left };
    };this.updateScrollBar = function (b) {
      if (a.ishwscroll) a.rail.css({ height: a.win.innerHeight() - (a.opt.railpadding.top + a.opt.railpadding.bottom) }), a.railh && a.railh.css({ width: a.win.innerWidth() - (a.opt.railpadding.left + a.opt.railpadding.right) });else {
        var g = a.getOffset(),
            c = g.top,
            e = g.left - (a.opt.railpadding.left + a.opt.railpadding.right),
            c = c + d(a.win, "border-top-width", !0),
            e = e + (a.rail.align ? a.win.outerWidth() - d(a.win, "border-right-width") - a.rail.width : d(a.win, "border-left-width")),
            f = a.opt.railoffset;f && (f.top && (c += f.top), a.rail.align && f.left && (e += f.left));a.railslocked || a.rail.css({ top: c, left: e, height: (b ? b.h : a.win.innerHeight()) - (a.opt.railpadding.top + a.opt.railpadding.bottom) });a.zoom && a.zoom.css({ top: c + 1, left: 1 == a.rail.align ? e - 20 : e + a.rail.width + 4 });if (a.railh && !a.railslocked) {
          c = g.top;e = g.left;if (f = a.opt.railhoffset) f.top && (c += f.top), f.left && (e += f.left);b = a.railh.align ? c + d(a.win, "border-top-width", !0) + a.win.innerHeight() - a.railh.height : c + d(a.win, "border-top-width", !0);e += d(a.win, "border-left-width");a.railh.css({ top: b - (a.opt.railpadding.top + a.opt.railpadding.bottom), left: e, width: a.railh.width });
        }
      }
    };this.doRailClick = function (b, g, c) {
      var e;a.railslocked || (a.cancelEvent(b), g ? (g = c ? a.doScrollLeft : a.doScrollTop, e = c ? (b.pageX - a.railh.offset().left - a.cursorwidth / 2) * a.scrollratio.x : (b.pageY - a.rail.offset().top - a.cursorheight / 2) * a.scrollratio.y, g(e)) : (g = c ? a.doScrollLeftBy : a.doScrollBy, e = c ? a.scroll.x : a.scroll.y, b = c ? b.pageX - a.railh.offset().left : b.pageY - a.rail.offset().top, c = c ? a.view.w : a.view.h, g(e >= b ? c : -c)));
    };a.hasanimationframe = s;a.hascancelanimationframe = t;a.hasanimationframe ? a.hascancelanimationframe || (t = function t() {
      a.cancelAnimationFrame = !0;
    }) : (s = function s(a) {
      return setTimeout(a, 15 - Math.floor(+new Date() / 1E3) % 16);
    }, t = clearInterval);this.init = function () {
      a.saved.css = [];if (e.isie7mobile || e.isoperamini) return !0;e.hasmstouch && a.css(a.ispage ? f("html") : a.win, { "-ms-touch-action": "none" });a.zindex = "auto";a.zindex = a.ispage || "auto" != a.opt.zindex ? a.opt.zindex : m() || "auto";!a.ispage && "auto" != a.zindex && a.zindex > x && (x = a.zindex);a.isie && 0 == a.zindex && "auto" == a.opt.zindex && (a.zindex = "auto");if (!a.ispage || !e.cantouch && !e.isieold && !e.isie9mobile) {
        var b = a.docscroll;a.ispage && (b = a.haswrapper ? a.win : a.doc);e.isie9mobile || a.css(b, { "overflow-y": "hidden" });a.ispage && e.isie7 && ("BODY" == a.doc[0].nodeName ? a.css(f("html"), { "overflow-y": "hidden" }) : "HTML" == a.doc[0].nodeName && a.css(f("body"), { "overflow-y": "hidden" }));!e.isios || a.ispage || a.haswrapper || a.css(f("body"), { "-webkit-overflow-scrolling": "touch" });var g = f(document.createElement("div"));g.css({ position: "relative", top: 0, "float": "right",
          width: a.opt.cursorwidth, height: "0px", "background-color": a.opt.cursorcolor, border: a.opt.cursorborder, "background-clip": "padding-box", "-webkit-border-radius": a.opt.cursorborderradius, "-moz-border-radius": a.opt.cursorborderradius, "border-radius": a.opt.cursorborderradius });g.hborder = parseFloat(g.outerHeight() - g.innerHeight());g.addClass("nicescroll-cursors");a.cursor = g;var c = f(document.createElement("div"));c.attr("id", a.id);c.addClass("nicescroll-rails nicescroll-rails-vr");var d,
            h,
            k = ["left", "right", "top", "bottom"],
            J;for (J in k) {
          h = k[J], (d = a.opt.railpadding[h]) ? c.css("padding-" + h, d + "px") : a.opt.railpadding[h] = 0;
        }c.append(g);c.width = Math.max(parseFloat(a.opt.cursorwidth), g.outerWidth());c.css({ width: c.width + "px", zIndex: a.zindex, background: a.opt.background, cursor: "default" });c.visibility = !0;c.scrollable = !0;c.align = "left" == a.opt.railalign ? 0 : 1;a.rail = c;g = a.rail.drag = !1;!a.opt.boxzoom || a.ispage || e.isieold || (g = document.createElement("div"), a.bind(g, "click", a.doZoom), a.bind(g, "mouseenter", function () {
          a.zoom.css("opacity", a.opt.cursoropacitymax);
        }), a.bind(g, "mouseleave", function () {
          a.zoom.css("opacity", a.opt.cursoropacitymin);
        }), a.zoom = f(g), a.zoom.css({ cursor: "pointer", "z-index": a.zindex, backgroundImage: "url(" + a.opt.scriptpath + "zoomico.png)", height: 18, width: 18, backgroundPosition: "0px 0px" }), a.opt.dblclickzoom && a.bind(a.win, "dblclick", a.doZoom), e.cantouch && a.opt.gesturezoom && (a.ongesturezoom = function (b) {
          1.5 < b.scale && a.doZoomIn(b);.8 > b.scale && a.doZoomOut(b);return a.cancelEvent(b);
        }, a.bind(a.win, "gestureend", a.ongesturezoom)));
        a.railh = !1;var l;a.opt.horizrailenabled && (a.css(b, { "overflow-x": "hidden" }), g = f(document.createElement("div")), g.css({ position: "absolute", top: 0, height: a.opt.cursorwidth, width: "0px", "background-color": a.opt.cursorcolor, border: a.opt.cursorborder, "background-clip": "padding-box", "-webkit-border-radius": a.opt.cursorborderradius, "-moz-border-radius": a.opt.cursorborderradius, "border-radius": a.opt.cursorborderradius }), e.isieold && g.css({ overflow: "hidden" }), g.wborder = parseFloat(g.outerWidth() - g.innerWidth()), g.addClass("nicescroll-cursors"), a.cursorh = g, l = f(document.createElement("div")), l.attr("id", a.id + "-hr"), l.addClass("nicescroll-rails nicescroll-rails-hr"), l.height = Math.max(parseFloat(a.opt.cursorwidth), g.outerHeight()), l.css({ height: l.height + "px", zIndex: a.zindex, background: a.opt.background }), l.append(g), l.visibility = !0, l.scrollable = !0, l.align = "top" == a.opt.railvalign ? 0 : 1, a.railh = l, a.railh.drag = !1);a.ispage ? (c.css({ position: "fixed", top: "0px", height: "100%" }), c.align ? c.css({ right: "0px" }) : c.css({ left: "0px" }), a.body.append(c), a.railh && (l.css({ position: "fixed", left: "0px", width: "100%" }), l.align ? l.css({ bottom: "0px" }) : l.css({ top: "0px" }), a.body.append(l))) : (a.ishwscroll ? ("static" == a.win.css("position") && a.css(a.win, { position: "relative" }), b = "HTML" == a.win[0].nodeName ? a.body : a.win, f(b).scrollTop(0).scrollLeft(0), a.zoom && (a.zoom.css({ position: "absolute", top: 1, right: 0, "margin-right": c.width + 4 }), b.append(a.zoom)), c.css({ position: "absolute", top: 0 }), c.align ? c.css({ right: 0 }) : c.css({ left: 0 }), b.append(c), l && (l.css({ position: "absolute",
          left: 0, bottom: 0 }), l.align ? l.css({ bottom: 0 }) : l.css({ top: 0 }), b.append(l))) : (a.isfixed = "fixed" == a.win.css("position"), b = a.isfixed ? "fixed" : "absolute", a.isfixed || (a.viewport = a.getViewport(a.win[0])), a.viewport && (a.body = a.viewport, 0 == /fixed|absolute/.test(a.viewport.css("position")) && a.css(a.viewport, { position: "relative" })), c.css({ position: b }), a.zoom && a.zoom.css({ position: b }), a.updateScrollBar(), a.body.append(c), a.zoom && a.body.append(a.zoom), a.railh && (l.css({ position: b }), a.body.append(l))), e.isios && a.css(a.win, { "-webkit-tap-highlight-color": "rgba(0,0,0,0)", "-webkit-touch-callout": "none" }), e.isie && a.opt.disableoutline && a.win.attr("hideFocus", "true"), e.iswebkit && a.opt.disableoutline && a.win.css({ outline: "none" }));!1 === a.opt.autohidemode ? (a.autohidedom = !1, a.rail.css({ opacity: a.opt.cursoropacitymax }), a.railh && a.railh.css({ opacity: a.opt.cursoropacitymax })) : !0 === a.opt.autohidemode || "leave" === a.opt.autohidemode ? (a.autohidedom = f().add(a.rail), e.isie8 && (a.autohidedom = a.autohidedom.add(a.cursor)), a.railh && (a.autohidedom = a.autohidedom.add(a.railh)), a.railh && e.isie8 && (a.autohidedom = a.autohidedom.add(a.cursorh))) : "scroll" == a.opt.autohidemode ? (a.autohidedom = f().add(a.rail), a.railh && (a.autohidedom = a.autohidedom.add(a.railh))) : "cursor" == a.opt.autohidemode ? (a.autohidedom = f().add(a.cursor), a.railh && (a.autohidedom = a.autohidedom.add(a.cursorh))) : "hidden" == a.opt.autohidemode && (a.autohidedom = !1, a.hide(), a.railslocked = !1);if (e.isie9mobile) a.scrollmom = new L(a), a.onmangotouch = function () {
          var b = a.getScrollTop(),
              c = a.getScrollLeft();
          if (b == a.scrollmom.lastscrolly && c == a.scrollmom.lastscrollx) return !0;var g = b - a.mangotouch.sy,
              e = c - a.mangotouch.sx;if (0 != Math.round(Math.sqrt(Math.pow(e, 2) + Math.pow(g, 2)))) {
            var d = 0 > g ? -1 : 1,
                f = 0 > e ? -1 : 1,
                q = +new Date();a.mangotouch.lazy && clearTimeout(a.mangotouch.lazy);80 < q - a.mangotouch.tm || a.mangotouch.dry != d || a.mangotouch.drx != f ? (a.scrollmom.stop(), a.scrollmom.reset(c, b), a.mangotouch.sy = b, a.mangotouch.ly = b, a.mangotouch.sx = c, a.mangotouch.lx = c, a.mangotouch.dry = d, a.mangotouch.drx = f, a.mangotouch.tm = q) : (a.scrollmom.stop(), a.scrollmom.update(a.mangotouch.sx - e, a.mangotouch.sy - g), a.mangotouch.tm = q, g = Math.max(Math.abs(a.mangotouch.ly - b), Math.abs(a.mangotouch.lx - c)), a.mangotouch.ly = b, a.mangotouch.lx = c, 2 < g && (a.mangotouch.lazy = setTimeout(function () {
              a.mangotouch.lazy = !1;a.mangotouch.dry = 0;a.mangotouch.drx = 0;a.mangotouch.tm = 0;a.scrollmom.doMomentum(30);
            }, 100)));
          }
        }, c = a.getScrollTop(), l = a.getScrollLeft(), a.mangotouch = { sy: c, ly: c, dry: 0, sx: l, lx: l, drx: 0, lazy: !1, tm: 0 }, a.bind(a.docscroll, "scroll", a.onmangotouch);else {
          if (e.cantouch || a.istouchcapable || a.opt.touchbehavior || e.hasmstouch) {
            a.scrollmom = new L(a);a.ontouchstart = function (b) {
              if (b.pointerType && 2 != b.pointerType && "touch" != b.pointerType) return !1;a.hasmoving = !1;if (!a.railslocked) {
                var c;if (e.hasmstouch) for (c = b.target ? b.target : !1; c;) {
                  var g = f(c).getNiceScroll();if (0 < g.length && g[0].me == a.me) break;if (0 < g.length) return !1;if ("DIV" == c.nodeName && c.id == a.id) break;c = c.parentNode ? c.parentNode : !1;
                }a.cancelScroll();if ((c = a.getTarget(b)) && /INPUT/i.test(c.nodeName) && /range/i.test(c.type)) return a.stopPropagation(b);
                !("clientX" in b) && "changedTouches" in b && (b.clientX = b.changedTouches[0].clientX, b.clientY = b.changedTouches[0].clientY);a.forcescreen && (g = b, b = { original: b.original ? b.original : b }, b.clientX = g.screenX, b.clientY = g.screenY);a.rail.drag = { x: b.clientX, y: b.clientY, sx: a.scroll.x, sy: a.scroll.y, st: a.getScrollTop(), sl: a.getScrollLeft(), pt: 2, dl: !1 };if (a.ispage || !a.opt.directionlockdeadzone) a.rail.drag.dl = "f";else {
                  var g = f(window).width(),
                      d = f(window).height(),
                      q = Math.max(document.body.scrollWidth, document.documentElement.scrollWidth),
                      h = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight),
                      d = Math.max(0, h - d),
                      g = Math.max(0, q - g);a.rail.drag.ck = !a.rail.scrollable && a.railh.scrollable ? 0 < d ? "v" : !1 : a.rail.scrollable && !a.railh.scrollable ? 0 < g ? "h" : !1 : !1;a.rail.drag.ck || (a.rail.drag.dl = "f");
                }a.opt.touchbehavior && a.isiframe && e.isie && (g = a.win.position(), a.rail.drag.x += g.left, a.rail.drag.y += g.top);a.hasmoving = !1;a.lastmouseup = !1;a.scrollmom.reset(b.clientX, b.clientY);if (!e.cantouch && !this.istouchcapable && !b.pointerType) {
                  if (!c || !/INPUT|SELECT|TEXTAREA/i.test(c.nodeName)) return !a.ispage && e.hasmousecapture && c.setCapture(), a.opt.touchbehavior ? (c.onclick && !c._onclick && (c._onclick = c.onclick, c.onclick = function (b) {
                    if (a.hasmoving) return !1;c._onclick.call(this, b);
                  }), a.cancelEvent(b)) : a.stopPropagation(b);/SUBMIT|CANCEL|BUTTON/i.test(f(c).attr("type")) && (pc = { tg: c, click: !1 }, a.preventclick = pc);
                }
              }
            };a.ontouchend = function (b) {
              if (!a.rail.drag) return !0;if (2 == a.rail.drag.pt) {
                if (b.pointerType && 2 != b.pointerType && "touch" != b.pointerType) return !1;
                a.scrollmom.doMomentum();a.rail.drag = !1;if (a.hasmoving && (a.lastmouseup = !0, a.hideCursor(), e.hasmousecapture && document.releaseCapture(), !e.cantouch)) return a.cancelEvent(b);
              } else if (1 == a.rail.drag.pt) return a.onmouseup(b);
            };var n = a.opt.touchbehavior && a.isiframe && !e.hasmousecapture;a.ontouchmove = function (b, c) {
              if (!a.rail.drag || b.targetTouches && a.opt.preventmultitouchscrolling && 1 < b.targetTouches.length || b.pointerType && 2 != b.pointerType && "touch" != b.pointerType) return !1;if (2 == a.rail.drag.pt) {
                if (e.cantouch && e.isios && "undefined" == typeof b.original) return !0;a.hasmoving = !0;a.preventclick && !a.preventclick.click && (a.preventclick.click = a.preventclick.tg.onclick || !1, a.preventclick.tg.onclick = a.onpreventclick);b = f.extend({ original: b }, b);"changedTouches" in b && (b.clientX = b.changedTouches[0].clientX, b.clientY = b.changedTouches[0].clientY);if (a.forcescreen) {
                  var g = b;b = { original: b.original ? b.original : b };b.clientX = g.screenX;b.clientY = g.screenY;
                }var d,
                    g = d = 0;n && !c && (d = a.win.position(), g = -d.left, d = -d.top);var q = b.clientY + d;d = q - a.rail.drag.y;var h = b.clientX + g,
                    u = h - a.rail.drag.x,
                    k = a.rail.drag.st - d;a.ishwscroll && a.opt.bouncescroll ? 0 > k ? k = Math.round(k / 2) : k > a.page.maxh && (k = a.page.maxh + Math.round((k - a.page.maxh) / 2)) : (0 > k && (q = k = 0), k > a.page.maxh && (k = a.page.maxh, q = 0));var l;a.railh && a.railh.scrollable && (l = a.isrtlmode ? u - a.rail.drag.sl : a.rail.drag.sl - u, a.ishwscroll && a.opt.bouncescroll ? 0 > l ? l = Math.round(l / 2) : l > a.page.maxw && (l = a.page.maxw + Math.round((l - a.page.maxw) / 2)) : (0 > l && (h = l = 0), l > a.page.maxw && (l = a.page.maxw, h = 0)));g = !1;if (a.rail.drag.dl) g = !0, "v" == a.rail.drag.dl ? l = a.rail.drag.sl : "h" == a.rail.drag.dl && (k = a.rail.drag.st);else {
                  d = Math.abs(d);var u = Math.abs(u),
                      z = a.opt.directionlockdeadzone;if ("v" == a.rail.drag.ck) {
                    if (d > z && u <= .3 * d) return a.rail.drag = !1, !0;u > z && (a.rail.drag.dl = "f", f("body").scrollTop(f("body").scrollTop()));
                  } else if ("h" == a.rail.drag.ck) {
                    if (u > z && d <= .3 * u) return a.rail.drag = !1, !0;d > z && (a.rail.drag.dl = "f", f("body").scrollLeft(f("body").scrollLeft()));
                  }
                }a.synched("touchmove", function () {
                  a.rail.drag && 2 == a.rail.drag.pt && (a.prepareTransition && a.prepareTransition(0), a.rail.scrollable && a.setScrollTop(k), a.scrollmom.update(h, q), a.railh && a.railh.scrollable ? (a.setScrollLeft(l), a.showCursor(k, l)) : a.showCursor(k), e.isie10 && document.selection.clear());
                });e.ischrome && a.istouchcapable && (g = !1);if (g) return a.cancelEvent(b);
              } else if (1 == a.rail.drag.pt) return a.onmousemove(b);
            };
          }a.onmousedown = function (b, c) {
            if (!a.rail.drag || 1 == a.rail.drag.pt) {
              if (a.railslocked) return a.cancelEvent(b);a.cancelScroll();a.rail.drag = { x: b.clientX, y: b.clientY, sx: a.scroll.x, sy: a.scroll.y,
                pt: 1, hr: !!c };var g = a.getTarget(b);!a.ispage && e.hasmousecapture && g.setCapture();a.isiframe && !e.hasmousecapture && (a.saved.csspointerevents = a.doc.css("pointer-events"), a.css(a.doc, { "pointer-events": "none" }));a.hasmoving = !1;return a.cancelEvent(b);
            }
          };a.onmouseup = function (b) {
            if (a.rail.drag) {
              if (1 != a.rail.drag.pt) return !0;e.hasmousecapture && document.releaseCapture();a.isiframe && !e.hasmousecapture && a.doc.css("pointer-events", a.saved.csspointerevents);a.rail.drag = !1;a.hasmoving && a.triggerScrollEnd();return a.cancelEvent(b);
            }
          };
          a.onmousemove = function (b) {
            if (a.rail.drag && 1 == a.rail.drag.pt) {
              if (e.ischrome && 0 == b.which) return a.onmouseup(b);a.cursorfreezed = !0;a.hasmoving = !0;if (a.rail.drag.hr) {
                a.scroll.x = a.rail.drag.sx + (b.clientX - a.rail.drag.x);0 > a.scroll.x && (a.scroll.x = 0);var c = a.scrollvaluemaxw;a.scroll.x > c && (a.scroll.x = c);
              } else a.scroll.y = a.rail.drag.sy + (b.clientY - a.rail.drag.y), 0 > a.scroll.y && (a.scroll.y = 0), c = a.scrollvaluemax, a.scroll.y > c && (a.scroll.y = c);a.synched("mousemove", function () {
                a.rail.drag && 1 == a.rail.drag.pt && (a.showCursor(), a.rail.drag.hr ? a.hasreversehr ? a.doScrollLeft(a.scrollvaluemaxw - Math.round(a.scroll.x * a.scrollratio.x), a.opt.cursordragspeed) : a.doScrollLeft(Math.round(a.scroll.x * a.scrollratio.x), a.opt.cursordragspeed) : a.doScrollTop(Math.round(a.scroll.y * a.scrollratio.y), a.opt.cursordragspeed));
              });return a.cancelEvent(b);
            }
          };if (e.cantouch || a.opt.touchbehavior) a.onpreventclick = function (b) {
            if (a.preventclick) return a.preventclick.tg.onclick = a.preventclick.click, a.preventclick = !1, a.cancelEvent(b);
          }, a.bind(a.win, "mousedown", a.ontouchstart), a.onclick = e.isios ? !1 : function (b) {
            return a.lastmouseup ? (a.lastmouseup = !1, a.cancelEvent(b)) : !0;
          }, a.opt.grabcursorenabled && e.cursorgrabvalue && (a.css(a.ispage ? a.doc : a.win, { cursor: e.cursorgrabvalue }), a.css(a.rail, { cursor: e.cursorgrabvalue }));else {
            var p = function p(b) {
              if (a.selectiondrag) {
                if (b) {
                  var c = a.win.outerHeight();b = b.pageY - a.selectiondrag.top;0 < b && b < c && (b = 0);b >= c && (b -= c);a.selectiondrag.df = b;
                }0 != a.selectiondrag.df && (a.doScrollBy(2 * -Math.floor(a.selectiondrag.df / 6)), a.debounced("doselectionscroll", function () {
                  p();
                }, 50));
              }
            };a.hasTextSelected = "getSelection" in document ? function () {
              return 0 < document.getSelection().rangeCount;
            } : "selection" in document ? function () {
              return "None" != document.selection.type;
            } : function () {
              return !1;
            };a.onselectionstart = function (b) {
              a.ispage || (a.selectiondrag = a.win.offset());
            };a.onselectionend = function (b) {
              a.selectiondrag = !1;
            };a.onselectiondrag = function (b) {
              a.selectiondrag && a.hasTextSelected() && a.debounced("selectionscroll", function () {
                p(b);
              }, 250);
            };
          }e.hasw3ctouch ? (a.css(a.rail, { "touch-action": "none" }), a.css(a.cursor, { "touch-action": "none" }), a.bind(a.win, "pointerdown", a.ontouchstart), a.bind(document, "pointerup", a.ontouchend), a.bind(document, "pointermove", a.ontouchmove)) : e.hasmstouch ? (a.css(a.rail, { "-ms-touch-action": "none" }), a.css(a.cursor, { "-ms-touch-action": "none" }), a.bind(a.win, "MSPointerDown", a.ontouchstart), a.bind(document, "MSPointerUp", a.ontouchend), a.bind(document, "MSPointerMove", a.ontouchmove), a.bind(a.cursor, "MSGestureHold", function (a) {
            a.preventDefault();
          }), a.bind(a.cursor, "contextmenu", function (a) {
            a.preventDefault();
          })) : this.istouchcapable && (a.bind(a.win, "touchstart", a.ontouchstart), a.bind(document, "touchend", a.ontouchend), a.bind(document, "touchcancel", a.ontouchend), a.bind(document, "touchmove", a.ontouchmove));if (a.opt.cursordragontouch || !e.cantouch && !a.opt.touchbehavior) a.rail.css({ cursor: "default" }), a.railh && a.railh.css({ cursor: "default" }), a.jqbind(a.rail, "mouseenter", function () {
            if (!a.ispage && !a.win.is(":visible")) return !1;a.canshowonmouseevent && a.showCursor();a.rail.active = !0;
          }), a.jqbind(a.rail, "mouseleave", function () {
            a.rail.active = !1;a.rail.drag || a.hideCursor();
          }), a.opt.sensitiverail && (a.bind(a.rail, "click", function (b) {
            a.doRailClick(b, !1, !1);
          }), a.bind(a.rail, "dblclick", function (b) {
            a.doRailClick(b, !0, !1);
          }), a.bind(a.cursor, "click", function (b) {
            a.cancelEvent(b);
          }), a.bind(a.cursor, "dblclick", function (b) {
            a.cancelEvent(b);
          })), a.railh && (a.jqbind(a.railh, "mouseenter", function () {
            if (!a.ispage && !a.win.is(":visible")) return !1;a.canshowonmouseevent && a.showCursor();a.rail.active = !0;
          }), a.jqbind(a.railh, "mouseleave", function () {
            a.rail.active = !1;a.rail.drag || a.hideCursor();
          }), a.opt.sensitiverail && (a.bind(a.railh, "click", function (b) {
            a.doRailClick(b, !1, !0);
          }), a.bind(a.railh, "dblclick", function (b) {
            a.doRailClick(b, !0, !0);
          }), a.bind(a.cursorh, "click", function (b) {
            a.cancelEvent(b);
          }), a.bind(a.cursorh, "dblclick", function (b) {
            a.cancelEvent(b);
          })));e.cantouch || a.opt.touchbehavior ? (a.bind(e.hasmousecapture ? a.win : document, "mouseup", a.ontouchend), a.bind(document, "mousemove", a.ontouchmove), a.onclick && a.bind(document, "click", a.onclick), a.opt.cursordragontouch && (a.bind(a.cursor, "mousedown", a.onmousedown), a.bind(a.cursor, "mouseup", a.onmouseup), a.cursorh && a.bind(a.cursorh, "mousedown", function (b) {
            a.onmousedown(b, !0);
          }), a.cursorh && a.bind(a.cursorh, "mouseup", a.onmouseup))) : (a.bind(e.hasmousecapture ? a.win : document, "mouseup", a.onmouseup), a.bind(document, "mousemove", a.onmousemove), a.onclick && a.bind(document, "click", a.onclick), a.bind(a.cursor, "mousedown", a.onmousedown), a.bind(a.cursor, "mouseup", a.onmouseup), a.railh && (a.bind(a.cursorh, "mousedown", function (b) {
            a.onmousedown(b, !0);
          }), a.bind(a.cursorh, "mouseup", a.onmouseup)), !a.ispage && a.opt.enablescrollonselection && (a.bind(a.win[0], "mousedown", a.onselectionstart), a.bind(document, "mouseup", a.onselectionend), a.bind(a.cursor, "mouseup", a.onselectionend), a.cursorh && a.bind(a.cursorh, "mouseup", a.onselectionend), a.bind(document, "mousemove", a.onselectiondrag)), a.zoom && (a.jqbind(a.zoom, "mouseenter", function () {
            a.canshowonmouseevent && a.showCursor();a.rail.active = !0;
          }), a.jqbind(a.zoom, "mouseleave", function () {
            a.rail.active = !1;a.rail.drag || a.hideCursor();
          })));a.opt.enablemousewheel && (a.isiframe || a.bind(e.isie && a.ispage ? document : a.win, "mousewheel", a.onmousewheel), a.bind(a.rail, "mousewheel", a.onmousewheel), a.railh && a.bind(a.railh, "mousewheel", a.onmousewheelhr));a.ispage || e.cantouch || /HTML|^BODY/.test(a.win[0].nodeName) || (a.win.attr("tabindex") || a.win.attr({ tabindex: N++ }), a.jqbind(a.win, "focus", function (b) {
            y = a.getTarget(b).id || !0;a.hasfocus = !0;a.canshowonmouseevent && a.noticeCursor();
          }), a.jqbind(a.win, "blur", function (b) {
            y = !1;a.hasfocus = !1;
          }), a.jqbind(a.win, "mouseenter", function (b) {
            D = a.getTarget(b).id || !0;a.hasmousefocus = !0;a.canshowonmouseevent && a.noticeCursor();
          }), a.jqbind(a.win, "mouseleave", function () {
            D = !1;a.hasmousefocus = !1;a.rail.drag || a.hideCursor();
          }));
        }a.onkeypress = function (b) {
          if (a.railslocked && 0 == a.page.maxh) return !0;b = b ? b : window.e;var c = a.getTarget(b);if (c && /INPUT|TEXTAREA|SELECT|OPTION/.test(c.nodeName) && (!c.getAttribute("type") && !c.type || !/submit|button|cancel/i.tp) || f(c).attr("contenteditable")) return !0;
          if (a.hasfocus || a.hasmousefocus && !y || a.ispage && !y && !D) {
            c = b.keyCode;if (a.railslocked && 27 != c) return a.cancelEvent(b);var g = b.ctrlKey || !1,
                d = b.shiftKey || !1,
                e = !1;switch (c) {case 38:case 63233:
                a.doScrollBy(72);e = !0;break;case 40:case 63235:
                a.doScrollBy(-72);e = !0;break;case 37:case 63232:
                a.railh && (g ? a.doScrollLeft(0) : a.doScrollLeftBy(72), e = !0);break;case 39:case 63234:
                a.railh && (g ? a.doScrollLeft(a.page.maxw) : a.doScrollLeftBy(-72), e = !0);break;case 33:case 63276:
                a.doScrollBy(a.view.h);e = !0;break;case 34:case 63277:
                a.doScrollBy(-a.view.h);
                e = !0;break;case 36:case 63273:
                a.railh && g ? a.doScrollPos(0, 0) : a.doScrollTo(0);e = !0;break;case 35:case 63275:
                a.railh && g ? a.doScrollPos(a.page.maxw, a.page.maxh) : a.doScrollTo(a.page.maxh);e = !0;break;case 32:
                a.opt.spacebarenabled && (d ? a.doScrollBy(a.view.h) : a.doScrollBy(-a.view.h), e = !0);break;case 27:
                a.zoomactive && (a.doZoom(), e = !0);}if (e) return a.cancelEvent(b);
          }
        };a.opt.enablekeyboard && a.bind(document, e.isopera && !e.isopera12 ? "keypress" : "keydown", a.onkeypress);a.bind(document, "keydown", function (b) {
          b.ctrlKey && (a.wheelprevented = !0);
        });a.bind(document, "keyup", function (b) {
          b.ctrlKey || (a.wheelprevented = !1);
        });a.bind(window, "blur", function (b) {
          a.wheelprevented = !1;
        });a.bind(window, "resize", a.lazyResize);a.bind(window, "orientationchange", a.lazyResize);a.bind(window, "load", a.lazyResize);if (e.ischrome && !a.ispage && !a.haswrapper) {
          var r = a.win.attr("style"),
              c = parseFloat(a.win.css("width")) + 1;a.win.css("width", c);a.synched("chromefix", function () {
            a.win.attr("style", r);
          });
        }a.onAttributeChange = function (b) {
          a.lazyResize(a.isieold ? 250 : 30);
        };!1 !== v && (a.observerbody = new v(function (b) {
          b.forEach(function (b) {
            if ("attributes" == b.type) return f("body").hasClass("modal-open") ? a.hide() : a.show();
          });if (document.body.scrollHeight != a.page.maxh) return a.lazyResize(30);
        }), a.observerbody.observe(document.body, { childList: !0, subtree: !0, characterData: !1, attributes: !0, attributeFilter: ["class"] }));a.ispage || a.haswrapper || (!1 !== v ? (a.observer = new v(function (b) {
          b.forEach(a.onAttributeChange);
        }), a.observer.observe(a.win[0], { childList: !0, characterData: !1,
          attributes: !0, subtree: !1 }), a.observerremover = new v(function (b) {
          b.forEach(function (b) {
            if (0 < b.removedNodes.length) for (var c in b.removedNodes) {
              if (a && b.removedNodes[c] == a.win[0]) return a.remove();
            }
          });
        }), a.observerremover.observe(a.win[0].parentNode, { childList: !0, characterData: !1, attributes: !1, subtree: !1 })) : (a.bind(a.win, e.isie && !e.isie9 ? "propertychange" : "DOMAttrModified", a.onAttributeChange), e.isie9 && a.win[0].attachEvent("onpropertychange", a.onAttributeChange), a.bind(a.win, "DOMNodeRemoved", function (b) {
          b.target == a.win[0] && a.remove();
        })));!a.ispage && a.opt.boxzoom && a.bind(window, "resize", a.resizeZoom);a.istextarea && a.bind(a.win, "mouseup", a.lazyResize);a.lazyResize(30);
      }if ("IFRAME" == this.doc[0].nodeName) {
        var M = function M() {
          a.iframexd = !1;var b;try {
            b = "contentDocument" in this ? this.contentDocument : this.contentWindow.document;
          } catch (c) {
            a.iframexd = !0, b = !1;
          }if (a.iframexd) return "console" in window && console.log("NiceScroll error: policy restriced iframe"), !0;a.forcescreen = !0;a.isiframe && (a.iframe = { doc: f(b), html: a.doc.contents().find("html")[0],
            body: a.doc.contents().find("body")[0] }, a.getContentSize = function () {
            return { w: Math.max(a.iframe.html.scrollWidth, a.iframe.body.scrollWidth), h: Math.max(a.iframe.html.scrollHeight, a.iframe.body.scrollHeight) };
          }, a.docscroll = f(a.iframe.body));if (!e.isios && a.opt.iframeautoresize && !a.isiframe) {
            a.win.scrollTop(0);a.doc.height("");var g = Math.max(b.getElementsByTagName("html")[0].scrollHeight, b.body.scrollHeight);a.doc.height(g);
          }a.lazyResize(30);e.isie7 && a.css(f(a.iframe.html), { "overflow-y": "hidden" });a.css(f(a.iframe.body), { "overflow-y": "hidden" });e.isios && a.haswrapper && a.css(f(b.body), { "-webkit-transform": "translate3d(0,0,0)" });"contentWindow" in this ? a.bind(this.contentWindow, "scroll", a.onscroll) : a.bind(b, "scroll", a.onscroll);a.opt.enablemousewheel && a.bind(b, "mousewheel", a.onmousewheel);a.opt.enablekeyboard && a.bind(b, e.isopera ? "keypress" : "keydown", a.onkeypress);if (e.cantouch || a.opt.touchbehavior) a.bind(b, "mousedown", a.ontouchstart), a.bind(b, "mousemove", function (b) {
            return a.ontouchmove(b, !0);
          }), a.opt.grabcursorenabled && e.cursorgrabvalue && a.css(f(b.body), { cursor: e.cursorgrabvalue });a.bind(b, "mouseup", a.ontouchend);a.zoom && (a.opt.dblclickzoom && a.bind(b, "dblclick", a.doZoom), a.ongesturezoom && a.bind(b, "gestureend", a.ongesturezoom));
        };this.doc[0].readyState && "complete" == this.doc[0].readyState && setTimeout(function () {
          M.call(a.doc[0], !1);
        }, 500);a.bind(this.doc, "load", M);
      }
    };this.showCursor = function (b, c) {
      a.cursortimeout && (clearTimeout(a.cursortimeout), a.cursortimeout = 0);if (a.rail) {
        a.autohidedom && (a.autohidedom.stop().css({ opacity: a.opt.cursoropacitymax }), a.cursoractive = !0);a.rail.drag && 1 == a.rail.drag.pt || ("undefined" != typeof b && !1 !== b && (a.scroll.y = Math.round(1 * b / a.scrollratio.y)), "undefined" != typeof c && (a.scroll.x = Math.round(1 * c / a.scrollratio.x)));a.cursor.css({ height: a.cursorheight, top: a.scroll.y });if (a.cursorh) {
          var d = a.hasreversehr ? a.scrollvaluemaxw - a.scroll.x : a.scroll.x;!a.rail.align && a.rail.visibility ? a.cursorh.css({ width: a.cursorwidth, left: d + a.rail.width }) : a.cursorh.css({ width: a.cursorwidth, left: d });a.cursoractive = !0;
        }a.zoom && a.zoom.stop().css({ opacity: a.opt.cursoropacitymax });
      }
    };
    this.hideCursor = function (b) {
      a.cursortimeout || !a.rail || !a.autohidedom || a.hasmousefocus && "leave" == a.opt.autohidemode || (a.cursortimeout = setTimeout(function () {
        a.rail.active && a.showonmouseevent || (a.autohidedom.stop().animate({ opacity: a.opt.cursoropacitymin }), a.zoom && a.zoom.stop().animate({ opacity: a.opt.cursoropacitymin }), a.cursoractive = !1);a.cursortimeout = 0;
      }, b || a.opt.hidecursordelay));
    };this.noticeCursor = function (b, c, d) {
      a.showCursor(c, d);a.rail.active || a.hideCursor(b);
    };this.getContentSize = a.ispage ? function () {
      return { w: Math.max(document.body.scrollWidth, document.documentElement.scrollWidth), h: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight) };
    } : a.haswrapper ? function () {
      return { w: a.doc.outerWidth() + parseInt(a.win.css("paddingLeft")) + parseInt(a.win.css("paddingRight")), h: a.doc.outerHeight() + parseInt(a.win.css("paddingTop")) + parseInt(a.win.css("paddingBottom")) };
    } : function () {
      return { w: a.docscroll[0].scrollWidth, h: a.docscroll[0].scrollHeight };
    };this.onResize = function (b, c) {
      if (!a || !a.win) return !1;if (!a.haswrapper && !a.ispage) {
        if ("none" == a.win.css("display")) return a.visibility && a.hideRail().hideRailHr(), !1;a.hidden || a.visibility || a.showRail().showRailHr();
      }var d = a.page.maxh,
          e = a.page.maxw,
          f = a.view.h,
          h = a.view.w;a.view = { w: a.ispage ? a.win.width() : parseInt(a.win[0].clientWidth), h: a.ispage ? a.win.height() : parseInt(a.win[0].clientHeight) };a.page = c ? c : a.getContentSize();a.page.maxh = Math.max(0, a.page.h - a.view.h);a.page.maxw = Math.max(0, a.page.w - a.view.w);if (a.page.maxh == d && a.page.maxw == e && a.view.w == h && a.view.h == f) {
        if (a.ispage) return a;d = a.win.offset();
        if (a.lastposition && (e = a.lastposition, e.top == d.top && e.left == d.left)) return a;a.lastposition = d;
      }0 == a.page.maxh ? (a.hideRail(), a.scrollvaluemax = 0, a.scroll.y = 0, a.scrollratio.y = 0, a.cursorheight = 0, a.setScrollTop(0), a.rail.scrollable = !1) : (a.page.maxh -= a.opt.railpadding.top + a.opt.railpadding.bottom, a.rail.scrollable = !0);0 == a.page.maxw ? (a.hideRailHr(), a.scrollvaluemaxw = 0, a.scroll.x = 0, a.scrollratio.x = 0, a.cursorwidth = 0, a.setScrollLeft(0), a.railh.scrollable = !1) : (a.page.maxw -= a.opt.railpadding.left + a.opt.railpadding.right, a.railh.scrollable = !0);a.railslocked = a.locked || 0 == a.page.maxh && 0 == a.page.maxw;if (a.railslocked) return a.ispage || a.updateScrollBar(a.view), !1;a.hidden || a.visibility ? a.hidden || a.railh.visibility || a.showRailHr() : a.showRail().showRailHr();a.istextarea && a.win.css("resize") && "none" != a.win.css("resize") && (a.view.h -= 20);a.cursorheight = Math.min(a.view.h, Math.round(a.view.h / a.page.h * a.view.h));a.cursorheight = a.opt.cursorfixedheight ? a.opt.cursorfixedheight : Math.max(a.opt.cursorminheight, a.cursorheight);a.cursorwidth = Math.min(a.view.w, Math.round(a.view.w / a.page.w * a.view.w));a.cursorwidth = a.opt.cursorfixedheight ? a.opt.cursorfixedheight : Math.max(a.opt.cursorminheight, a.cursorwidth);a.scrollvaluemax = a.view.h - a.cursorheight - a.cursor.hborder - (a.opt.railpadding.top + a.opt.railpadding.bottom);a.railh && (a.railh.width = 0 < a.page.maxh ? a.view.w - a.rail.width : a.view.w, a.scrollvaluemaxw = a.railh.width - a.cursorwidth - a.cursorh.wborder - (a.opt.railpadding.left + a.opt.railpadding.right));a.ispage || a.updateScrollBar(a.view);a.scrollratio = { x: a.page.maxw / a.scrollvaluemaxw, y: a.page.maxh / a.scrollvaluemax };a.getScrollTop() > a.page.maxh ? a.doScrollTop(a.page.maxh) : (a.scroll.y = Math.round(a.getScrollTop() * (1 / a.scrollratio.y)), a.scroll.x = Math.round(a.getScrollLeft() * (1 / a.scrollratio.x)), a.cursoractive && a.noticeCursor());a.scroll.y && 0 == a.getScrollTop() && a.doScrollTo(Math.floor(a.scroll.y * a.scrollratio.y));return a;
    };this.resize = a.onResize;this.lazyResize = function (b) {
      b = isNaN(b) ? 30 : b;a.debounced("resize", a.resize, b);return a;
    };this.jqbind = function (b, c, d) {
      a.events.push({ e: b, n: c, f: d, q: !0 });f(b).bind(c, d);
    };this.bind = function (b, c, d, f) {
      var h = "jquery" in b ? b[0] : b;"mousewheel" == c ? window.addEventListener || "onwheel" in document ? a._bind(h, "wheel", d, f || !1) : (b = "undefined" != typeof document.onmousewheel ? "mousewheel" : "DOMMouseScroll", n(h, b, d, f || !1), "DOMMouseScroll" == b && n(h, "MozMousePixelScroll", d, f || !1)) : h.addEventListener ? (e.cantouch && /mouseup|mousedown|mousemove/.test(c) && a._bind(h, "mousedown" == c ? "touchstart" : "mouseup" == c ? "touchend" : "touchmove", function (a) {
        if (a.touches) {
          if (2 > a.touches.length) {
            var b = a.touches.length ? a.touches[0] : a;b.original = a;d.call(this, b);
          }
        } else a.changedTouches && (b = a.changedTouches[0], b.original = a, d.call(this, b));
      }, f || !1), a._bind(h, c, d, f || !1), e.cantouch && "mouseup" == c && a._bind(h, "touchcancel", d, f || !1)) : a._bind(h, c, function (b) {
        (b = b || window.event || !1) && b.srcElement && (b.target = b.srcElement);"pageY" in b || (b.pageX = b.clientX + document.documentElement.scrollLeft, b.pageY = b.clientY + document.documentElement.scrollTop);return !1 === d.call(h, b) || !1 === f ? a.cancelEvent(b) : !0;
      });
    };e.haseventlistener ? (this._bind = function (b, c, d, e) {
      a.events.push({ e: b, n: c, f: d, b: e, q: !1 });b.addEventListener(c, d, e || !1);
    }, this.cancelEvent = function (a) {
      if (!a) return !1;a = a.original ? a.original : a;a.preventDefault();a.stopPropagation();a.preventManipulation && a.preventManipulation();return !1;
    }, this.stopPropagation = function (a) {
      if (!a) return !1;a = a.original ? a.original : a;a.stopPropagation();return !1;
    }, this._unbind = function (a, c, d, e) {
      a.removeEventListener(c, d, e);
    }) : (this._bind = function (b, c, d, e) {
      a.events.push({ e: b,
        n: c, f: d, b: e, q: !1 });b.attachEvent ? b.attachEvent("on" + c, d) : b["on" + c] = d;
    }, this.cancelEvent = function (a) {
      a = window.event || !1;if (!a) return !1;a.cancelBubble = !0;a.cancel = !0;return a.returnValue = !1;
    }, this.stopPropagation = function (a) {
      a = window.event || !1;if (!a) return !1;a.cancelBubble = !0;return !1;
    }, this._unbind = function (a, c, d, e) {
      a.detachEvent ? a.detachEvent("on" + c, d) : a["on" + c] = !1;
    });this.unbindAll = function () {
      for (var b = 0; b < a.events.length; b++) {
        var c = a.events[b];c.q ? c.e.unbind(c.n, c.f) : a._unbind(c.e, c.n, c.f, c.b);
      }
    };this.showRail = function () {
      0 == a.page.maxh || !a.ispage && "none" == a.win.css("display") || (a.visibility = !0, a.rail.visibility = !0, a.rail.css("display", "block"));return a;
    };this.showRailHr = function () {
      if (!a.railh) return a;0 == a.page.maxw || !a.ispage && "none" == a.win.css("display") || (a.railh.visibility = !0, a.railh.css("display", "block"));return a;
    };this.hideRail = function () {
      a.visibility = !1;a.rail.visibility = !1;a.rail.css("display", "none");return a;
    };this.hideRailHr = function () {
      if (!a.railh) return a;a.railh.visibility = !1;a.railh.css("display", "none");return a;
    };this.show = function () {
      a.hidden = !1;a.railslocked = !1;return a.showRail().showRailHr();
    };this.hide = function () {
      a.hidden = !0;a.railslocked = !0;return a.hideRail().hideRailHr();
    };this.toggle = function () {
      return a.hidden ? a.show() : a.hide();
    };this.remove = function () {
      a.stop();a.cursortimeout && clearTimeout(a.cursortimeout);a.doZoomOut();a.unbindAll();e.isie9 && a.win[0].detachEvent("onpropertychange", a.onAttributeChange);!1 !== a.observer && a.observer.disconnect();!1 !== a.observerremover && a.observerremover.disconnect();
      !1 !== a.observerbody && a.observerbody.disconnect();a.events = null;a.cursor && a.cursor.remove();a.cursorh && a.cursorh.remove();a.rail && a.rail.remove();a.railh && a.railh.remove();a.zoom && a.zoom.remove();for (var b = 0; b < a.saved.css.length; b++) {
        var c = a.saved.css[b];c[0].css(c[1], "undefined" == typeof c[2] ? "" : c[2]);
      }a.saved = !1;a.me.data("__nicescroll", "");var d = f.nicescroll;d.each(function (b) {
        if (this && this.id === a.id) {
          delete d[b];for (var c = ++b; c < d.length; c++, b++) {
            d[b] = d[c];
          }d.length--;d.length && delete d[d.length];
        }
      });
      for (var h in a) {
        a[h] = null, delete a[h];
      }a = null;
    };this.scrollstart = function (b) {
      this.onscrollstart = b;return a;
    };this.scrollend = function (b) {
      this.onscrollend = b;return a;
    };this.scrollcancel = function (b) {
      this.onscrollcancel = b;return a;
    };this.zoomin = function (b) {
      this.onzoomin = b;return a;
    };this.zoomout = function (b) {
      this.onzoomout = b;return a;
    };this.isScrollable = function (a) {
      a = a.target ? a.target : a;if ("OPTION" == a.nodeName) return !0;for (; a && 1 == a.nodeType && !/^BODY|HTML/.test(a.nodeName);) {
        var c = f(a),
            c = c.css("overflowY") || c.css("overflowX") || c.css("overflow") || "";if (/scroll|auto/.test(c)) return a.clientHeight != a.scrollHeight;a = a.parentNode ? a.parentNode : !1;
      }return !1;
    };this.getViewport = function (a) {
      for (a = a && a.parentNode ? a.parentNode : !1; a && 1 == a.nodeType && !/^BODY|HTML/.test(a.nodeName);) {
        var c = f(a);if (/fixed|absolute/.test(c.css("position"))) return c;var d = c.css("overflowY") || c.css("overflowX") || c.css("overflow") || "";if (/scroll|auto/.test(d) && a.clientHeight != a.scrollHeight || 0 < c.getNiceScroll().length) return c;a = a.parentNode ? a.parentNode : !1;
      }return !1;
    };
    this.triggerScrollEnd = function () {
      if (a.onscrollend) {
        var b = a.getScrollLeft(),
            c = a.getScrollTop();a.onscrollend.call(a, { type: "scrollend", current: { x: b, y: c }, end: { x: b, y: c } });
      }
    };this.onmousewheel = function (b) {
      if (!a.wheelprevented) {
        if (a.railslocked) return a.debounced("checkunlock", a.resize, 250), !0;if (a.rail.drag) return a.cancelEvent(b);"auto" == a.opt.oneaxismousemode && 0 != b.deltaX && (a.opt.oneaxismousemode = !1);if (a.opt.oneaxismousemode && 0 == b.deltaX && !a.rail.scrollable) return a.railh && a.railh.scrollable ? a.onmousewheelhr(b) : !0;var c = +new Date(),
            d = !1;a.opt.preservenativescrolling && a.checkarea + 600 < c && (a.nativescrollingarea = a.isScrollable(b), d = !0);a.checkarea = c;if (a.nativescrollingarea) return !0;if (b = p(b, !1, d)) a.checkarea = 0;return b;
      }
    };this.onmousewheelhr = function (b) {
      if (!a.wheelprevented) {
        if (a.railslocked || !a.railh.scrollable) return !0;if (a.rail.drag) return a.cancelEvent(b);var c = +new Date(),
            d = !1;a.opt.preservenativescrolling && a.checkarea + 600 < c && (a.nativescrollingarea = a.isScrollable(b), d = !0);a.checkarea = c;return a.nativescrollingarea ? !0 : a.railslocked ? a.cancelEvent(b) : p(b, !0, d);
      }
    };this.stop = function () {
      a.cancelScroll();a.scrollmon && a.scrollmon.stop();a.cursorfreezed = !1;a.scroll.y = Math.round(a.getScrollTop() * (1 / a.scrollratio.y));a.noticeCursor();return a;
    };this.getTransitionSpeed = function (b) {
      var c = Math.round(10 * a.opt.scrollspeed);b = Math.min(c, Math.round(b / 20 * a.opt.scrollspeed));return 20 < b ? b : 0;
    };a.opt.smoothscroll ? a.ishwscroll && e.hastransition && a.opt.usetransition && a.opt.smoothscroll ? (this.prepareTransition = function (b, c) {
      var d = c ? 20 < b ? b : 0 : a.getTransitionSpeed(b),
          f = d ? e.prefixstyle + "transform " + d + "ms ease-out" : "";a.lasttransitionstyle && a.lasttransitionstyle == f || (a.lasttransitionstyle = f, a.doc.css(e.transitionstyle, f));return d;
    }, this.doScrollLeft = function (b, c) {
      var d = a.scrollrunning ? a.newscrolly : a.getScrollTop();a.doScrollPos(b, d, c);
    }, this.doScrollTop = function (b, c) {
      var d = a.scrollrunning ? a.newscrollx : a.getScrollLeft();a.doScrollPos(d, b, c);
    }, this.doScrollPos = function (b, c, d) {
      var f = a.getScrollTop(),
          h = a.getScrollLeft();(0 > (a.newscrolly - f) * (c - f) || 0 > (a.newscrollx - h) * (b - h)) && a.cancelScroll();0 == a.opt.bouncescroll && (0 > c ? c = 0 : c > a.page.maxh && (c = a.page.maxh), 0 > b ? b = 0 : b > a.page.maxw && (b = a.page.maxw));if (a.scrollrunning && b == a.newscrollx && c == a.newscrolly) return !1;a.newscrolly = c;a.newscrollx = b;a.newscrollspeed = d || !1;if (a.timer) return !1;a.timer = setTimeout(function () {
        var d = a.getScrollTop(),
            f = a.getScrollLeft(),
            h,
            k;h = b - f;k = c - d;h = Math.round(Math.sqrt(Math.pow(h, 2) + Math.pow(k, 2)));h = a.newscrollspeed && 1 < a.newscrollspeed ? a.newscrollspeed : a.getTransitionSpeed(h);
        a.newscrollspeed && 1 >= a.newscrollspeed && (h *= a.newscrollspeed);a.prepareTransition(h, !0);a.timerscroll && a.timerscroll.tm && clearInterval(a.timerscroll.tm);0 < h && (!a.scrollrunning && a.onscrollstart && a.onscrollstart.call(a, { type: "scrollstart", current: { x: f, y: d }, request: { x: b, y: c }, end: { x: a.newscrollx, y: a.newscrolly }, speed: h }), e.transitionend ? a.scrollendtrapped || (a.scrollendtrapped = !0, a.bind(a.doc, e.transitionend, a.onScrollTransitionEnd, !1)) : (a.scrollendtrapped && clearTimeout(a.scrollendtrapped), a.scrollendtrapped = setTimeout(a.onScrollTransitionEnd, h)), a.timerscroll = { bz: new A(d, a.newscrolly, h, 0, 0, .58, 1), bh: new A(f, a.newscrollx, h, 0, 0, .58, 1) }, a.cursorfreezed || (a.timerscroll.tm = setInterval(function () {
          a.showCursor(a.getScrollTop(), a.getScrollLeft());
        }, 60)));a.synched("doScroll-set", function () {
          a.timer = 0;a.scrollendtrapped && (a.scrollrunning = !0);a.setScrollTop(a.newscrolly);a.setScrollLeft(a.newscrollx);if (!a.scrollendtrapped) a.onScrollTransitionEnd();
        });
      }, 50);
    }, this.cancelScroll = function () {
      if (!a.scrollendtrapped) return !0;
      var b = a.getScrollTop(),
          c = a.getScrollLeft();a.scrollrunning = !1;e.transitionend || clearTimeout(e.transitionend);a.scrollendtrapped = !1;a._unbind(a.doc[0], e.transitionend, a.onScrollTransitionEnd);a.prepareTransition(0);a.setScrollTop(b);a.railh && a.setScrollLeft(c);a.timerscroll && a.timerscroll.tm && clearInterval(a.timerscroll.tm);a.timerscroll = !1;a.cursorfreezed = !1;a.showCursor(b, c);return a;
    }, this.onScrollTransitionEnd = function () {
      a.scrollendtrapped && a._unbind(a.doc[0], e.transitionend, a.onScrollTransitionEnd);
      a.scrollendtrapped = !1;a.prepareTransition(0);a.timerscroll && a.timerscroll.tm && clearInterval(a.timerscroll.tm);a.timerscroll = !1;var b = a.getScrollTop(),
          c = a.getScrollLeft();a.setScrollTop(b);a.railh && a.setScrollLeft(c);a.noticeCursor(!1, b, c);a.cursorfreezed = !1;0 > b ? b = 0 : b > a.page.maxh && (b = a.page.maxh);0 > c ? c = 0 : c > a.page.maxw && (c = a.page.maxw);if (b != a.newscrolly || c != a.newscrollx) return a.doScrollPos(c, b, a.opt.snapbackspeed);a.onscrollend && a.scrollrunning && a.triggerScrollEnd();a.scrollrunning = !1;
    }) : (this.doScrollLeft = function (b, c) {
      var d = a.scrollrunning ? a.newscrolly : a.getScrollTop();a.doScrollPos(b, d, c);
    }, this.doScrollTop = function (b, c) {
      var d = a.scrollrunning ? a.newscrollx : a.getScrollLeft();a.doScrollPos(d, b, c);
    }, this.doScrollPos = function (b, c, d) {
      function e() {
        if (a.cancelAnimationFrame) return !0;a.scrollrunning = !0;if (n = 1 - n) return a.timer = s(e) || 1;var b = 0,
            c,
            d,
            g = d = a.getScrollTop();if (a.dst.ay) {
          g = a.bzscroll ? a.dst.py + a.bzscroll.getNow() * a.dst.ay : a.newscrolly;c = g - d;if (0 > c && g < a.newscrolly || 0 < c && g > a.newscrolly) g = a.newscrolly;
          a.setScrollTop(g);g == a.newscrolly && (b = 1);
        } else b = 1;d = c = a.getScrollLeft();if (a.dst.ax) {
          d = a.bzscroll ? a.dst.px + a.bzscroll.getNow() * a.dst.ax : a.newscrollx;c = d - c;if (0 > c && d < a.newscrollx || 0 < c && d > a.newscrollx) d = a.newscrollx;a.setScrollLeft(d);d == a.newscrollx && (b += 1);
        } else b += 1;2 == b ? (a.timer = 0, a.cursorfreezed = !1, a.bzscroll = !1, a.scrollrunning = !1, 0 > g ? g = 0 : g > a.page.maxh && (g = a.page.maxh), 0 > d ? d = 0 : d > a.page.maxw && (d = a.page.maxw), d != a.newscrollx || g != a.newscrolly ? a.doScrollPos(d, g) : a.onscrollend && a.triggerScrollEnd()) : a.timer = s(e) || 1;
      }c = "undefined" == typeof c || !1 === c ? a.getScrollTop(!0) : c;if (a.timer && a.newscrolly == c && a.newscrollx == b) return !0;a.timer && t(a.timer);a.timer = 0;var f = a.getScrollTop(),
          h = a.getScrollLeft();(0 > (a.newscrolly - f) * (c - f) || 0 > (a.newscrollx - h) * (b - h)) && a.cancelScroll();a.newscrolly = c;a.newscrollx = b;a.bouncescroll && a.rail.visibility || (0 > a.newscrolly ? a.newscrolly = 0 : a.newscrolly > a.page.maxh && (a.newscrolly = a.page.maxh));a.bouncescroll && a.railh.visibility || (0 > a.newscrollx ? a.newscrollx = 0 : a.newscrollx > a.page.maxw && (a.newscrollx = a.page.maxw));a.dst = {};a.dst.x = b - h;a.dst.y = c - f;a.dst.px = h;a.dst.py = f;var k = Math.round(Math.sqrt(Math.pow(a.dst.x, 2) + Math.pow(a.dst.y, 2)));a.dst.ax = a.dst.x / k;a.dst.ay = a.dst.y / k;var l = 0,
          m = k;0 == a.dst.x ? (l = f, m = c, a.dst.ay = 1, a.dst.py = 0) : 0 == a.dst.y && (l = h, m = b, a.dst.ax = 1, a.dst.px = 0);k = a.getTransitionSpeed(k);d && 1 >= d && (k *= d);a.bzscroll = 0 < k ? a.bzscroll ? a.bzscroll.update(m, k) : new A(l, m, k, 0, 1, 0, 1) : !1;if (!a.timer) {
        (f == a.page.maxh && c >= a.page.maxh || h == a.page.maxw && b >= a.page.maxw) && a.checkContentSize();
        var n = 1;a.cancelAnimationFrame = !1;a.timer = 1;a.onscrollstart && !a.scrollrunning && a.onscrollstart.call(a, { type: "scrollstart", current: { x: h, y: f }, request: { x: b, y: c }, end: { x: a.newscrollx, y: a.newscrolly }, speed: k });e();(f == a.page.maxh && c >= f || h == a.page.maxw && b >= h) && a.checkContentSize();a.noticeCursor();
      }
    }, this.cancelScroll = function () {
      a.timer && t(a.timer);a.timer = 0;a.bzscroll = !1;a.scrollrunning = !1;return a;
    }) : (this.doScrollLeft = function (b, c) {
      var d = a.getScrollTop();a.doScrollPos(b, d, c);
    }, this.doScrollTop = function (b, c) {
      var d = a.getScrollLeft();a.doScrollPos(d, b, c);
    }, this.doScrollPos = function (b, c, d) {
      var e = b > a.page.maxw ? a.page.maxw : b;0 > e && (e = 0);var f = c > a.page.maxh ? a.page.maxh : c;0 > f && (f = 0);a.synched("scroll", function () {
        a.setScrollTop(f);a.setScrollLeft(e);
      });
    }, this.cancelScroll = function () {});this.doScrollBy = function (b, c) {
      var d = 0,
          d = c ? Math.floor((a.scroll.y - b) * a.scrollratio.y) : (a.timer ? a.newscrolly : a.getScrollTop(!0)) - b;if (a.bouncescroll) {
        var e = Math.round(a.view.h / 2);d < -e ? d = -e : d > a.page.maxh + e && (d = a.page.maxh + e);
      }a.cursorfreezed = !1;e = a.getScrollTop(!0);if (0 > d && 0 >= e) return a.noticeCursor();if (d > a.page.maxh && e >= a.page.maxh) return a.checkContentSize(), a.noticeCursor();a.doScrollTop(d);
    };this.doScrollLeftBy = function (b, c) {
      var d = 0,
          d = c ? Math.floor((a.scroll.x - b) * a.scrollratio.x) : (a.timer ? a.newscrollx : a.getScrollLeft(!0)) - b;if (a.bouncescroll) {
        var e = Math.round(a.view.w / 2);d < -e ? d = -e : d > a.page.maxw + e && (d = a.page.maxw + e);
      }a.cursorfreezed = !1;e = a.getScrollLeft(!0);if (0 > d && 0 >= e || d > a.page.maxw && e >= a.page.maxw) return a.noticeCursor();a.doScrollLeft(d);
    };
    this.doScrollTo = function (b, c) {
      c && Math.round(b * a.scrollratio.y);a.cursorfreezed = !1;a.doScrollTop(b);
    };this.checkContentSize = function () {
      var b = a.getContentSize();b.h == a.page.h && b.w == a.page.w || a.resize(!1, b);
    };a.onscroll = function (b) {
      a.rail.drag || a.cursorfreezed || a.synched("scroll", function () {
        a.scroll.y = Math.round(a.getScrollTop() * (1 / a.scrollratio.y));a.railh && (a.scroll.x = Math.round(a.getScrollLeft() * (1 / a.scrollratio.x)));a.noticeCursor();
      });
    };a.bind(a.docscroll, "scroll", a.onscroll);this.doZoomIn = function (b) {
      if (!a.zoomactive) {
        a.zoomactive = !0;a.zoomrestore = { style: {} };var c = "position top left zIndex backgroundColor marginTop marginBottom marginLeft marginRight".split(" "),
            d = a.win[0].style,
            h;for (h in c) {
          var k = c[h];a.zoomrestore.style[k] = "undefined" != typeof d[k] ? d[k] : "";
        }a.zoomrestore.style.width = a.win.css("width");a.zoomrestore.style.height = a.win.css("height");a.zoomrestore.padding = { w: a.win.outerWidth() - a.win.width(), h: a.win.outerHeight() - a.win.height() };e.isios4 && (a.zoomrestore.scrollTop = f(window).scrollTop(), f(window).scrollTop(0));
        a.win.css({ position: e.isios4 ? "absolute" : "fixed", top: 0, left: 0, "z-index": x + 100, margin: "0px" });c = a.win.css("backgroundColor");("" == c || /transparent|rgba\(0, 0, 0, 0\)|rgba\(0,0,0,0\)/.test(c)) && a.win.css("backgroundColor", "#fff");a.rail.css({ "z-index": x + 101 });a.zoom.css({ "z-index": x + 102 });a.zoom.css("backgroundPosition", "0px -18px");a.resizeZoom();a.onzoomin && a.onzoomin.call(a);return a.cancelEvent(b);
      }
    };this.doZoomOut = function (b) {
      if (a.zoomactive) return a.zoomactive = !1, a.win.css("margin", ""), a.win.css(a.zoomrestore.style), e.isios4 && f(window).scrollTop(a.zoomrestore.scrollTop), a.rail.css({ "z-index": a.zindex }), a.zoom.css({ "z-index": a.zindex }), a.zoomrestore = !1, a.zoom.css("backgroundPosition", "0px 0px"), a.onResize(), a.onzoomout && a.onzoomout.call(a), a.cancelEvent(b);
    };this.doZoom = function (b) {
      return a.zoomactive ? a.doZoomOut(b) : a.doZoomIn(b);
    };this.resizeZoom = function () {
      if (a.zoomactive) {
        var b = a.getScrollTop();a.win.css({ width: f(window).width() - a.zoomrestore.padding.w + "px", height: f(window).height() - a.zoomrestore.padding.h + "px" });
        a.onResize();a.setScrollTop(Math.min(a.page.maxh, b));
      }
    };this.init();f.nicescroll.push(this);
  },
      L = function L(f) {
    var c = this;this.nc = f;this.steptime = this.lasttime = this.speedy = this.speedx = this.lasty = this.lastx = 0;this.snapy = this.snapx = !1;this.demuly = this.demulx = 0;this.lastscrolly = this.lastscrollx = -1;this.timer = this.chky = this.chkx = 0;this.time = function () {
      return +new Date();
    };this.reset = function (f, k) {
      c.stop();var d = c.time();c.steptime = 0;c.lasttime = d;c.speedx = 0;c.speedy = 0;c.lastx = f;c.lasty = k;c.lastscrollx = -1;c.lastscrolly = -1;
    };this.update = function (f, k) {
      var d = c.time();c.steptime = d - c.lasttime;c.lasttime = d;var d = k - c.lasty,
          n = f - c.lastx,
          p = c.nc.getScrollTop(),
          a = c.nc.getScrollLeft(),
          p = p + d,
          a = a + n;c.snapx = 0 > a || a > c.nc.page.maxw;c.snapy = 0 > p || p > c.nc.page.maxh;c.speedx = n;c.speedy = d;c.lastx = f;c.lasty = k;
    };this.stop = function () {
      c.nc.unsynched("domomentum2d");c.timer && clearTimeout(c.timer);c.timer = 0;c.lastscrollx = -1;c.lastscrolly = -1;
    };this.doSnapy = function (f, k) {
      var d = !1;0 > k ? (k = 0, d = !0) : k > c.nc.page.maxh && (k = c.nc.page.maxh, d = !0);0 > f ? (f = 0, d = !0) : f > c.nc.page.maxw && (f = c.nc.page.maxw, d = !0);d ? c.nc.doScrollPos(f, k, c.nc.opt.snapbackspeed) : c.nc.triggerScrollEnd();
    };this.doMomentum = function (f) {
      var k = c.time(),
          d = f ? k + f : c.lasttime;f = c.nc.getScrollLeft();var n = c.nc.getScrollTop(),
          p = c.nc.page.maxh,
          a = c.nc.page.maxw;c.speedx = 0 < a ? Math.min(60, c.speedx) : 0;c.speedy = 0 < p ? Math.min(60, c.speedy) : 0;d = d && 60 >= k - d;if (0 > n || n > p || 0 > f || f > a) d = !1;f = c.speedx && d ? c.speedx : !1;if (c.speedy && d && c.speedy || f) {
        var s = Math.max(16, c.steptime);50 < s && (f = s / 50, c.speedx *= f, c.speedy *= f, s = 50);c.demulxy = 0;c.lastscrollx = c.nc.getScrollLeft();c.chkx = c.lastscrollx;c.lastscrolly = c.nc.getScrollTop();c.chky = c.lastscrolly;var e = c.lastscrollx,
            r = c.lastscrolly,
            t = function t() {
          var d = 600 < c.time() - k ? .04 : .02;c.speedx && (e = Math.floor(c.lastscrollx - c.speedx * (1 - c.demulxy)), c.lastscrollx = e, 0 > e || e > a) && (d = .1);c.speedy && (r = Math.floor(c.lastscrolly - c.speedy * (1 - c.demulxy)), c.lastscrolly = r, 0 > r || r > p) && (d = .1);c.demulxy = Math.min(1, c.demulxy + d);c.nc.synched("domomentum2d", function () {
            c.speedx && (c.nc.getScrollLeft() != c.chkx && c.stop(), c.chkx = e, c.nc.setScrollLeft(e));c.speedy && (c.nc.getScrollTop() != c.chky && c.stop(), c.chky = r, c.nc.setScrollTop(r));c.timer || (c.nc.hideCursor(), c.doSnapy(e, r));
          });1 > c.demulxy ? c.timer = setTimeout(t, s) : (c.stop(), c.nc.hideCursor(), c.doSnapy(e, r));
        };t();
      } else c.doSnapy(c.nc.getScrollLeft(), c.nc.getScrollTop());
    };
  },
      w = f.fn.scrollTop;f.cssHooks.pageYOffset = { get: function get(k, c, h) {
      return (c = f.data(k, "__nicescroll") || !1) && c.ishwscroll ? c.getScrollTop() : w.call(k);
    }, set: function set(k, c) {
      var h = f.data(k, "__nicescroll") || !1;h && h.ishwscroll ? h.setScrollTop(parseInt(c)) : w.call(k, c);return this;
    } };f.fn.scrollTop = function (k) {
    if ("undefined" == typeof k) {
      var c = this[0] ? f.data(this[0], "__nicescroll") || !1 : !1;return c && c.ishwscroll ? c.getScrollTop() : w.call(this);
    }return this.each(function () {
      var c = f.data(this, "__nicescroll") || !1;c && c.ishwscroll ? c.setScrollTop(parseInt(k)) : w.call(f(this), k);
    });
  };var B = f.fn.scrollLeft;f.cssHooks.pageXOffset = { get: function get(k, c, h) {
      return (c = f.data(k, "__nicescroll") || !1) && c.ishwscroll ? c.getScrollLeft() : B.call(k);
    },
    set: function set(k, c) {
      var h = f.data(k, "__nicescroll") || !1;h && h.ishwscroll ? h.setScrollLeft(parseInt(c)) : B.call(k, c);return this;
    } };f.fn.scrollLeft = function (k) {
    if ("undefined" == typeof k) {
      var c = this[0] ? f.data(this[0], "__nicescroll") || !1 : !1;return c && c.ishwscroll ? c.getScrollLeft() : B.call(this);
    }return this.each(function () {
      var c = f.data(this, "__nicescroll") || !1;c && c.ishwscroll ? c.setScrollLeft(parseInt(k)) : B.call(f(this), k);
    });
  };var C = function C(k) {
    var c = this;this.length = 0;this.name = "nicescrollarray";this.each = function (d) {
      for (var f = 0, h = 0; f < c.length; f++) {
        d.call(c[f], h++);
      }return c;
    };this.push = function (d) {
      c[c.length] = d;c.length++;
    };this.eq = function (d) {
      return c[d];
    };if (k) for (var h = 0; h < k.length; h++) {
      var m = f.data(k[h], "__nicescroll") || !1;m && (this[this.length] = m, this.length++);
    }return this;
  };(function (f, c, h) {
    for (var m = 0; m < c.length; m++) {
      h(f, c[m]);
    }
  })(C.prototype, "show hide toggle onResize resize remove stop doScrollPos".split(" "), function (f, c) {
    f[c] = function () {
      var f = arguments;return this.each(function () {
        this[c].apply(this, f);
      });
    };
  });f.fn.getNiceScroll = function (k) {
    return "undefined" == typeof k ? new C(this) : this[k] && f.data(this[k], "__nicescroll") || !1;
  };f.extend(f.expr[":"], { nicescroll: function nicescroll(k) {
      return f.data(k, "__nicescroll") ? !0 : !1;
    } });f.fn.niceScroll = function (k, c) {
    "undefined" != typeof c || "object" != (typeof k === "undefined" ? "undefined" : _typeof(k)) || "jquery" in k || (c = k, k = !1);c = f.extend({}, c);var h = new C();"undefined" == typeof c && (c = {});k && (c.doc = f(k), c.win = f(this));var m = !("doc" in c);m || "win" in c || (c.win = f(this));this.each(function () {
      var d = f(this).data("__nicescroll") || !1;d || (c.doc = m ? f(this) : c.doc, d = new R(c, f(this)), f(this).data("__nicescroll", d));h.push(d);
    });return 1 == h.length ? h[0] : h;
  };window.NiceScroll = { getjQuery: function getjQuery() {
      return f;
    } };f.nicescroll || (f.nicescroll = new C(), f.nicescroll.options = I);
});

/***/ }),

/***/ 485:
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(__webpack_provided_window_dot_jQuery) {/**
  * bootstrap-switch - Turn checkboxes and radio buttons into toggle switches.
  *
  * @version v3.3.3
  * @homepage http://www.bootstrap-switch.org
  * @author Mattia Larentis <mattia@larentis.eu> (http://larentis.eu)
  * @license Apache-2.0
  */



var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function ($, window) {
  var BootstrapSwitch = function () {
    function BootstrapSwitch(element) {
      var _this = this;

      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      _classCallCheck(this, BootstrapSwitch);

      this.$element = $(element);
      this.options = $.extend({}, $.fn.bootstrapSwitch.defaults, this._getElementOptions(), options);
      this.prevOptions = {};
      this.$wrapper = $('<div>', {
        class: function _class() {
          var classes = [];
          classes.push(_this.options.state ? 'on' : 'off');
          if (_this.options.size) {
            classes.push(_this.options.size);
          }
          if (_this.options.disabled) {
            classes.push('disabled');
          }
          if (_this.options.readonly) {
            classes.push('readonly');
          }
          if (_this.options.indeterminate) {
            classes.push('indeterminate');
          }
          if (_this.options.inverse) {
            classes.push('inverse');
          }
          if (_this.$element.attr('id')) {
            classes.push('id-' + _this.$element.attr('id'));
          }
          return classes.map(_this._getClass.bind(_this)).concat([_this.options.baseClass], _this._getClasses(_this.options.wrapperClass)).join(' ');
        }
      });
      this.$container = $('<div>', { class: this._getClass('container') });
      this.$on = $('<span>', {
        html: this.options.onText,
        class: this._getClass('handle-on') + ' ' + this._getClass(this.options.onColor)
      });
      this.$off = $('<span>', {
        html: this.options.offText,
        class: this._getClass('handle-off') + ' ' + this._getClass(this.options.offColor)
      });
      this.$label = $('<span>', {
        html: this.options.labelText,
        class: this._getClass('label')
      });

      this.$element.on('init.bootstrapSwitch', this.options.onInit.bind(this, element));
      this.$element.on('switchChange.bootstrapSwitch', function () {
        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }

        if (_this.options.onSwitchChange.apply(element, args) === false) {
          if (_this.$element.is(':radio')) {
            $('[name="' + _this.$element.attr('name') + '"]').trigger('previousState.bootstrapSwitch', true);
          } else {
            _this.$element.trigger('previousState.bootstrapSwitch', true);
          }
        }
      });

      this.$container = this.$element.wrap(this.$container).parent();
      this.$wrapper = this.$container.wrap(this.$wrapper).parent();
      this.$element.before(this.options.inverse ? this.$off : this.$on).before(this.$label).before(this.options.inverse ? this.$on : this.$off);

      if (this.options.indeterminate) {
        this.$element.prop('indeterminate', true);
      }

      this._init();
      this._elementHandlers();
      this._handleHandlers();
      this._labelHandlers();
      this._formHandler();
      this._externalLabelHandler();
      this.$element.trigger('init.bootstrapSwitch', this.options.state);
    }

    _createClass(BootstrapSwitch, [{
      key: 'setPrevOptions',
      value: function setPrevOptions() {
        this.prevOptions = Object.assign({}, this.options);
      }
    }, {
      key: 'state',
      value: function state(value, skip) {
        if (typeof value === 'undefined') {
          return this.options.state;
        }
        if (this.options.disabled || this.options.readonly || this.options.state && !this.options.radioAllOff && this.$element.is(':radio')) {
          return this.$element;
        }
        if (this.$element.is(':radio')) {
          $('[name="' + this.$element.attr('name') + '"]').trigger('setPreviousOptions.bootstrapSwitch');
        } else {
          this.$element.trigger('setPreviousOptions.bootstrapSwitch');
        }
        if (this.options.indeterminate) {
          this.indeterminate(false);
        }
        this.$element.prop('checked', Boolean(value)).trigger('change.bootstrapSwitch', skip);
        return this.$element;
      }
    }, {
      key: 'toggleState',
      value: function toggleState(skip) {
        if (this.options.disabled || this.options.readonly) {
          return this.$element;
        }
        if (this.options.indeterminate) {
          this.indeterminate(false);
          return this.state(true);
        } else {
          return this.$element.prop('checked', !this.options.state).trigger('change.bootstrapSwitch', skip);
        }
      }
    }, {
      key: 'size',
      value: function size(value) {
        if (typeof value === 'undefined') {
          return this.options.size;
        }
        if (this.options.size != null) {
          this.$wrapper.removeClass(this._getClass(this.options.size));
        }
        if (value) {
          this.$wrapper.addClass(this._getClass(value));
        }
        this._width();
        this._containerPosition();
        this.options.size = value;
        return this.$element;
      }
    }, {
      key: 'animate',
      value: function animate(value) {
        if (typeof value === 'undefined') {
          return this.options.animate;
        }
        if (this.options.animate === Boolean(value)) {
          return this.$element;
        }
        return this.toggleAnimate();
      }
    }, {
      key: 'toggleAnimate',
      value: function toggleAnimate() {
        this.options.animate = !this.options.animate;
        this.$wrapper.toggleClass(this._getClass('animate'));
        return this.$element;
      }
    }, {
      key: 'disabled',
      value: function disabled(value) {
        if (typeof value === 'undefined') {
          return this.options.disabled;
        }
        if (this.options.disabled === Boolean(value)) {
          return this.$element;
        }
        return this.toggleDisabled();
      }
    }, {
      key: 'toggleDisabled',
      value: function toggleDisabled() {
        this.options.disabled = !this.options.disabled;
        this.$element.prop('disabled', this.options.disabled);
        this.$wrapper.toggleClass(this._getClass('disabled'));
        return this.$element;
      }
    }, {
      key: 'readonly',
      value: function readonly(value) {
        if (typeof value === 'undefined') {
          return this.options.readonly;
        }
        if (this.options.readonly === Boolean(value)) {
          return this.$element;
        }
        return this.toggleReadonly();
      }
    }, {
      key: 'toggleReadonly',
      value: function toggleReadonly() {
        this.options.readonly = !this.options.readonly;
        this.$element.prop('readonly', this.options.readonly);
        this.$wrapper.toggleClass(this._getClass('readonly'));
        return this.$element;
      }
    }, {
      key: 'indeterminate',
      value: function indeterminate(value) {
        if (typeof value === 'undefined') {
          return this.options.indeterminate;
        }
        if (this.options.indeterminate === Boolean(value)) {
          return this.$element;
        }
        return this.toggleIndeterminate();
      }
    }, {
      key: 'toggleIndeterminate',
      value: function toggleIndeterminate() {
        this.options.indeterminate = !this.options.indeterminate;
        this.$element.prop('indeterminate', this.options.indeterminate);
        this.$wrapper.toggleClass(this._getClass('indeterminate'));
        this._containerPosition();
        return this.$element;
      }
    }, {
      key: 'inverse',
      value: function inverse(value) {
        if (typeof value === 'undefined') {
          return this.options.inverse;
        }
        if (this.options.inverse === Boolean(value)) {
          return this.$element;
        }
        return this.toggleInverse();
      }
    }, {
      key: 'toggleInverse',
      value: function toggleInverse() {
        this.$wrapper.toggleClass(this._getClass('inverse'));
        var $on = this.$on.clone(true);
        var $off = this.$off.clone(true);
        this.$on.replaceWith($off);
        this.$off.replaceWith($on);
        this.$on = $off;
        this.$off = $on;
        this.options.inverse = !this.options.inverse;
        return this.$element;
      }
    }, {
      key: 'onColor',
      value: function onColor(value) {
        if (typeof value === 'undefined') {
          return this.options.onColor;
        }
        if (this.options.onColor) {
          this.$on.removeClass(this._getClass(this.options.onColor));
        }
        this.$on.addClass(this._getClass(value));
        this.options.onColor = value;
        return this.$element;
      }
    }, {
      key: 'offColor',
      value: function offColor(value) {
        if (typeof value === 'undefined') {
          return this.options.offColor;
        }
        if (this.options.offColor) {
          this.$off.removeClass(this._getClass(this.options.offColor));
        }
        this.$off.addClass(this._getClass(value));
        this.options.offColor = value;
        return this.$element;
      }
    }, {
      key: 'onText',
      value: function onText(value) {
        if (typeof value === 'undefined') {
          return this.options.onText;
        }
        this.$on.html(value);
        this._width();
        this._containerPosition();
        this.options.onText = value;
        return this.$element;
      }
    }, {
      key: 'offText',
      value: function offText(value) {
        if (typeof value === 'undefined') {
          return this.options.offText;
        }
        this.$off.html(value);
        this._width();
        this._containerPosition();
        this.options.offText = value;
        return this.$element;
      }
    }, {
      key: 'labelText',
      value: function labelText(value) {
        if (typeof value === 'undefined') {
          return this.options.labelText;
        }
        this.$label.html(value);
        this._width();
        this.options.labelText = value;
        return this.$element;
      }
    }, {
      key: 'handleWidth',
      value: function handleWidth(value) {
        if (typeof value === 'undefined') {
          return this.options.handleWidth;
        }
        this.options.handleWidth = value;
        this._width();
        this._containerPosition();
        return this.$element;
      }
    }, {
      key: 'labelWidth',
      value: function labelWidth(value) {
        if (typeof value === 'undefined') {
          return this.options.labelWidth;
        }
        this.options.labelWidth = value;
        this._width();
        this._containerPosition();
        return this.$element;
      }
    }, {
      key: 'baseClass',
      value: function baseClass(value) {
        return this.options.baseClass;
      }
    }, {
      key: 'wrapperClass',
      value: function wrapperClass(value) {
        if (typeof value === 'undefined') {
          return this.options.wrapperClass;
        }
        if (!value) {
          value = $.fn.bootstrapSwitch.defaults.wrapperClass;
        }
        this.$wrapper.removeClass(this._getClasses(this.options.wrapperClass).join(' '));
        this.$wrapper.addClass(this._getClasses(value).join(' '));
        this.options.wrapperClass = value;
        return this.$element;
      }
    }, {
      key: 'radioAllOff',
      value: function radioAllOff(value) {
        if (typeof value === 'undefined') {
          return this.options.radioAllOff;
        }
        var val = Boolean(value);
        if (this.options.radioAllOff === val) {
          return this.$element;
        }
        this.options.radioAllOff = val;
        return this.$element;
      }
    }, {
      key: 'onInit',
      value: function onInit(value) {
        if (typeof value === 'undefined') {
          return this.options.onInit;
        }
        if (!value) {
          value = $.fn.bootstrapSwitch.defaults.onInit;
        }
        this.options.onInit = value;
        return this.$element;
      }
    }, {
      key: 'onSwitchChange',
      value: function onSwitchChange(value) {
        if (typeof value === 'undefined') {
          return this.options.onSwitchChange;
        }
        if (!value) {
          value = $.fn.bootstrapSwitch.defaults.onSwitchChange;
        }
        this.options.onSwitchChange = value;
        return this.$element;
      }
    }, {
      key: 'destroy',
      value: function destroy() {
        var $form = this.$element.closest('form');
        if ($form.length) {
          $form.off('reset.bootstrapSwitch').removeData('bootstrap-switch');
        }
        this.$container.children().not(this.$element).remove();
        this.$element.unwrap().unwrap().off('.bootstrapSwitch').removeData('bootstrap-switch');
        return this.$element;
      }
    }, {
      key: '_getElementOptions',
      value: function _getElementOptions() {
        return {
          state: this.$element.is(':checked'),
          size: this.$element.data('size'),
          animate: this.$element.data('animate'),
          disabled: this.$element.is(':disabled'),
          readonly: this.$element.is('[readonly]'),
          indeterminate: this.$element.data('indeterminate'),
          inverse: this.$element.data('inverse'),
          radioAllOff: this.$element.data('radio-all-off'),
          onColor: this.$element.data('on-color'),
          offColor: this.$element.data('off-color'),
          onText: this.$element.data('on-text'),
          offText: this.$element.data('off-text'),
          labelText: this.$element.data('label-text'),
          handleWidth: this.$element.data('handle-width'),
          labelWidth: this.$element.data('label-width'),
          baseClass: this.$element.data('base-class'),
          wrapperClass: this.$element.data('wrapper-class')
        };
      }
    }, {
      key: '_width',
      value: function _width() {
        var _this2 = this;

        var $handles = this.$on.add(this.$off).add(this.$label).css('width', '');
        var handleWidth = void 0;
        if (this.options.handleWidth === 'auto') {
          handleWidth = Math.round(Math.max(this.$on.width(), this.$off.width()));
        } else {
          handleWidth = this.options.handleWidth;
        }
        $handles.width(handleWidth);
        this.$label.width(function (index, width) {
          if (_this2.options.labelWidth !== 'auto') {
            return _this2.options.labelWidth;
          }
          if (width < handleWidth) {
            return handleWidth;
          }
          return width;
        });
        this._handleWidth = this.$on.outerWidth();
        this._labelWidth = this.$label.outerWidth();
        this.$container.width(this._handleWidth * 2 + this._labelWidth);
        return this.$wrapper.width(this._handleWidth + this._labelWidth);
      }
    }, {
      key: '_containerPosition',
      value: function _containerPosition() {
        var _this3 = this;

        var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.options.state;
        var callback = arguments[1];

        this.$container.css('margin-left', function () {
          var values = [0, '-' + _this3._handleWidth + 'px'];
          if (_this3.options.indeterminate) {
            return '-' + _this3._handleWidth / 2 + 'px';
          }
          if (state) {
            if (_this3.options.inverse) {
              return values[1];
            } else {
              return values[0];
            }
          } else {
            if (_this3.options.inverse) {
              return values[0];
            } else {
              return values[1];
            }
          }
        });
      }
    }, {
      key: '_init',
      value: function _init() {
        var _this4 = this;

        var init = function init() {
          _this4.setPrevOptions();
          _this4._width();
          _this4._containerPosition();
          setTimeout(function () {
            if (_this4.options.animate) {
              return _this4.$wrapper.addClass(_this4._getClass('animate'));
            }
          }, 50);
        };
        if (this.$wrapper.is(':visible')) {
          init();
          return;
        }
        var initInterval = window.setInterval(function () {
          if (_this4.$wrapper.is(':visible')) {
            init();
            return window.clearInterval(initInterval);
          }
        }, 50);
      }
    }, {
      key: '_elementHandlers',
      value: function _elementHandlers() {
        var _this5 = this;

        return this.$element.on({
          'setPreviousOptions.bootstrapSwitch': this.setPrevOptions.bind(this),

          'previousState.bootstrapSwitch': function previousStateBootstrapSwitch() {
            _this5.options = _this5.prevOptions;
            if (_this5.options.indeterminate) {
              _this5.$wrapper.addClass(_this5._getClass('indeterminate'));
            }
            _this5.$element.prop('checked', _this5.options.state).trigger('change.bootstrapSwitch', true);
          },

          'change.bootstrapSwitch': function changeBootstrapSwitch(event, skip) {
            event.preventDefault();
            event.stopImmediatePropagation();
            var state = _this5.$element.is(':checked');
            _this5._containerPosition(state);
            if (state === _this5.options.state) {
              return;
            }
            _this5.options.state = state;
            _this5.$wrapper.toggleClass(_this5._getClass('off')).toggleClass(_this5._getClass('on'));
            if (!skip) {
              if (_this5.$element.is(':radio')) {
                $('[name="' + _this5.$element.attr('name') + '"]').not(_this5.$element).prop('checked', false).trigger('change.bootstrapSwitch', true);
              }
              _this5.$element.trigger('switchChange.bootstrapSwitch', [state]);
            }
          },

          'focus.bootstrapSwitch': function focusBootstrapSwitch(event) {
            event.preventDefault();
            _this5.$wrapper.addClass(_this5._getClass('focused'));
          },

          'blur.bootstrapSwitch': function blurBootstrapSwitch(event) {
            event.preventDefault();
            _this5.$wrapper.removeClass(_this5._getClass('focused'));
          },

          'keydown.bootstrapSwitch': function keydownBootstrapSwitch(event) {
            if (!event.which || _this5.options.disabled || _this5.options.readonly) {
              return;
            }
            if (event.which === 37 || event.which === 39) {
              event.preventDefault();
              event.stopImmediatePropagation();
              _this5.state(event.which === 39);
            }
          }
        });
      }
    }, {
      key: '_handleHandlers',
      value: function _handleHandlers() {
        var _this6 = this;

        this.$on.on('click.bootstrapSwitch', function (event) {
          event.preventDefault();
          event.stopPropagation();
          _this6.state(false);
          return _this6.$element.trigger('focus.bootstrapSwitch');
        });
        return this.$off.on('click.bootstrapSwitch', function (event) {
          event.preventDefault();
          event.stopPropagation();
          _this6.state(true);
          return _this6.$element.trigger('focus.bootstrapSwitch');
        });
      }
    }, {
      key: '_labelHandlers',
      value: function _labelHandlers() {
        var _this7 = this;

        var handlers = {
          click: function click(event) {
            event.stopPropagation();
          },


          'mousedown.bootstrapSwitch touchstart.bootstrapSwitch': function mousedownBootstrapSwitchTouchstartBootstrapSwitch(event) {
            if (_this7._dragStart || _this7.options.disabled || _this7.options.readonly) {
              return;
            }
            event.preventDefault();
            event.stopPropagation();
            _this7._dragStart = (event.pageX || event.originalEvent.touches[0].pageX) - parseInt(_this7.$container.css('margin-left'), 10);
            if (_this7.options.animate) {
              _this7.$wrapper.removeClass(_this7._getClass('animate'));
            }
            _this7.$element.trigger('focus.bootstrapSwitch');
          },

          'mousemove.bootstrapSwitch touchmove.bootstrapSwitch': function mousemoveBootstrapSwitchTouchmoveBootstrapSwitch(event) {
            if (_this7._dragStart == null) {
              return;
            }
            var difference = (event.pageX || event.originalEvent.touches[0].pageX) - _this7._dragStart;
            event.preventDefault();
            if (difference < -_this7._handleWidth || difference > 0) {
              return;
            }
            _this7._dragEnd = difference;
            _this7.$container.css('margin-left', _this7._dragEnd + 'px');
          },

          'mouseup.bootstrapSwitch touchend.bootstrapSwitch': function mouseupBootstrapSwitchTouchendBootstrapSwitch(event) {
            if (!_this7._dragStart) {
              return;
            }
            event.preventDefault();
            if (_this7.options.animate) {
              _this7.$wrapper.addClass(_this7._getClass('animate'));
            }
            if (_this7._dragEnd) {
              var state = _this7._dragEnd > -(_this7._handleWidth / 2);
              _this7._dragEnd = false;
              _this7.state(_this7.options.inverse ? !state : state);
            } else {
              _this7.state(!_this7.options.state);
            }
            _this7._dragStart = false;
          },

          'mouseleave.bootstrapSwitch': function mouseleaveBootstrapSwitch() {
            _this7.$label.trigger('mouseup.bootstrapSwitch');
          }
        };
        this.$label.on(handlers);
      }
    }, {
      key: '_externalLabelHandler',
      value: function _externalLabelHandler() {
        var _this8 = this;

        var $externalLabel = this.$element.closest('label');
        $externalLabel.on('click', function (event) {
          event.preventDefault();
          event.stopImmediatePropagation();
          if (event.target === $externalLabel[0]) {
            _this8.toggleState();
          }
        });
      }
    }, {
      key: '_formHandler',
      value: function _formHandler() {
        var $form = this.$element.closest('form');
        if ($form.data('bootstrap-switch')) {
          return;
        }
        $form.on('reset.bootstrapSwitch', function () {
          window.setTimeout(function () {
            $form.find('input').filter(function () {
              return $(this).data('bootstrap-switch');
            }).each(function () {
              return $(this).bootstrapSwitch('state', this.checked);
            });
          }, 1);
        }).data('bootstrap-switch', true);
      }
    }, {
      key: '_getClass',
      value: function _getClass(name) {
        return this.options.baseClass + '-' + name;
      }
    }, {
      key: '_getClasses',
      value: function _getClasses(classes) {
        if (!$.isArray(classes)) {
          return [this._getClass(classes)];
        }
        return classes.map(this._getClass.bind(this));
      }
    }]);

    return BootstrapSwitch;
  }();

  $.fn.bootstrapSwitch = function (option) {
    for (var _len2 = arguments.length, args = Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
      args[_key2 - 1] = arguments[_key2];
    }

    var ret = this;
    this.each(function () {
      var $this = $(this);
      var data = $this.data('bootstrap-switch');
      if (!data) {
        data = new BootstrapSwitch(this, option);
        $this.data('bootstrap-switch', data);
      }
      if (typeof option === 'string') {
        ret = data[option].apply(data, args);
      }
    });
    return ret;
  };
  $.fn.bootstrapSwitch.Constructor = BootstrapSwitch;
  $.fn.bootstrapSwitch.defaults = {
    state: true,
    size: null,
    animate: true,
    disabled: false,
    readonly: false,
    indeterminate: false,
    inverse: false,
    radioAllOff: false,
    onColor: 'primary',
    offColor: 'default',
    onText: 'ON',
    offText: 'OFF',
    labelText: '&nbsp',
    handleWidth: 'auto',
    labelWidth: 'auto',
    baseClass: 'bootstrap-switch',
    wrapperClass: 'wrapper',
    onInit: function onInit() {},
    onSwitchChange: function onSwitchChange() {}
  };
})(__webpack_provided_window_dot_jQuery, window);

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(0)))

/***/ }),

/***/ 487:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)();
exports.push([module.i, "/**\n  * bootstrap-switch - Turn checkboxes and radio buttons into toggle switches.\n  *\n  * @version v3.3.3\n  * @homepage http://www.bootstrap-switch.org\n  * @author Mattia Larentis <mattia@larentis.eu> (http://larentis.eu)\n  * @license Apache-2.0\n  */\n\n.bootstrap-switch{display:inline-block;direction:ltr;cursor:pointer;border-radius:4px;border:1px solid #ccc;position:relative;text-align:left;overflow:hidden;line-height:8px;z-index:0;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;vertical-align:middle;-webkit-transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s;-o-transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s;transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s}.bootstrap-switch .bootstrap-switch-container{display:inline-block;top:0;border-radius:4px;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}.bootstrap-switch .bootstrap-switch-handle-off,.bootstrap-switch .bootstrap-switch-handle-on,.bootstrap-switch .bootstrap-switch-label{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;cursor:pointer;display:inline-block!important;height:100%;padding:6px 12px;font-size:14px;line-height:20px}.bootstrap-switch .bootstrap-switch-handle-off,.bootstrap-switch .bootstrap-switch-handle-on{text-align:center;z-index:1}.bootstrap-switch .bootstrap-switch-handle-off.bootstrap-switch-primary,.bootstrap-switch .bootstrap-switch-handle-on.bootstrap-switch-primary{color:#fff;background:#337ab7}.bootstrap-switch .bootstrap-switch-handle-off.bootstrap-switch-info,.bootstrap-switch .bootstrap-switch-handle-on.bootstrap-switch-info{color:#fff;background:#5bc0de}.bootstrap-switch .bootstrap-switch-handle-off.bootstrap-switch-success,.bootstrap-switch .bootstrap-switch-handle-on.bootstrap-switch-success{color:#fff;background:#5cb85c}.bootstrap-switch .bootstrap-switch-handle-off.bootstrap-switch-warning,.bootstrap-switch .bootstrap-switch-handle-on.bootstrap-switch-warning{background:#f0ad4e;color:#fff}.bootstrap-switch .bootstrap-switch-handle-off.bootstrap-switch-danger,.bootstrap-switch .bootstrap-switch-handle-on.bootstrap-switch-danger{color:#fff;background:#d9534f}.bootstrap-switch .bootstrap-switch-handle-off.bootstrap-switch-default,.bootstrap-switch .bootstrap-switch-handle-on.bootstrap-switch-default{color:#000;background:#eee}.bootstrap-switch .bootstrap-switch-label{text-align:center;margin-top:-1px;margin-bottom:-1px;z-index:100;color:#333;background:#fff}.bootstrap-switch .bootstrap-switch-handle-on{border-bottom-left-radius:3px;border-top-left-radius:3px}.bootstrap-switch .bootstrap-switch-handle-off{border-bottom-right-radius:3px;border-top-right-radius:3px}.bootstrap-switch input[type=radio],.bootstrap-switch input[type=checkbox]{position:absolute!important;top:0;left:0;margin:0;z-index:-1;opacity:0;filter:alpha(opacity=0)}.bootstrap-switch.bootstrap-switch-mini .bootstrap-switch-handle-off,.bootstrap-switch.bootstrap-switch-mini .bootstrap-switch-handle-on,.bootstrap-switch.bootstrap-switch-mini .bootstrap-switch-label{padding:1px 5px;font-size:12px;line-height:1.5}.bootstrap-switch.bootstrap-switch-small .bootstrap-switch-handle-off,.bootstrap-switch.bootstrap-switch-small .bootstrap-switch-handle-on,.bootstrap-switch.bootstrap-switch-small .bootstrap-switch-label{padding:5px 10px;font-size:12px;line-height:1.5}.bootstrap-switch.bootstrap-switch-large .bootstrap-switch-handle-off,.bootstrap-switch.bootstrap-switch-large .bootstrap-switch-handle-on,.bootstrap-switch.bootstrap-switch-large .bootstrap-switch-label{padding:6px 16px;font-size:18px;line-height:1.3333333}.bootstrap-switch.bootstrap-switch-disabled,.bootstrap-switch.bootstrap-switch-indeterminate,.bootstrap-switch.bootstrap-switch-readonly{cursor:default!important}.bootstrap-switch.bootstrap-switch-disabled .bootstrap-switch-handle-off,.bootstrap-switch.bootstrap-switch-disabled .bootstrap-switch-handle-on,.bootstrap-switch.bootstrap-switch-disabled .bootstrap-switch-label,.bootstrap-switch.bootstrap-switch-indeterminate .bootstrap-switch-handle-off,.bootstrap-switch.bootstrap-switch-indeterminate .bootstrap-switch-handle-on,.bootstrap-switch.bootstrap-switch-indeterminate .bootstrap-switch-label,.bootstrap-switch.bootstrap-switch-readonly .bootstrap-switch-handle-off,.bootstrap-switch.bootstrap-switch-readonly .bootstrap-switch-handle-on,.bootstrap-switch.bootstrap-switch-readonly .bootstrap-switch-label{opacity:.5;filter:alpha(opacity=50);cursor:default!important}.bootstrap-switch.bootstrap-switch-animate .bootstrap-switch-container{-webkit-transition:margin-left .5s;-o-transition:margin-left .5s;transition:margin-left .5s}.bootstrap-switch.bootstrap-switch-inverse .bootstrap-switch-handle-on{border-radius:0 3px 3px 0}.bootstrap-switch.bootstrap-switch-inverse .bootstrap-switch-handle-off{border-radius:3px 0 0 3px}.bootstrap-switch.bootstrap-switch-focused{border-color:#66afe9;outline:0;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6);box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,.6)}.bootstrap-switch.bootstrap-switch-inverse.bootstrap-switch-off .bootstrap-switch-label,.bootstrap-switch.bootstrap-switch-on .bootstrap-switch-label{border-bottom-right-radius:3px;border-top-right-radius:3px}.bootstrap-switch.bootstrap-switch-inverse.bootstrap-switch-on .bootstrap-switch-label,.bootstrap-switch.bootstrap-switch-off .bootstrap-switch-label{border-bottom-left-radius:3px;border-top-left-radius:3px}", ""]);

/***/ }),

/***/ 524:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)();
exports.push([module.i, "/*\nCreated by: Jyostna Designs\n\n[TABLE OF CONTENTS]\n\n1.  IMPORTS\n2.  RESET STYLES\n3.  HEADER STYLES\n    3.1 HEADER RIGHT SIDE BAR\n    3.2 HEADER LEFT\n    3.3 HEADER RIGHT SIDE DROPDOWNS\n4. LEFT SIDE BAR\n5. MAIN WRAPPER STYLES\n6. LEFT MENU COLLAPSE STYLES\n7. CUSTOM STYLES\n8. MEDIA QUERIES\n9. PRELOADER\n\n*/\n/********** 1. IMPORTS **********/\n/* Variables Imported from sass */\n/*****  2.RESET STYLES  *****/\nhtml {\n  background: none repeat scroll 0 0 #FCFCFC;\n  overflow-x: hidden;\n  -webkit-font-smoothing: antialiased;\n  transition: all .25s ease-out;\n  font-size: small;\n}\nbody {\n  background: none repeat scroll 0 0 #FCFCFC;\n  -webkit-font-smoothing: antialiased;\n  transition: all .25s ease-out;\n  font-size: small;\n  letter-spacing: 0.5px;\n  overflow-x: hidden;\n}\nul {\n  list-style: none;\n}\np {\n  line-height: 20px;\n}\nlabel {\n  font-weight: 400;\n  font-size: 14px;\n  letter-spacing: 1px;\n}\nbody.modal-open, body.swal2-in {\n  padding: 0 !important;\n}\n\n/******  3.HEADER STYLES   ******/\nbody > #app .header {\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  z-index: 1030;\n  background: #2E576B;\n}\nbody > #app .header .navbar {\n  margin-bottom: 0;\n}\nbody > #app .header .navbar .nav > li > a > .label {\n  border-radius: 50%;\n  position: absolute;\n  top: 12px;\n  right: 9px;\n  font-size: 8px;\n  font-weight: normal;\n  width: 13px;\n  height: 13px;\n  line-height: 1.0em;\n  text-align: center;\n  padding: 2px;\n}\nbody > #app .header .navbar .nav > li > a:hover > .label {\n  top: 7px;\n}\nbody > #app .header .logo {\n  display: block;\n  float: left;\n  height: 50px;\n  line-height: 50px;\n  padding: 3px 10px;\n  text-align: center;\n  width: 251px;\n}\nbody > #app .header .logo .icon {\n  margin-right: 10px;\n}\n\n/* Define 2 column template */\n.right-side,\n.left-side {\n  display: block;\n}\n\n/****** 3.1 HEADER RIGHT SIDE BAR *******/\n.right-side {\n  margin-left: 250px;\n  padding: 51px 10px 10px 10px;\n}\n.right-side > .content-header > h1 {\n  margin: 2px;\n  padding-left: 13px;\n  padding-top: 7px;\n}\n.right-side > .content-header {\n  margin: -2px -10px 25px -10px;\n  height: 73px;\n  background: #FAFAFA;\n  box-shadow: 0 2px 18px #E5E5E5;\n}\n.right-side > .content-header > .breadcrumb {\n  background-color: #F9F9F9;\n  padding: 2px 15px 9px 15px;\n}\n.right-side > .content-header > .breadcrumb > li > a,\n.right-side > .content-header > .breadcrumb > li {\n  color: #333;\n}\n.right-side > .content-header > .breadcrumb > li > a > .fa,\n.right-side > .content-header > .breadcrumb > li > a > .glyphicon {\n  margin-right: 5px;\n}\n.breadcrumb > li + li:before {\n  padding: 0;\n}\n\n/* right side bar css start */\n#right {\n  transition: all .3s ease-in-out;\n  width: 270px;\n  z-index: 999;\n  position: fixed;\n  top: 0;\n  bottom: 0;\n  overflow-y: auto;\n  right: -270px;\n  box-shadow: 0 0 15px #CCC;\n  background: #FAFAFA;\n}\n.rightsidebar-right .rightsidebar-right-content {\n  padding-top: 53px;\n}\n#right .nav-tabs > li > a:hover {\n  border: 1px solid transparent;\n}\n#right .nav > li > a:hover {\n  background-color: transparent;\n}\n.rightsidebar-right .nav-tabs {\n  border-bottom: 0;\n}\n.rightslider-p-t {\n  padding-top: 0 !important;\n}\n.rightsidebar-right .text-muted {\n  color: #555;\n}\n.rightsidebar-right .rightsidebar-right-content .rightsidebar-right-heading {\n  background: #FFF;\n  color: #555;\n  border-bottom: 1px solid #DDD;\n  border-top: 1px solid #DDD;\n  margin: 0px -20px 0;\n  font-size: 15px;\n  padding: 15px 20px 15px 15px;\n}\n.rightsidebar-right .rightsidebar-right-content .gen-sett-m-t {\n  margin-top: 138px;\n}\n.margin-none {\n  margin: 0;\n}\n.rightsidebar-contact-wrapper {\n  margin: 1px -20px;\n  transition: all 0.5s ease;\n}\n.rightsidebar-contact-wrapper .rightsidebar-contact {\n  padding: 15px 20px;\n  display: block;\n  color: #2E576B;\n}\n.rightsidebar-contact-wrapper .rightsidebar-contact:hover {\n  text-decoration: none;\n}\n.rightsidebar-notification {\n  margin: 1px 0;\n  transition: all 0.5s ease;\n}\n.rightsidebar-notification a {\n  padding: 15px 0;\n  display: block;\n  color: #2E576B;\n}\n.sidebar-right-opened {\n  right: 250px;\n}\n.sidebar-right-opened #right {\n  right: 0;\n}\n.sidebar-right-opened .background-overlay {\n  position: fixed;\n  display: block;\n  top: 0;\n  bottom: 0;\n  right: 0;\n  left: 0;\n  background: rgba(0, 0, 0, 0.12);\n  z-index: 998;\n  transition: background-color .3s;\n}\n.scrollable-content {\n  height: 100%;\n}\n\n/*rightside bar tabs*/\n#right .nav-tabs > li {\n  margin-bottom: -3px;\n}\n#right .nav-tabs > li > a {\n  padding: 10px 19px 4px 19px;\n  font-size: 23px;\n}\n#right .nav-tabs > li.active > a,\n.nav-tabs > li.active > a:hover,\n.nav-tabs > li.active > a:focus {\n  border: 1px solid #DDD;\n  color: #555;\n  background-color: #FFF;\n  border-bottom-color: transparent;\n  margin-top: -2px;\n}\n#slim_t1,\n#slim_t2,\n#slim_t3 {\n  padding-left: 20px;\n  padding-right: 20px;\n}\n#right #slim_t1 img {\n  width: 20px;\n  height: 20px;\n}\n#slim_t2 .notifications li {\n  height: 52px;\n}\n#slim_t2 .notifications li a {\n  line-height: 20px;\n  font-size: 12.5px;\n  color: #333;\n}\n#slim_t2 .message .message-image {\n  height: 37px;\n}\n#slim_t2 .message-body {\n  padding-top: 3px;\n  color: #717171;\n}\n#slim_t2 .noti-date {\n  margin-top: -42px;\n}\n.m-t-15 {\n  margin-top: 15px;\n}\n#slim_t2 .notifications .noti-footer {\n  height: 32px;\n  padding-top: 10px;\n}\n#slim_t2 .notifications .noti-footer a {\n  color: #6699CC;\n}\n\n/*tab 3 settings*/\n/*to hide default skin picker*/\n#slim_t3 ul {\n  padding: 0;\n}\n#right #slim_t3 .settings-list li {\n  padding-top: 8px;\n  padding-bottom: 8px;\n  font-size: 14px;\n}\ninput[type=\"range\"] {\n  display: block;\n  width: 80%;\n  margin: auto;\n}\n.setting-color {\n  padding: 0 2px;\n  margin-bottom: 5px;\n}\n.setting-color > label {\n  display: block;\n  position: relative;\n  margin: 10px;\n  padding: 0;\n  border-radius: 3px;\n  overflow: hidden;\n  border: 0;\n  box-shadow: 2px 4px 5px #CCC;\n  cursor: pointer;\n  width: 53px;\n  float: left;\n}\n.setting-color > label.active-color .split .bg-default-clear:after,\n.setting-color > label.active-color .split .bg-mint:after,\n.setting-color > label.active-color .split .bg-grape:after,\n.setting-color > label.active-color .split .bg-lavender:after,\n.setting-color > label.active-color .split .bg-pink:after,\n.setting-color > label.active-color .split .bg-sunflower:after {\n  content: '';\n  position: absolute;\n  top: 12px;\n  left: 14px;\n  height: 22px;\n  width: 26px;\n  border-radius: 16px;\n  border-top: 13px solid #fafafa;\n}\n.setting-color > label.active-color .split .bg-default-clear:after {\n  border-bottom: 13px solid #2E576B;\n}\n.setting-color > label.active-color .split .bg-mint:after {\n  border-bottom: 13px solid #37BC9B;\n}\n.setting-color > label.active-color .split .bg-grape:after {\n  border-bottom: 13px solid #E76F7C;\n}\n.setting-color > label.active-color .split .bg-lavender:after {\n  border-bottom: 13px solid #AC92EC;\n}\n.setting-color > label.active-color .split .bg-pink:after {\n  border-bottom: 13px solid #EC87C0;\n}\n.setting-color > label.active-color .split .bg-sunflower:after {\n  border-bottom: 13px solid #FFCE54;\n}\n.setting-color > label:first-child {\n  margin-left: 10px;\n}\n.setting-color > label:last-child {\n  margin-right: 0;\n}\n.setting-color > label > .color {\n  display: block;\n  height: 18px;\n}\n.setting-color > label > .split {\n  display: block;\n}\n.setting-color > label > .split:after,\n.setting-color > label > .split:before {\n  content: \" \";\n  display: table;\n}\n.setting-color > label > .split:after {\n  clear: both;\n}\n.setting-color > label > .split > .color {\n  display: block;\n  height: 25.5px;\n}\n.setting-color > label > .split > .color:first-child {\n  float: left;\n  width: 70%;\n}\n.setting-color > label > .split > .color:last-child {\n  float: right;\n  width: 30%;\n}\n.setting-color > label > input[type=radio] {\n  position: absolute;\n  opacity: 0;\n  visibility: hidden;\n}\n.bg-default-light {\n  background-color: #2E576B;\n  color: #FFF;\n}\n.bg-default-clear {\n  background-color: #2E576B;\n  color: #EBF4E4;\n}\n.bg-mint-light {\n  background-color: #56CCAE;\n  color: #FFF;\n}\n.bg-mint {\n  background-color: #37BC9B;\n  color: #EBF4E4;\n}\n.bg-grape-light {\n  background-color: #F4929D;\n  color: #FFF;\n}\n.bg-grape {\n  background-color: #E76F7C;\n  color: #EBF4E4;\n}\n.bg-lavender-light {\n  background-color: #B6A0EC;\n  color: #FFF;\n}\n.bg-lavender {\n  background-color: #AC92EC;\n  color: #EBF4E4;\n}\n.bg-pink-light {\n  background-color: #EE98C8;\n  color: #FFF;\n}\n.bg-pink {\n  background-color: #EC87C0;\n  color: #EBF4E4;\n}\n.bg-gray {\n  background-color: #2E576B;\n}\n.bg-gray-light {\n  background-color: #EFEFEF;\n}\n.bg-sunflower {\n  background-color: #FFCE54;\n}\n.bg-sunflower-light {\n  background-color: #FFDD87;\n}\n.no-margin {\n  padding-left: 6px;\n}\n.ion-email {\n  font-size: 17px;\n}\n.stylehtml {\n  background: url("+__webpack_require__(239)+") repeat;\n}\n\n/*rightside bar tabs ends*/\n/******* 3.2 HEADER LEFT ******/\n/*side bar nav */\n.sidebar {\n  display: block;\n  float: left;\n  width: 250px !important;\n}\n.content {\n  display: block;\n  width: auto;\n  padding: 0 15px;\n}\n.left-side {\n  background: #FFF;\n  box-shadow: 0 0 15px #EEE;\n}\n.skin-default .sidebar a {\n  color: #808B9C;\n  -webkit-font-smoothing: antialiased;\n}\n\n/* left side profile css */\n.nav_profile .profile-left {\n  padding: 15px;\n  min-height: 90px;\n  border-bottom: 1px solid #EEE;\n}\n.nav_profile .profile-left .profile-thumb {\n  border-radius: 50px;\n  display: inline-block;\n  padding-top: 9px;\n}\n.nav_profile .profile-left .media-heading {\n  line-height: 23px;\n  margin-top: 12px;\n  font-weight: 500;\n  font-size: 16px;\n  color: #2E576B;\n}\n.nav_profile .profile-left .profile-thumb img {\n  width: 54px;\n}\n.nav_profile .content-profile .icon-list li {\n  display: inline-block;\n  padding: 0;\n  vertical-align: top;\n}\n.nav_profile .content-profile .icon-list:before {\n  content: '';\n}\n.nav_profile .content-profile .icon-list li i {\n  font-size: 13px;\n  color: #555;\n  padding-top: 5px;\n}\n.nav_profile .content-profile .icon-list li a {\n  display: block;\n  width: 30px;\n  height: 25px;\n  text-align: center;\n  line-height: 23px;\n  transition: all 300ms ease-in-out;\n}\n.content-profile .icon-list li a {\n  border: 1px solid #DDD;\n}\n.icon-list li a {\n  position: relative;\n}\n\n/******* 3.3 HEADER RIGHT SIDE DROPDOWNS  *****/\n/*\n   Dropdown menus\n----------------------------\n*/\n/*Dropdowns in general*/\n.dropdown-menu {\n  box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);\n  z-index: 2300;\n}\n.dropdown-menu > li > a > .glyphicon,\n.dropdown-menu > li > a > .fa,\n.dropdown-menu > li > a > .ion {\n  margin-right: 10px;\n}\n\n/*Drodown in navbars*/\n.skin-blue .navbar .dropdown-menu > li > a {\n  color: #444444;\n}\n.navbar {\n  background-color: #2E576B;\n}\n\n/*\n   Navbar custom dropdown menu\n------------------------------------\n*/\n.navbar-nav > .messages-menu > .dropdown-menu {\n  width: 340px;\n  padding: 0;\n  margin: 1px 0 0 0;\n  top: 100%;\n  border: 1px;\n}\n.navbar-nav > .user-menu > .dropdown-menu {\n  font-size: 13px;\n  padding: 0;\n  margin-top: 1px;\n  border-radius: 4px;\n  box-shadow: 0 3px 6px rgba(0, 0, 0, 0.2);\n  border: 0;\n}\n.navbar-nav > .user-menu > .dropdown-menu > li.user-header {\n  height: 140px;\n  padding: 6%;\n  background: #2E576B;\n  text-align: center;\n}\n.navbar .nav a {\n  color: #555;\n}\n.navbar .nav .user-footer a {\n  color: #6699CC;\n}\n.navbar-right .nav > li > a {\n  padding: 10px 15px;\n}\n.navbar .navbar-right > .nav {\n  margin-right: 15px;\n}\n.navbar-right .nav > li > .padding-user {\n  padding-top: 8px;\n}\n.navbar-nav > .user-menu > .dropdown-menu > li.user-header > img {\n  z-index: 5;\n  height: 90px;\n  width: 90px;\n}\n.navbar-nav > .user-menu > .dropdown-menu > li.user-header > p {\n  z-index: 5;\n  color: #FFF;\n  font-size: 14px;\n  margin-top: 5px;\n}\n.navbar-nav > .user-menu > .dropdown-menu > li.user-header > p > small {\n  display: block;\n  font-size: 12px;\n}\n.navbar-nav > .user-menu > .dropdown-menu > li.user-body {\n  padding: 15px;\n  border-bottom: 1px solid #F4F4F4;\n  border-top: 1px solid #DDDDDD;\n}\n.navbar-nav > .user-menu > .dropdown-menu > li.user-body:before,\n.navbar-nav > .user-menu > .dropdown-menu > li.user-body:after {\n  display: table;\n  content: \" \";\n}\n.navbar-nav > .user-menu > .dropdown-menu > li.user-body:after {\n  clear: both;\n}\n.navbar-nav > .user-menu > .dropdown-menu > li.user-body > div > a {\n  color: #0073B7;\n}\n.navbar-nav > .user-menu > .dropdown-menu > li.user-footer {\n  padding-right: 12px;\n  padding-left: 12px;\n  padding-bottom: 5px;\n}\n.navbar-nav > .user-menu > .dropdown-menu > li.user-footer:before,\n.navbar-nav > .user-menu > .dropdown-menu > li.user-footer:after {\n  display: table;\n  content: \" \";\n}\n.navbar-nav > .user-menu > .dropdown-menu > li.user-footer:after {\n  clear: both;\n}\n.navbar-nav > .user-menu > .dropdown-menu > li.user-footer .btn-default {\n  color: #666666;\n}\n\n/*===add nicescroll if wondow height is less------*/\n.nice_dropdown {\n  height: 300px;\n  overflow: scroll;\n}\n\n/* Add fade animation to dropdown menus */\n.open > .dropdown-menu {\n  animation-name: fadeAnimation;\n  animation-duration: .7s;\n  animation-iteration-count: 1;\n  animation-timing-function: ease;\n  animation-fill-mode: forwards;\n  -webkit-animation-name: fadeAnimation;\n  -webkit-animation-duration: .7s;\n  -webkit-animation-iteration-count: 1;\n  -webkit-animation-timing-function: ease;\n  -webkit-animation-fill-mode: forwards;\n  -moz-animation-name: fadeAnimation;\n  -moz-animation-duration: .7s;\n  -moz-animation-iteration-count: 1;\n  -moz-animation-timing-function: ease;\n  -moz-animation-fill-mode: forwards;\n}\n@keyframes fadeAnimation {\nfrom {\n    opacity: 0;\n    top: 120%;\n}\nto {\n    opacity: 1;\n    top: 100%;\n}\n}\n@-webkit-keyframes fadeAnimation {\nfrom {\n    opacity: 0;\n    top: 120%;\n}\nto {\n    opacity: 1;\n    top: 100%;\n}\n}\n.dropdown-menu .menu i {\n  display: inline-block;\n  margin: 4px 12px;\n  float: left;\n  padding: 10px 30px 30px 10px;\n  text-align: center;\n  border-radius: 50%;\n  border: 1px solid #E2E2E2;\n}\n.dropdown-menu .menu a {\n  line-height: 42px;\n}\n.dropdown-menu .menu a .clearfix {\n  color: #FFF;\n  line-height: 31px;\n}\n.mesages li img {\n  width: 46px;\n  padding-top: 5px;\n  height: auto;\n  float: left;\n  margin-right: 15px;\n}\n.mesages li {\n  padding: 5px;\n  cursor: pointer;\n}\n.mesages li span {\n  font-size: 12px;\n  display: inline-block;\n  clear: both;\n  float: none;\n}\n.mesages li .samp {\n  font-size: 11px;\n  clear: both;\n  margin-top: -3px;\n}\n.mesages li .time {\n  font-size: 11px;\n  color: #666;\n  margin-top: -3px;\n}\n.message .message-image {\n  display: block;\n  float: left;\n  height: 45px;\n  margin-right: 15px;\n  text-align: center;\n}\nli.dropdown-title {\n  padding: 16px;\n  background: #2E576B;\n  font-size: 14px;\n  color: #FFF;\n}\nli.dropdown-footer a {\n  color: #fff !important;\n}\n.slimScrollDiv .menu li {\n  width: 100%;\n  font-size: 12px;\n  display: inline-block;\n}\nli.dropdown-footer {\n  padding: 16px;\n  background: #2E576B;\n  color: #FFF;\n}\nli.dropdown-footer a {\n  color: #FFF;\n  font-size: 14px;\n}\n.padding-15 {\n  padding: 15px;\n}\n.dropdown-menu li > .message {\n  padding: 5px 15px 5px 25px;\n}\n.dropdown-menu .footer {\n  margin: 0;\n  padding: 0;\n  border-bottom: none;\n}\n.dropdown-menu .message:hover {\n  background: #E0E0E0;\n}\n.message .ol {\n  padding: 5px 10px 5px 5px;\n}\n.message .ol:hover {\n  color: #090;\n}\n.dropdown-menu:after {\n  border-color: transparent;\n  bottom: 100%;\n  content: \" \";\n  height: 0;\n  margin-left: -10px;\n  pointer-events: none;\n  position: absolute;\n  right: 10px;\n  width: 0;\n}\n.paddingrightleft_10 {\n  padding-left: 15px;\n  padding-right: 15px;\n}\n.paddingtopbottom_5px {\n  padding-bottom: 5px;\n  padding-top: 5px;\n}\n.plus-minus {\n  float: right;\n}\n.navbar-right .nav .open > a,\n.navbar-right .nav .open > a:hover,\n.navbar-right .nav .open > a:focus,\n.navbar-right .nav > li > a:hover,\n.navbar-right .nav > li > a:focus {\n  background-color: #2E576B;\n  border-color: #2E576B;\n}\n.riot {\n  color: #FFF;\n  padding: 7px 0 5px 45px;\n}\n.user_name_max {\n  max-width: 140px;\n  white-space: nowrap;\n  overflow: hidden !important;\n  text-overflow: ellipsis;\n  margin: 0 0 -1px;\n}\n.riot .caret {\n  margin-top: 0;\n}\n.navbar-nav > .user-menu > .dropdown-menu:after {\n  -moz-border-bottom-colors: none;\n  -moz-border-left-colors: none;\n  -moz-border-right-colors: none;\n  -moz-border-top-colors: none;\n  border-color: transparent;\n}\n.navbar-right .nav > li > a .black {\n  padding-top: 7px;\n  color: #FFF;\n  font-size: 17px;\n}\n.dropdown-messages {\n  min-width: 320px;\n}\n.dropdown-messages > li {\n  border-bottom: 1px solid #F5F5F5;\n}\n.dropdown-messages > li > .message {\n  line-height: 20px;\n  white-space: normal;\n  font-size: 11px;\n}\n.dropdown-messages > li:last-child {\n  border-bottom: none;\n}\n.dropdown-notifications {\n  min-width: 260px;\n}\n.msg-lable {\n  float: right;\n  margin-top: -19px;\n}\n.noti-date {\n  float: right;\n  margin-top: -37px;\n}\n.striped-col {\n  background-color: #F9F9F9;\n}\n.dropdown-menu > .dropdown-footer > a:hover,\n.dropdown-menu > .dropdown-footer > a:focus {\n  background-color: #2E576B;\n  color: #FFF;\n}\n\n/**** END HEADER RIGHT SIDE DROPDOWNS ****/\n/****** 4.LEFT SIDEBAR ******/\n.left-side {\n  position: absolute;\n  width: 250px;\n}\nli.active > a > .arrow {\n  position: absolute;\n  right: 15px;\n}\nli.active a,\na:hover,\na {\n  text-decoration: none !important;\n}\n.content-header h1 {\n  font-size: 22px;\n  line-height: 1.5;\n}\n.badge {\n  background-color: #66CC99;\n  font-weight: 400;\n  float: right;\n}\n.sub-menu {\n  list-style: none;\n  padding: 0;\n  margin: 0;\n}\n#menu li.active > a {\n  border-right: 3px solid #68DEB7;\n}\n#menu li.active > a {\n  background: #EEEEEE;\n  color: #33CC99;\n}\n#menu .profile-left li > a:hover {\n  color: #0A1414;\n}\n#menu li > a:hover {\n  color: #33CC99;\n}\n#menu .menu-dropdown > ul > li > a {\n  padding-left: 37px;\n}\n#menu .menu-dropdown > ul,\n#menu .menu-dropdown-open-ul {\n  background: #FFF;\n}\n#menu .navigation .menu-icon {\n  display: inline-block;\n  margin-right: 5px;\n  line-height: 20px;\n  height: 20px;\n  width: 20px;\n  text-align: center;\n  font-size: 16px;\n}\n#menu .navigation {\n  padding: 4px 0 15px;\n}\n#menu .navigation a {\n  text-align: left;\n  color: #666;\n  position: relative;\n  transition: all .2s;\n  display: block;\n  font-size: 13px;\n  line-height: 20px;\n  padding: 11px 20px;\n}\n#menu .fa.arrow:before {\n  content: \"\\f105\";\n}\n#menu .active > a > .fa.arrow:before {\n  content: \"\\f107\";\n}\n\n/******* END LEFT SIDEBAR *****/\n/********* 5. MAIN WRAPPER STYLES *********/\n.wrapper:before,\n.wrapper:after {\n  display: table;\n  content: \" \";\n}\n.wrapper:after {\n  clear: both;\n}\n\n/********* END MAIN WRAPPER STYLES *********/\n/********* 6. LEFT MENU COLLAPSE STYLES *********/\nbody > #app .header .navbar .sidebar-toggle {\n  float: left;\n  color: #FFF;\n  font-size: 23px;\n  font-weight: bold;\n  margin-left: 10px;\n}\nbody > #app .header .navbar .sidebar-toggle i {\n  vertical-align: middle;\n}\n\n/********* END LEFT MENU COLLAPSE STYLES *********/\n/*********7. CUSTOM STYLES *********/\n.modal-dialog {\n  margin: 60px 10px;\n}\n.progress_task {\n  margin-top: 8px;\n  margin-bottom: 12px;\n}\n.progress-xs {\n  height: 5px;\n}\n.animsition {\n  position: inherit;\n}\n.panel-heading small {\n  line-height: 23px;\n  font-size: 12px;\n}\n.clickable {\n  cursor: pointer;\n  font-size: 12px;\n}\n.panel-heading > span {\n  margin-top: -20px;\n  font-size: 15px;\n}\n.nav-tabs > li.active > a,\n.nav-tabs > li.active > a:hover,\n.nav-tabs > li.active > a:focus {\n  color: #555;\n  background-color: #FFF;\n  border-top: 3px solid #6699CC;\n  border-bottom-color: transparent;\n  cursor: default;\n  font-weight: 500;\n  margin-top: -2px;\n}\n.p-t-3 {\n  padding-top: 3px;\n}\n.p-10 {\n  padding: 10px;\n}\n.map_size {\n  width: 100%;\n  height: 350px;\n}\n.navbar-right {\n  margin-right: 0;\n}\n\n/* Users action icons*/\n.actions_icon {\n  cursor: pointer;\n}\n#advanced_map {\n  height: 350px;\n}\n.leaflet-top,\n.leaflet-bottom {\n  z-index: 400;\n}\n.m-t-10 {\n  margin-top: 10px !important;\n}\n.m-l-18 {\n  margin-left: 18px;\n}\n.text-white {\n  color: #FFFFFF;\n}\n.input-group-addon {\n  padding: 5px 12px;\n}\n.input-group-btn > .btn {\n  border-bottom: 2px solid transparent;\n}\n.radio label,\n.checkbox label,\n.checkbox-inline,\n.radio-inline {\n  padding-left: 0;\n}\n.m-t-25 {\n  margin-top: 25px;\n}\n\n/*\nCustomized Bootstrap toastr\n*/\n.radio,\n.checkbox {\n  display: inline;\n  min-height: 0;\n  margin-top: 10px;\n  margin-bottom: 10px;\n}\ndiv.radio,\ndiv.checker {\n  margin-right: 0;\n  margin-left: 3px;\n}\ndiv.selector,\ndiv.checker,\ndiv.button,\ndiv.uploader {\n  display: -moz-inline-box;\n  display: inline-block;\n  zoom: 1;\n  vertical-align: middle;\n}\n.resize_vertical {\n  resize: vertical;\n}\n.input-group-addon {\n  background-color: #DCDCDC;\n  border: 1px solid #CCC;\n}\n.m-t-6 {\n  margin-top: 6px;\n}\n.dataTables_length {\n  margin-top: 10px;\n}\n.table-responsive {\n  overflow-y: hidden;\n}\n.chartWindow {\n  border-radius: 5px;\n  border: 1px solid #E5E5E5;\n  margin-bottom: 15px;\n  overflow-x: auto;\n  overflow-y: hidden;\n}\n.right-side .label {\n  text-align: left;\n}\n.selectric-items {\n  width: 100% !important;\n}\n.multiselect-container > li > a {\n  padding: 5px;\n}\n.multiselect-item .multiselect-search {\n  height: 35px;\n}\n.btn_selection {\n  margin: 3px 0;\n}\nbody.fixed-layout > #app .header,\nbody.fixed-layout .left-side,\nbody.fixed-layout .navbar {\n  position: fixed;\n}\nbody.fixed-layout > #app .header {\n  top: 0;\n  right: 0;\n  left: 0;\n}\nbody.fixed-layout .navbar {\n  left: 0;\n  right: 0;\n}\nbody.fixed-layout .wrapper {\n  margin-top: 50px;\n}\n.padding-top {\n  padding-top: 50px;\n}\nbody.fixed-top > #app .header {\n  position: fixed;\n}\n.sub-submenu {\n  padding-left: 20px;\n}\n.p-l-40 {\n  padding-left: 40px;\n}\n#menu > .navigation .menu-dropdown .form-submenu > li > a {\n  padding-left: 55px;\n}\n\n/*image-magnifier*/\n.img_height {\n  height: 200px;\n}\n.magnify .magnify {\n  z-index: 2;\n}\n.magnify .magnify-large {\n  z-index: 4;\n}\n\n/* layout css ends*/\n/**** 8.MEDIA QUERIES ****/\n@media screen and (min-width: 993px) {\n.left-side {\n    top: 51px;\n}\n  /*Right side strech mode*/\n.right-side.strech {\n    margin-left: 0;\n}\n  /* Left side collapse */\n.left-side.collapse-left {\n    left: -250px;\n}\n}\n\n/*Give content full width on xs screens*/\n@media screen and (max-width: 992px) {\n.right-side {\n    margin-left: 0;\n}\n#menu {\n    padding-top: 54px;\n}\n}\n\n/*======pull modal below the fixed header=======*/\n@media screen and (min-width: 768px) {\n.modal-dialog {\n    margin: 70px auto;\n}\n}\n@media screen and (max-width: 560px) {\n.right-side {\n    padding: 107px 10px 10px 10px;\n}\n.modal-dialog {\n    margin: 115px 10px;\n}\n}\n\n/*\n* Off Canvas\n* --------------------------------------------------\n*  Gives us the push menu effect\n*/\n@media screen and (max-width: 992px) {\n.relative {\n    position: relative;\n}\n.row-offcanvas-right .sidebar-offcanvas {\n    right: -250px;\n}\n.row-offcanvas-left .sidebar-offcanvas {\n    left: -250px;\n}\n.row-offcanvas-right {\n    right: 250px;\n}\n.row-offcanvas-left {\n    left: 250px;\n}\n.sidebar-offcanvas {\n    left: 0;\n}\nbody.fixed .sidebar-offcanvas {\n    margin-top: 50px;\n    left: -250px;\n}\nbody.fixed .row-offcanvas-left .navbar {\n    left: 250px;\n    right: 0;\n}\nbody.fixed .row-offcanvas-left .sidebar-offcanvas {\n    left: 0;\n}\n}\n@media screen and (max-width: 767px) {\n.right-side > .content-header > .breadcrumb {\n    position: relative;\n    margin-top: 5px;\n    top: 0;\n    right: 0;\n    float: none;\n}\n.navbar .navbar-nav > li {\n    float: left;\n}\n.navbar-nav {\n    margin: 0;\n    float: left;\n}\n.navbar-nav > li > a {\n    padding-top: 15px;\n    padding-bottom: 15px;\n    line-height: 20px;\n}\n.navbar .navbar-right {\n    float: right;\n}\nbody > #app .header .navbar {\n    padding-left: 19px;\n    padding-right: 8px;\n}\n}\n\n/* Fix dropdown menu for small screens to display correctly on small screens */\n@media screen and (max-width: 767px) {\n.navbar-nav > .user-menu > .dropdown-menu,\n  .navbar-nav > .messages-menu > .dropdown-menu {\n    position: absolute;\n    top: 100%;\n    right: -120px;\n    left: auto;\n    background: #FFFFFF;\n}\n.navbar-nav > .user-menu > .dropdown-menu {\n    right: 0;\n}\n.navbar-nav .user-menu .dropdown-menu > li > a {\n    padding: 3px 20px;\n}\n.navbar-right .nav > li > a {\n    padding: 10px 12px;\n}\n}\n\n/* Fix menu positions on xs screens to appear correctly and fully */\n@media screen and (max-width: 560px) {\n.rightsidebar-right .rightsidebar-right-content {\n    padding-top: 105px;\n}\n.rightslider-p-t-small {\n    padding-top: 51px !important;\n}\n#menu {\n    padding-top: 104px;\n}\n}\n@media screen and (max-width: 480px) {\n.navbar-nav > .messages-menu > .dropdown-menu > li.header:after {\n    border-width: 0;\n}\n.navbar-nav > .messages-menu > .dropdown-menu {\n    position: absolute;\n    right: -190px;\n    left: auto;\n}\n}\n@media screen and (max-width: 560px) {\nbody > #app .header {\n    position: fixed;\n}\nbody > #app .header .logo,\n  body > #app .header .navbar {\n    width: 100%;\n    float: none;\n    position: relative;\n    height: initial;\n}\nbody > #app .header .navbar {\n    margin: 0;\n}\nbody.fixed > #app .header {\n    position: fixed;\n}\nbody.fixed > #app .wrapper,\n  body.fixed .sidebar-offcanvas {\n    margin-top: 100px;\n}\n}\n@media screen and (max-width: 350px) {\n.navbar-nav > .messages-menu > .dropdown-menu {\n    right: -213px;\n}\n}\n@media screen and (max-width: 360px) {\n#right .nav-tabs > li {\n    width: 89px;\n}\n}\n@media (min-width: 768px) {\nbody.boxed,\n  body.boxed .Footer,\n  body.boxed .navbar.navbar-fixed-top {\n    max-width: 650px;\n    margin-left: auto;\n    margin-right: auto;\n}\n}\n@media (min-width: 1024px) {\nbody.boxed,\n  body.boxed .Footer,\n  body.boxed .navbar.navbar-fixed-top {\n    max-width: 900px;\n    margin-left: auto;\n    margin-right: auto;\n}\n}\n@media (min-width: 1200px) {\nbody.boxed,\n  body.boxed .Footer,\n  body.boxed .navbar.navbar-fixed-top {\n    max-width: 1170px;\n    margin-left: auto;\n    margin-right: auto;\n}\n}\n@media (min-width: 1440px) and (max-width: 2560px) {\n#menu .menu-dropdown > ul,\n  #menu .menu-dropdown-open-ul {\n    margin-top: -1px;\n}\n}\n\n/****** END MEDIA QUERIES ****/\n/****** 9.PRELOADER ****/\n.preloader {\n  position: fixed;\n  width: 100%;\n  height: 100%;\n  top: 0;\n  left: 0;\n  z-index: 100001;\n  -webkit-backface-visibility: hidden;\n          backface-visibility: hidden;\n  background: #FFFFFF;\n}\n.loader_img {\n  width: 50px;\n  height: 50px;\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  background-position: center;\n  margin: -25px 0 0 -25px;\n}\n\n/****** END PRELOADER ****/\n", ""]);

/***/ }),

/***/ 525:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(1)();
exports.push([module.i, "\n.arrow {\n    float       : right;\n    line-height : 1.42857;\n}\n.glyphicon.arrow:before {\n    content : \"\\e079\";\n}\n.active > a > .glyphicon.arrow:before {\n    content : \"\\e114\";\n}\n/*\n * Require Font-Awesome\n * http://fortawesome.github.io/Font-Awesome/\n*/\n.fa.arrow:before {\n    content : \"+\";\n}\n.active > a > .fa.arrow:before {\n    content : \"\";\n}\n.plus-times {\n    float : right;\n}\n.fa.plus-times:before {\n    content : \"\\f067\";\n}\n.active > a > .fa.plus-times {\n    filter            : progid:DXImageTransform.Microsoft.BasicImage(rotation=1);\n    -webkit-transform : rotate(45deg);\n    transform         : rotate(45deg);\n}\n.plus-minus {\n    float : right;\n}\n.fa.plus-minus:before {\n    content : \"\\f067\";\n}\n.active > a > .fa.plus-minus:before {\n    content : \"\\f068\";\n}\n", ""]);

/***/ }),

/***/ 737:
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(jQuery) {/*! Copyright (c) 2011 Piotr Rochala (http://rocha.la)
 * Dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php)
 * and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.
 *
 * Version: 1.3.8
 *
 */
(function($) {

  $.fn.extend({
    slimScroll: function(options) {

      var defaults = {

        // width in pixels of the visible scroll area
        width : 'auto',

        // height in pixels of the visible scroll area
        height : '250px',

        // width in pixels of the scrollbar and rail
        size : '7px',

        // scrollbar color, accepts any hex/color value
        color: '#000',

        // scrollbar position - left/right
        position : 'right',

        // distance in pixels between the side edge and the scrollbar
        distance : '1px',

        // default scroll position on load - top / bottom / $('selector')
        start : 'top',

        // sets scrollbar opacity
        opacity : .4,

        // enables always-on mode for the scrollbar
        alwaysVisible : false,

        // check if we should hide the scrollbar when user is hovering over
        disableFadeOut : false,

        // sets visibility of the rail
        railVisible : false,

        // sets rail color
        railColor : '#333',

        // sets rail opacity
        railOpacity : .2,

        // whether  we should use jQuery UI Draggable to enable bar dragging
        railDraggable : true,

        // defautlt CSS class of the slimscroll rail
        railClass : 'slimScrollRail',

        // defautlt CSS class of the slimscroll bar
        barClass : 'slimScrollBar',

        // defautlt CSS class of the slimscroll wrapper
        wrapperClass : 'slimScrollDiv',

        // check if mousewheel should scroll the window if we reach top/bottom
        allowPageScroll : false,

        // scroll amount applied to each mouse wheel step
        wheelStep : 20,

        // scroll amount applied when user is using gestures
        touchScrollStep : 200,

        // sets border radius
        borderRadius: '7px',

        // sets border radius of the rail
        railBorderRadius : '7px'
      };

      var o = $.extend(defaults, options);

      // do it for every element that matches selector
      this.each(function(){

      var isOverPanel, isOverBar, isDragg, queueHide, touchDif,
        barHeight, percentScroll, lastScroll,
        divS = '<div></div>',
        minBarHeight = 30,
        releaseScroll = false;

        // used in event handlers and for better minification
        var me = $(this);

        // ensure we are not binding it again
        if (me.parent().hasClass(o.wrapperClass))
        {
            // start from last bar position
            var offset = me.scrollTop();

            // find bar and rail
            bar = me.siblings('.' + o.barClass);
            rail = me.siblings('.' + o.railClass);

            getBarHeight();

            // check if we should scroll existing instance
            if ($.isPlainObject(options))
            {
              // Pass height: auto to an existing slimscroll object to force a resize after contents have changed
              if ( 'height' in options && options.height == 'auto' ) {
                me.parent().css('height', 'auto');
                me.css('height', 'auto');
                var height = me.parent().parent().height();
                me.parent().css('height', height);
                me.css('height', height);
              } else if ('height' in options) {
                var h = options.height;
                me.parent().css('height', h);
                me.css('height', h);
              }

              if ('scrollTo' in options)
              {
                // jump to a static point
                offset = parseInt(o.scrollTo);
              }
              else if ('scrollBy' in options)
              {
                // jump by value pixels
                offset += parseInt(o.scrollBy);
              }
              else if ('destroy' in options)
              {
                // remove slimscroll elements
                bar.remove();
                rail.remove();
                me.unwrap();
                return;
              }

              // scroll content by the given offset
              scrollContent(offset, false, true);
            }

            return;
        }
        else if ($.isPlainObject(options))
        {
            if ('destroy' in options)
            {
            	return;
            }
        }

        // optionally set height to the parent's height
        o.height = (o.height == 'auto') ? me.parent().height() : o.height;

        // wrap content
        var wrapper = $(divS)
          .addClass(o.wrapperClass)
          .css({
            position: 'relative',
            overflow: 'hidden',
            width: o.width,
            height: o.height
          });

        // update style for the div
        me.css({
          overflow: 'hidden',
          width: o.width,
          height: o.height
        });

        // create scrollbar rail
        var rail = $(divS)
          .addClass(o.railClass)
          .css({
            width: o.size,
            height: '100%',
            position: 'absolute',
            top: 0,
            display: (o.alwaysVisible && o.railVisible) ? 'block' : 'none',
            'border-radius': o.railBorderRadius,
            background: o.railColor,
            opacity: o.railOpacity,
            zIndex: 90
          });

        // create scrollbar
        var bar = $(divS)
          .addClass(o.barClass)
          .css({
            background: o.color,
            width: o.size,
            position: 'absolute',
            top: 0,
            opacity: o.opacity,
            display: o.alwaysVisible ? 'block' : 'none',
            'border-radius' : o.borderRadius,
            BorderRadius: o.borderRadius,
            MozBorderRadius: o.borderRadius,
            WebkitBorderRadius: o.borderRadius,
            zIndex: 99
          });

        // set position
        var posCss = (o.position == 'right') ? { right: o.distance } : { left: o.distance };
        rail.css(posCss);
        bar.css(posCss);

        // wrap it
        me.wrap(wrapper);

        // append to parent div
        me.parent().append(bar);
        me.parent().append(rail);

        // make it draggable and no longer dependent on the jqueryUI
        if (o.railDraggable){
          bar.bind("mousedown", function(e) {
            var $doc = $(document);
            isDragg = true;
            t = parseFloat(bar.css('top'));
            pageY = e.pageY;

            $doc.bind("mousemove.slimscroll", function(e){
              currTop = t + e.pageY - pageY;
              bar.css('top', currTop);
              scrollContent(0, bar.position().top, false);// scroll content
            });

            $doc.bind("mouseup.slimscroll", function(e) {
              isDragg = false;hideBar();
              $doc.unbind('.slimscroll');
            });
            return false;
          }).bind("selectstart.slimscroll", function(e){
            e.stopPropagation();
            e.preventDefault();
            return false;
          });
        }

        // on rail over
        rail.hover(function(){
          showBar();
        }, function(){
          hideBar();
        });

        // on bar over
        bar.hover(function(){
          isOverBar = true;
        }, function(){
          isOverBar = false;
        });

        // show on parent mouseover
        me.hover(function(){
          isOverPanel = true;
          showBar();
          hideBar();
        }, function(){
          isOverPanel = false;
          hideBar();
        });

        // support for mobile
        me.bind('touchstart', function(e,b){
          if (e.originalEvent.touches.length)
          {
            // record where touch started
            touchDif = e.originalEvent.touches[0].pageY;
          }
        });

        me.bind('touchmove', function(e){
          // prevent scrolling the page if necessary
          if(!releaseScroll)
          {
  		      e.originalEvent.preventDefault();
		      }
          if (e.originalEvent.touches.length)
          {
            // see how far user swiped
            var diff = (touchDif - e.originalEvent.touches[0].pageY) / o.touchScrollStep;
            // scroll content
            scrollContent(diff, true);
            touchDif = e.originalEvent.touches[0].pageY;
          }
        });

        // set up initial height
        getBarHeight();

        // check start position
        if (o.start === 'bottom')
        {
          // scroll content to bottom
          bar.css({ top: me.outerHeight() - bar.outerHeight() });
          scrollContent(0, true);
        }
        else if (o.start !== 'top')
        {
          // assume jQuery selector
          scrollContent($(o.start).position().top, null, true);

          // make sure bar stays hidden
          if (!o.alwaysVisible) { bar.hide(); }
        }

        // attach scroll events
        attachWheel(this);

        function _onWheel(e)
        {
          // use mouse wheel only when mouse is over
          if (!isOverPanel) { return; }

          var e = e || window.event;

          var delta = 0;
          if (e.wheelDelta) { delta = -e.wheelDelta/120; }
          if (e.detail) { delta = e.detail / 3; }

          var target = e.target || e.srcTarget || e.srcElement;
          if ($(target).closest('.' + o.wrapperClass).is(me.parent())) {
            // scroll content
            scrollContent(delta, true);
          }

          // stop window scroll
          if (e.preventDefault && !releaseScroll) { e.preventDefault(); }
          if (!releaseScroll) { e.returnValue = false; }
        }

        function scrollContent(y, isWheel, isJump)
        {
          releaseScroll = false;
          var delta = y;
          var maxTop = me.outerHeight() - bar.outerHeight();

          if (isWheel)
          {
            // move bar with mouse wheel
            delta = parseInt(bar.css('top')) + y * parseInt(o.wheelStep) / 100 * bar.outerHeight();

            // move bar, make sure it doesn't go out
            delta = Math.min(Math.max(delta, 0), maxTop);

            // if scrolling down, make sure a fractional change to the
            // scroll position isn't rounded away when the scrollbar's CSS is set
            // this flooring of delta would happened automatically when
            // bar.css is set below, but we floor here for clarity
            delta = (y > 0) ? Math.ceil(delta) : Math.floor(delta);

            // scroll the scrollbar
            bar.css({ top: delta + 'px' });
          }

          // calculate actual scroll amount
          percentScroll = parseInt(bar.css('top')) / (me.outerHeight() - bar.outerHeight());
          delta = percentScroll * (me[0].scrollHeight - me.outerHeight());

          if (isJump)
          {
            delta = y;
            var offsetTop = delta / me[0].scrollHeight * me.outerHeight();
            offsetTop = Math.min(Math.max(offsetTop, 0), maxTop);
            bar.css({ top: offsetTop + 'px' });
          }

          // scroll content
          me.scrollTop(delta);

          // fire scrolling event
          me.trigger('slimscrolling', ~~delta);

          // ensure bar is visible
          showBar();

          // trigger hide when scroll is stopped
          hideBar();
        }

        function attachWheel(target)
        {
          if (window.addEventListener)
          {
            target.addEventListener('DOMMouseScroll', _onWheel, false );
            target.addEventListener('mousewheel', _onWheel, false );
          }
          else
          {
            document.attachEvent("onmousewheel", _onWheel)
          }
        }

        function getBarHeight()
        {
          // calculate scrollbar height and make sure it is not too small
          barHeight = Math.max((me.outerHeight() / me[0].scrollHeight) * me.outerHeight(), minBarHeight);
          bar.css({ height: barHeight + 'px' });

          // hide scrollbar if content is not long enough
          var display = barHeight == me.outerHeight() ? 'none' : 'block';
          bar.css({ display: display });
        }

        function showBar()
        {
          // recalculate bar height
          getBarHeight();
          clearTimeout(queueHide);

          // when bar reached top or bottom
          if (percentScroll == ~~percentScroll)
          {
            //release wheel
            releaseScroll = o.allowPageScroll;

            // publish approporiate event
            if (lastScroll != percentScroll)
            {
                var msg = (~~percentScroll == 0) ? 'top' : 'bottom';
                me.trigger('slimscroll', msg);
            }
          }
          else
          {
            releaseScroll = false;
          }
          lastScroll = percentScroll;

          // show only when required
          if(barHeight >= me.outerHeight()) {
            //allow window scroll
            releaseScroll = true;
            return;
          }
          bar.stop(true,true).fadeIn('fast');
          if (o.railVisible) { rail.stop(true,true).fadeIn('fast'); }
        }

        function hideBar()
        {
          // only hide when options allow it
          if (!o.alwaysVisible)
          {
            queueHide = setTimeout(function(){
              if (!(o.disableFadeOut && isOverPanel) && !isOverBar && !isDragg)
              {
                bar.fadeOut('slow');
                rail.fadeOut('slow');
              }
            }, 1000);
          }
        }

      });

      // maintain chainability
      return this;
    }
  });

  $.fn.extend({
    slimscroll: $.fn.slimScroll
  });

})(jQuery);

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(0)))

/***/ }),

/***/ 741:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(487);
if(typeof content === 'string') content = [[module.i, content, '']];
// add the styles to the DOM
var update = __webpack_require__(247)(content, {});
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../../../css-loader/index.js!./bootstrap-switch.min.css", function() {
			var newContent = require("!!../../../../css-loader/index.js!./bootstrap-switch.min.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 754:
/***/ (function(module, exports, __webpack_require__) {

var Component = __webpack_require__(3)(
  /* script */
  __webpack_require__(397),
  /* template */
  __webpack_require__(839),
  /* scopeId */
  null,
  /* cssModules */
  null
)
Component.options.__file = "/var/www/html/clear-vue-laravel/resources/assets/components/layout/clear_header.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] clear_header.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-f4df8e1c", Component.options)
  } else {
    hotAPI.reload("data-v-f4df8e1c", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),

/***/ 755:
/***/ (function(module, exports, __webpack_require__) {

var Component = __webpack_require__(3)(
  /* script */
  __webpack_require__(398),
  /* template */
  __webpack_require__(772),
  /* scopeId */
  null,
  /* cssModules */
  null
)
Component.options.__file = "/var/www/html/clear-vue-laravel/resources/assets/components/layout/left-side.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] left-side.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-246eff8c", Component.options)
  } else {
    hotAPI.reload("data-v-246eff8c", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),

/***/ 756:
/***/ (function(module, exports, __webpack_require__) {

var Component = __webpack_require__(3)(
  /* script */
  __webpack_require__(399),
  /* template */
  __webpack_require__(778),
  /* scopeId */
  null,
  /* cssModules */
  null
)
Component.options.__file = "/var/www/html/clear-vue-laravel/resources/assets/components/layout/right-side.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] right-side.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-2ba40cdb", Component.options)
  } else {
    hotAPI.reload("data-v-2ba40cdb", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),

/***/ 772:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('aside', {
    staticClass: "left-side sidebar-offcanvas"
  }, [_c('section', {
    staticClass: "sidebar"
  }, [_c('div', {
    attrs: {
      "id": "menu",
      "role": "navigation"
    }
  }, [_c('div', {
    staticClass: "nav_profile"
  }, [_c('div', {
    staticClass: "media profile-left"
  }, [_c('a', {
    staticClass: "pull-left profile-thumb",
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('img', {
    staticClass: "img-circle",
    attrs: {
      "src": this.$store.state.user.picture,
      "alt": "User Image"
    }
  })]), _vm._v(" "), _c('div', {
    staticClass: "content-profile"
  }, [_c('h4', {
    staticClass: "media-heading user_name_max",
    domProps: {
      "textContent": _vm._s(this.$store.state.user.name)
    }
  }), _vm._v(" "), _c('ul', {
    staticClass: "icon-list"
  }, [_c('li', [_c('router-link', {
    attrs: {
      "to": "/users_list",
      "exact": ""
    }
  }, [_c('i', {
    staticClass: "ti-user"
  })])], 1), _vm._v(" "), _c('li', [_c('router-link', {
    attrs: {
      "to": "/lockscreen",
      "exact": ""
    }
  }, [_c('i', {
    staticClass: "ti-lock"
  })])], 1), _vm._v(" "), _c('li', [_c('router-link', {
    attrs: {
      "to": "/edit_user",
      "exact": ""
    }
  }, [_c('i', {
    staticClass: "ti-settings"
  })])], 1), _vm._v(" "), _c('li', [_c('router-link', {
    attrs: {
      "to": "/login",
      "exact": ""
    }
  }, [_c('i', {
    staticClass: "ti-shift-right"
  })])], 1)])])])]), _vm._v(" "), _c('ul', {
    staticClass: "navigation"
  }, [_c('router-link', {
    attrs: {
      "to": "/",
      "tag": "li",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-desktop"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v("Dashboard 1")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/index2",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-layout-list-large-image"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v("Dashboard 2")])])]), _vm._v(" "), _c('li', {
    staticClass: "menu-dropdown"
  }, [_vm._m(0), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu"
  }, [_c('li', [_vm._m(1), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu form-submenu"
  }, [_c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/form-elements",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-cup"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Form Elements")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/realtime_form",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-write"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Realtime Forms")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/form-validations",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-alert"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Form validations")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/form_layouts",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-layout-width-default"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Form Layouts")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/complex_forms",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-layout-cta-left"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Complex Forms")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/radio_check",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-check-box"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Radio and Checkbox")])])])], 1)]), _vm._v(" "), _c('li', [_vm._m(2), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu form-submenu"
  }, [_c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/form_editors",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-pencil"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Form Editors")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/form_wizards",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-settings"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Form Wizards")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/dropdowns",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-widget-alt"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Drop Downs")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/vue_multiselect",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-widget-alt"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Vue Multiselect")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/vue_slider",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-bell"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Vue Slider")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/vscroll",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-list"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Vscroll")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/date_pickers",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-calendar"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Date pickers")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/advanced_date_pickers",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-notepad"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Advanced Date pickers")])])])], 1)])])]), _vm._v(" "), _c('li', {
    staticClass: "menu-dropdown"
  }, [_vm._m(3), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu"
  }, [_c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/general_components",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-plug"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" General Components")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/buttons",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-layout-placeholder"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Buttons")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/tabs_accordions",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-layers"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Tabs & Accordions")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/font_icons",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-ink-pen"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Font Icons")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/advanced_modals",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-brush-alt"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Advanced Modals")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/timeline",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-time"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Timeline")])])])], 1)]), _vm._v(" "), _c('li', {
    staticClass: "menu-dropdown"
  }, [_vm._m(4), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu"
  }, [_c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/pickers",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-brush"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Pickers")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/grid_layout",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-layout-grid2"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Grid Layout")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/tags_input",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-tag"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Tags Input")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/nestable_list",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-view-list"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Nestable List")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/sweet_alert",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-bell"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Sweet Alert")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/toastr_notifications",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-tablet"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Toastr Notifications")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/draggable_portlets",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-control-shuffle"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Draggable Portlets")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/transitions",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-star"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Transitions")])])])], 1)]), _vm._v(" "), _c('router-link', {
    attrs: {
      "to": "/widgets",
      "tag": "li",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-widgetized"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v("Widgets ")])])]), _vm._v(" "), _c('li', {
    staticClass: "menu-dropdown"
  }, [_vm._m(5), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu"
  }, [_c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/simple_tables",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-layout"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Simple tables")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/datatables",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-server"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Data Tables")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/advanced_datatables",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-layout-grid3"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Advanced Tables")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/responsive_datatables",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-layout-accordion-merged"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Responsive DataTables")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/bootstrap_tables",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-layout-grid2"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Bootstrap Tables")])])])], 1)]), _vm._v(" "), _c('li', {
    staticClass: "menu-dropdown"
  }, [_vm._m(6), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu"
  }, [_c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/flot_charts",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-bar-chart-alt"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Flot Charts")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/nvd3_charts",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-stats-up"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" NVD3 Charts")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/circle_sliders",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-basketball"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Circle Sliders")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/chartjs",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-pie-chart"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Chartjs Charts")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/chartist",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-bar-chart"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Chartist Charts")])])])], 1)]), _vm._v(" "), _c('li', {
    staticClass: "menu-dropdown"
  }, [_vm._m(7), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu"
  }, [_c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/calendar",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-video-clapper"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Calendar")]), _c('small', {
    staticClass: "badge badge1"
  }, [_vm._v("7")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/calendar2",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-calendar"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Calendar2")]), _c('small', {
    staticClass: "badge badge2"
  }, [_vm._v("7")])])])], 1)]), _vm._v(" "), _c('li', {
    staticClass: "menu-dropdown"
  }, [_vm._m(8), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu"
  }, [_c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/masonry_gallery",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-gallery"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Masonry Gallery")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/dropify",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-dropbox"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Dropify")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/image_hover",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-image"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Image Hover")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/image_filter",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-filter"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Image Filter")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/image_magnifier",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-zoom-in"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Image Magnifier")])])])], 1)]), _vm._v(" "), _c('li', {
    staticClass: "menu-dropdown"
  }, [_vm._m(9), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu"
  }, [_c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/users_list",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-menu-alt"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Users List")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/addnew_user",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-user"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Add New User")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/user_profile",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-id-badge"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" View Profile")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/deleted_users",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-trash"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Deleted Users")])])])], 1)]), _vm._v(" "), _c('li', {
    staticClass: "menu-dropdown"
  }, [_vm._m(10), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu"
  }, [_c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/gmaps",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-world"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Google Maps")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/vector_maps",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-map"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Vector Maps")])])])], 1)]), _vm._v(" "), _c('li', {
    staticClass: "menu-dropdown"
  }, [_vm._m(11), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu"
  }, [_c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/login",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-shift-right"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Login")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/register",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-check-box"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Register")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/reset_password",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-help"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Forgot Password")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/lockscreen",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-lock"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Lockscreen")])])])], 1)]), _vm._v(" "), _c('li', {
    staticClass: "menu-dropdown"
  }, [_vm._m(12), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu"
  }, [_c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/blank",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-file"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Blank page")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/invoice",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-layout-cta-left"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Invoice")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/pricing",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-time"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Pricing Table")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/404",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-unlink"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" 404 Error")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/500",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-face-sad"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" 500 Error")])])])], 1)]), _vm._v(" "), _c('li', {
    staticClass: "menu-dropdown"
  }, [_vm._m(13), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu"
  }, [_c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/menubar_fold",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-layout-menu-v"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Menubar Fold")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/boxed",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-view-list"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Boxed Layout")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/fixed_menu",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-layout-column2"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Fixed Menu")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/movable_header",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-view-list-alt"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Movable Header")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/boxed_movableheader",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-view-list-alt"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Boxed & Movable Header")])])]), _vm._v(" "), _c('router-link', {
    attrs: {
      "tag": "li",
      "to": "/mini_sidebar",
      "exact": ""
    }
  }, [_c('a', {
    staticClass: "logo"
  }, [_c('i', {
    staticClass: "menu-icon ti-layout-menu-v"
  }), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v(" Mini Sidebar")])])])], 1)]), _vm._v(" "), _vm._m(14)], 1)])])])
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "menu-icon ti-check-box"
  }), _vm._v(" "), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v("Forms")]), _vm._v(" "), _c('span', {
    staticClass: "fa arrow"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-receipt"
  }), _vm._v(" Features\n                                "), _c('span', {
    staticClass: "fa arrow"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-clipboard"
  }), _vm._v(" Components\n                                "), _c('span', {
    staticClass: "fa arrow"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "menu-icon ti-desktop"
  }), _vm._v(" "), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v("UI Features")]), _vm._v(" "), _c('span', {
    staticClass: "fa arrow"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "menu-icon ti-briefcase"
  }), _vm._v(" "), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v("UI Components")]), _vm._v(" "), _c('span', {
    staticClass: "fa arrow"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "menu-icon ti-layout-grid4"
  }), _vm._v(" "), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v("DataTables")]), _vm._v(" "), _c('span', {
    staticClass: "fa arrow"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "menu-icon ti-bar-chart"
  }), _vm._v(" "), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v("Charts")]), _vm._v(" "), _c('span', {
    staticClass: "fa arrow"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "menu-icon ti-calendar"
  }), _vm._v(" "), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v("Calendar")]), _vm._v(" "), _c('span', {
    staticClass: "fa arrow"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "menu-icon ti-gallery"
  }), _vm._v(" "), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v("Gallery")]), _vm._v(" "), _c('span', {
    staticClass: "fa arrow"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "menu-icon ti-user"
  }), _vm._v(" "), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v("Users")]), _vm._v(" "), _c('span', {
    staticClass: "fa arrow"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "menu-icon ti-location-pin"
  }), _vm._v(" "), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v("Maps")]), _vm._v(" "), _c('span', {
    staticClass: "fa arrow"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "menu-icon ti-files"
  }), _vm._v(" "), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v("Pages")]), _vm._v(" "), _c('span', {
    staticClass: "fa arrow"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "menu-icon ti-face-smile"
  }), _vm._v(" "), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v("Extra Pages")]), _vm._v(" "), _c('span', {
    staticClass: "fa arrow"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "menu-icon ti-layout-grid3"
  }), _vm._v(" "), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v("Layouts")]), _vm._v(" "), _c('span', {
    staticClass: "fa arrow"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('li', {
    staticClass: "menu-dropdown"
  }, [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "menu-icon ti-menu"
  }), _vm._v(" "), _c('span', {
    staticClass: "mm-text"
  }, [_vm._v("Menu levels")]), _vm._v(" "), _c('span', {
    staticClass: "fa arrow"
  })]), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu"
  }, [_c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 1\n                                "), _c('span', {
    staticClass: "fa arrow"
  })]), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu sub-submenu"
  }, [_c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 2\n                                    ")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 2\n                                    ")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 2\n                                        "), _c('span', {
    staticClass: "fa arrow"
  })]), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu sub-submenu"
  }, [_c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 3\n                                            ")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 3\n                                            ")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 3\n                                                "), _c('span', {
    staticClass: "fa arrow"
  })]), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu sub-submenu"
  }, [_c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 4\n                                                    ")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 4\n                                                    ")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 4\n                                                        "), _c('span', {
    staticClass: "fa arrow"
  })]), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu sub-submenu"
  }, [_c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 5\n                                                            ")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 5\n                                                            ")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 5\n                                                            ")])])])])])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 4\n                                            ")])])])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 2\n                                    ")])])])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 1\n                            ")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 1\n                                "), _c('span', {
    staticClass: "fa arrow"
  })]), _vm._v(" "), _c('ul', {
    staticClass: "sub-menu sub-submenu"
  }, [_c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 2\n                                    ")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 2\n                                    ")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-vector"
  }), _vm._v(" Level 2\n                                    ")])])])])])])
}]}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-246eff8c", module.exports)
  }
}

/***/ }),

/***/ 775:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('clear_header'), _vm._v(" "), _c('div', {
    staticClass: "wrapper row-offcanvas row-offcanvas-left"
  }, [_c('left_side'), _vm._v(" "), _c('right_side', [_c('router-view')], 1)], 1), _vm._v(" "), _c('div', {
    staticClass: "background-overlay",
    on: {
      "click": _vm.right_close
    }
  })], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-27913e91", module.exports)
  }
}

/***/ }),

/***/ 778:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('aside', {
    staticClass: "right-side"
  }, [_c('section', {
    staticClass: "content-header"
  }, [_c('h1', {
    domProps: {
      "innerHTML": _vm._s(this.$route.meta.title)
    }
  }, [_vm._v("Title")]), _vm._v(" "), _c('ol', {
    staticClass: "breadcrumb",
    domProps: {
      "innerHTML": _vm._s(this.$route.meta.breadcrumb)
    }
  })]), _vm._v(" "), _c('section', {
    staticClass: "content"
  }, [_vm._t("default"), _vm._v(" "), _c('div', {
    attrs: {
      "id": "right"
    }
  }, [_c('div', {
    attrs: {
      "id": "right-slim"
    }
  }, [_c('div', {
    staticClass: "rightsidebar-right"
  }, [_c('div', {
    staticClass: "rightsidebar-right-content"
  }, [_vm._m(0), _vm._v(" "), _c('div', {
    staticClass: "tab-content"
  }, [_vm._m(1), _vm._v(" "), _vm._m(2), _vm._v(" "), _c('div', {
    staticClass: "tab-pane fade",
    attrs: {
      "id": "r_tab3"
    }
  }, [_c('div', {
    attrs: {
      "id": "slim_t3"
    }
  }, [_vm._m(3), _vm._v(" "), _c('ul', [_c('li', {
    staticClass: "setting-color"
  }, [_c('label', {
    staticClass: "active-color"
  }, [_c('input', {
    attrs: {
      "name": "skins",
      "type": "radio",
      "value": "skin-default",
      "checked": "checked"
    },
    on: {
      "change": _vm.change_skin
    }
  }), _vm._v(" "), _vm._m(4), _vm._v(" "), _c('span', {
    staticClass: "color l-m-bg"
  })]), _vm._v(" "), _c('label', [_c('input', {
    attrs: {
      "name": "skins",
      "type": "radio",
      "value": "skin-mint"
    },
    on: {
      "change": _vm.change_skin
    }
  }), _vm._v(" "), _vm._m(5), _vm._v(" "), _c('span', {
    staticClass: "color l-m-bg"
  })]), _vm._v(" "), _c('label', [_c('input', {
    attrs: {
      "name": "skins",
      "type": "radio",
      "value": "skin-grape"
    },
    on: {
      "change": _vm.change_skin
    }
  }), _vm._v(" "), _vm._m(6), _vm._v(" "), _c('span', {
    staticClass: "color l-m-bg"
  })])]), _vm._v(" "), _c('li', {
    staticClass: "setting-color"
  }, [_c('label', [_c('input', {
    attrs: {
      "name": "skins",
      "type": "radio",
      "value": "skin-lavender"
    },
    on: {
      "change": _vm.change_skin
    }
  }), _vm._v(" "), _vm._m(7), _vm._v(" "), _c('span', {
    staticClass: "color l-m-bg"
  })]), _vm._v(" "), _c('label', [_c('input', {
    attrs: {
      "name": "skins",
      "type": "radio",
      "value": "skin-pink"
    },
    on: {
      "change": _vm.change_skin
    }
  }), _vm._v(" "), _vm._m(8), _vm._v(" "), _c('span', {
    staticClass: "color l-m-bg"
  })]), _vm._v(" "), _c('label', [_c('input', {
    attrs: {
      "name": "skins",
      "type": "radio",
      "value": "skin-sunflower"
    },
    on: {
      "change": _vm.change_skin
    }
  }), _vm._v(" "), _vm._m(9), _vm._v(" "), _c('span', {
    staticClass: "color l-m-bg"
  })])])]), _vm._v(" "), _vm._m(10), _vm._v(" "), _vm._m(11), _vm._v(" "), _vm._m(12), _vm._v(" "), _vm._m(13)])])])])])])])], 2)])
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "panel-tabs"
  }, [_c('ul', {
    staticClass: "nav nav-tabs nav-float",
    attrs: {
      "role": "tablist"
    }
  }, [_c('li', {
    staticClass: "active text-center"
  }, [_c('a', {
    attrs: {
      "href": "#r_tab1",
      "role": "tab",
      "data-toggle": "tab"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-comments"
  })])]), _vm._v(" "), _c('li', {
    staticClass: "text-center"
  }, [_c('a', {
    attrs: {
      "href": "#r_tab2",
      "role": "tab",
      "data-toggle": "tab"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-bell"
  })])]), _vm._v(" "), _c('li', {
    staticClass: "text-center"
  }, [_c('a', {
    attrs: {
      "href": "#r_tab3",
      "role": "tab",
      "data-toggle": "tab"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-settings"
  })])])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "tab-pane fade in active",
    attrs: {
      "id": "r_tab1"
    }
  }, [_c('div', {
    attrs: {
      "id": "slim_t1"
    }
  }, [_c('h5', {
    staticClass: "rightsidebar-right-heading text-uppercase text-xs"
  }, [_c('i', {
    staticClass: "menu-icon  fa fa-fw ti-user"
  }), _vm._v("\n                                        Contacts\n                                    ")]), _vm._v(" "), _c('ul', {
    staticClass: "list-unstyled margin-none"
  }, [_c('li', {
    staticClass: "rightsidebar-contact-wrapper"
  }, [_c('a', {
    staticClass: "rightsidebar-contact",
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('img', {
    staticClass: "img-circle pull-right",
    attrs: {
      "src": __webpack_require__(267),
      "alt": "avatar-image"
    }
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-circle text-xs text-primary"
  }), _vm._v(" Annette\n                                            ")])]), _vm._v(" "), _c('li', {
    staticClass: "rightsidebar-contact-wrapper"
  }, [_c('a', {
    staticClass: "rightsidebar-contact",
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('img', {
    staticClass: "img-circle pull-right",
    attrs: {
      "src": __webpack_require__(242),
      "alt": "avatar-image"
    }
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-circle text-xs text-primary"
  }), _vm._v(" Jordan\n                                            ")])]), _vm._v(" "), _c('li', {
    staticClass: "rightsidebar-contact-wrapper"
  }, [_c('a', {
    staticClass: "rightsidebar-contact",
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('img', {
    staticClass: "img-circle pull-right",
    attrs: {
      "src": __webpack_require__(244),
      "alt": "avatar-image"
    }
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-circle text-xs text-primary"
  }), _vm._v(" Stewart\n                                            ")])]), _vm._v(" "), _c('li', {
    staticClass: "rightsidebar-contact-wrapper"
  }, [_c('a', {
    staticClass: "rightsidebar-contact",
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('img', {
    staticClass: "img-circle pull-right",
    attrs: {
      "src": __webpack_require__(245),
      "alt": "avatar-image"
    }
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-circle text-xs text-warning"
  }), _vm._v(" Alfred\n                                            ")])]), _vm._v(" "), _c('li', {
    staticClass: "rightsidebar-contact-wrapper"
  }, [_c('a', {
    staticClass: "rightsidebar-contact",
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('img', {
    staticClass: "img-circle pull-right",
    attrs: {
      "src": __webpack_require__(251),
      "alt": "avatar-image"
    }
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-circle text-xs text-danger"
  }), _vm._v(" Eileen\n                                            ")])]), _vm._v(" "), _c('li', {
    staticClass: "rightsidebar-contact-wrapper"
  }, [_c('a', {
    staticClass: "rightsidebar-contact",
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('img', {
    staticClass: "img-circle pull-right",
    attrs: {
      "src": __webpack_require__(259),
      "alt": "avatar-image"
    }
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-circle text-xs text-muted"
  }), _vm._v(" Robert\n                                            ")])]), _vm._v(" "), _c('li', {
    staticClass: "rightsidebar-contact-wrapper"
  }, [_c('a', {
    staticClass: "rightsidebar-contact",
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('img', {
    staticClass: "img-circle pull-right",
    attrs: {
      "src": __webpack_require__(260),
      "alt": "avatar-image"
    }
  }), _vm._v(" "), _c('i', {
    staticClass: "fa fa-circle text-xs text-muted"
  }), _vm._v(" Cassandra\n                                            ")])])]), _vm._v(" "), _c('h5', {
    staticClass: "rightsidebar-right-heading text-uppercase text-xs"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-export"
  }), _vm._v("\n                                        Recent Updates\n                                    ")]), _vm._v(" "), _c('div', [_c('ul', {
    staticClass: "list-unstyled"
  }, [_c('li', {
    staticClass: "rightsidebar-notification"
  }, [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa ti-comments-smiley fa-fw text-primary"
  }), _vm._v(" New Comment\n                                                ")])]), _vm._v(" "), _c('li', {
    staticClass: "rightsidebar-notification"
  }, [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa ti-twitter-alt fa-fw text-success"
  }), _vm._v(" 3 New Followers\n                                                ")])]), _vm._v(" "), _c('li', {
    staticClass: "rightsidebar-notification"
  }, [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa ti-email fa-fw text-info"
  }), _vm._v(" Message Sent\n                                                ")])]), _vm._v(" "), _c('li', {
    staticClass: "rightsidebar-notification"
  }, [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa ti-write fa-fw text-warning"
  }), _vm._v(" New Task\n                                                ")])]), _vm._v(" "), _c('li', {
    staticClass: "rightsidebar-notification"
  }, [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa ti-export fa-fw text-danger"
  }), _vm._v(" Server Rebooted\n                                                ")])]), _vm._v(" "), _c('li', {
    staticClass: "rightsidebar-notification"
  }, [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa ti-info-alt fa-fw text-primary"
  }), _vm._v(" Server Not Responding\n                                                ")])]), _vm._v(" "), _c('li', {
    staticClass: "rightsidebar-notification"
  }, [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa ti-shopping-cart fa-fw text-success"
  }), _vm._v(" New Order Placed\n                                                ")])]), _vm._v(" "), _c('li', {
    staticClass: "rightsidebar-notification"
  }, [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_c('i', {
    staticClass: "fa ti-money fa-fw text-info"
  }), _vm._v(" Payment Received\n                                                ")])])])])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "tab-pane fade",
    attrs: {
      "id": "r_tab2"
    }
  }, [_c('div', {
    attrs: {
      "id": "slim_t2"
    }
  }, [_c('h5', {
    staticClass: "rightsidebar-right-heading text-uppercase text-xs"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-bell"
  }), _vm._v("\n                                        Notifications\n                                    ")]), _vm._v(" "), _c('ul', {
    staticClass: "list-unstyled m-t-15 notifications"
  }, [_c('li', [_c('a', {
    staticClass: "message icon-not striped-col",
    attrs: {
      "href": ""
    }
  }, [_c('img', {
    staticClass: "message-image img-circle",
    attrs: {
      "src": __webpack_require__(245),
      "alt": "avatar-image"
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "message-body"
  }, [_c('strong', [_vm._v("John Doe")]), _vm._v(" "), _c('br'), _vm._v(" 5 members joined today\n                                                    "), _c('br'), _vm._v(" "), _c('small', {
    staticClass: "noti-date"
  }, [_vm._v("Just now")])])])]), _vm._v(" "), _c('li', [_c('a', {
    staticClass: "message icon-not",
    attrs: {
      "href": ""
    }
  }, [_c('img', {
    staticClass: "message-image img-circle",
    attrs: {
      "src": __webpack_require__(242),
      "alt": "avatar-image"
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "message-body"
  }, [_c('strong', [_vm._v("Tony")]), _vm._v(" "), _c('br'), _vm._v(" likes a photo of you\n                                                    "), _c('br'), _vm._v(" "), _c('small', {
    staticClass: "noti-date"
  }, [_vm._v("5 min")])])])]), _vm._v(" "), _c('li', [_c('a', {
    staticClass: "message icon-not striped-col",
    attrs: {
      "href": ""
    }
  }, [_c('img', {
    staticClass: "message-image img-circle",
    attrs: {
      "src": __webpack_require__(267),
      "alt": "avatar-image"
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "message-body"
  }, [_c('strong', [_vm._v("John")]), _vm._v(" "), _c('br'), _vm._v(" Dont forgot to call...\n                                                    "), _c('br'), _vm._v(" "), _c('small', {
    staticClass: "noti-date"
  }, [_vm._v("11 min")])])])]), _vm._v(" "), _c('li', [_c('a', {
    staticClass: "message icon-not",
    attrs: {
      "href": ""
    }
  }, [_c('img', {
    staticClass: "message-image img-circle",
    attrs: {
      "src": __webpack_require__(9),
      "alt": "avatar-image"
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "message-body"
  }, [_c('strong', [_vm._v("Jenny Kerry")]), _vm._v(" "), _c('br'), _vm._v(" Done with it...\n                                                    "), _c('br'), _vm._v(" "), _c('small', {
    staticClass: "noti-date"
  }, [_vm._v("1 Hour")])])])]), _vm._v(" "), _c('li', [_c('a', {
    staticClass: "message icon-not striped-col",
    attrs: {
      "href": ""
    }
  }, [_c('img', {
    staticClass: "message-image img-circle",
    attrs: {
      "src": __webpack_require__(260),
      "alt": "avatar-image"
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "message-body"
  }, [_c('strong', [_vm._v("Ernest Kerry")]), _vm._v(" "), _c('br'), _vm._v(" 2 members joined today\n                                                    "), _c('br'), _vm._v(" "), _c('small', {
    staticClass: "noti-date"
  }, [_vm._v("3 Days")])])])]), _vm._v(" "), _c('li', {
    staticClass: "text-right noti-footer"
  }, [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_vm._v("View All Notifications "), _c('i', {
    staticClass: "ti-arrow-right"
  })])])]), _vm._v(" "), _c('h5', {
    staticClass: "rightsidebar-right-heading text-uppercase text-xs"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-check-box"
  }), _vm._v("\n                                        Tasks\n                                    ")]), _vm._v(" "), _c('ul', {
    staticClass: "list-unstyled m-t-15"
  }, [_c('li', [_c('div', [_c('p', [_c('span', [_vm._v("Button Design")]), _vm._v(" "), _c('small', {
    staticClass: "pull-right text-muted"
  }, [_vm._v("40%")])]), _vm._v(" "), _c('div', {
    staticClass: "progress progress-xs progress-striped active"
  }, [_c('div', {
    staticClass: "progress-bar progress-bar-success",
    staticStyle: {
      "width": "40%"
    },
    attrs: {
      "role": "progressbar",
      "aria-valuenow": "40",
      "aria-valuemin": "0",
      "aria-valuemax": "100"
    }
  }, [_c('span', {
    staticClass: "sr-only"
  }, [_vm._v("40% Complete (success)")])])])])]), _vm._v(" "), _c('li', [_c('div', [_c('p', [_c('span', [_vm._v("Theme Creation")]), _vm._v(" "), _c('small', {
    staticClass: "pull-right text-muted"
  }, [_vm._v("20%")])]), _vm._v(" "), _c('div', {
    staticClass: "progress progress-xs progress-striped active"
  }, [_c('div', {
    staticClass: "progress-bar progress-bar-info",
    staticStyle: {
      "width": "20%"
    },
    attrs: {
      "role": "progressbar",
      "aria-valuenow": "20",
      "aria-valuemin": "0",
      "aria-valuemax": "100"
    }
  }, [_c('span', {
    staticClass: "sr-only"
  }, [_vm._v("20% Complete")])])])])]), _vm._v(" "), _c('li', [_c('div', [_c('p', [_c('span', [_vm._v("XYZ Task To Do")]), _vm._v(" "), _c('small', {
    staticClass: "pull-right text-muted"
  }, [_vm._v("60%")])]), _vm._v(" "), _c('div', {
    staticClass: "progress progress-xs progress-striped active"
  }, [_c('div', {
    staticClass: "progress-bar progress-bar-warning",
    staticStyle: {
      "width": "60%"
    },
    attrs: {
      "role": "progressbar",
      "aria-valuenow": "60",
      "aria-valuemin": "0",
      "aria-valuemax": "100"
    }
  }, [_c('span', {
    staticClass: "sr-only"
  }, [_vm._v("60% Complete (warning)")])])])])]), _vm._v(" "), _c('li', [_c('div', [_c('p', [_c('span', [_vm._v("Transitions Creation")]), _vm._v(" "), _c('small', {
    staticClass: "pull-right text-muted"
  }, [_vm._v("80%")])]), _vm._v(" "), _c('div', {
    staticClass: "progress progress-xs progress-striped active"
  }, [_c('div', {
    staticClass: "progress-bar progress-bar-danger",
    staticStyle: {
      "width": "80%"
    },
    attrs: {
      "role": "progressbar",
      "aria-valuenow": "80",
      "aria-valuemin": "0",
      "aria-valuemax": "100"
    }
  }, [_c('span', {
    staticClass: "sr-only"
  }, [_vm._v("80% Complete (danger)")])])])])]), _vm._v(" "), _c('li', {
    staticClass: "text-right"
  }, [_c('a', {
    attrs: {
      "href": "javascript:void(0)"
    }
  }, [_vm._v("View All Tasks "), _c('i', {
    staticClass: "ti-arrow-right"
  })])])])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('h5', {
    staticClass: "rightsidebar-right-heading text-uppercase text-xs"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-layers"
  }), _vm._v("\n                                        Skins\n                                    ")])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('span', {
    staticClass: "split"
  }, [_c('span', {
    staticClass: "color bg-default-clear"
  }), _vm._v(" "), _c('span', {
    staticClass: "color bg-default-light"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('span', {
    staticClass: "split"
  }, [_c('span', {
    staticClass: "color bg-mint"
  }), _vm._v(" "), _c('span', {
    staticClass: "color bg-mint-light"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('span', {
    staticClass: "split"
  }, [_c('span', {
    staticClass: "color bg-grape"
  }), _vm._v(" "), _c('span', {
    staticClass: "color bg-grape-light"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('span', {
    staticClass: "split"
  }, [_c('span', {
    staticClass: "color bg-lavender"
  }), _vm._v(" "), _c('span', {
    staticClass: "color bg-lavender-light"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('span', {
    staticClass: "split"
  }, [_c('span', {
    staticClass: "color bg-pink"
  }), _vm._v(" "), _c('span', {
    staticClass: "color bg-pink-light"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('span', {
    staticClass: "split"
  }, [_c('span', {
    staticClass: "color bg-sunflower"
  }), _vm._v(" "), _c('span', {
    staticClass: "color bg-sunflower-light"
  })])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('h5', {
    staticClass: "rightsidebar-right-heading text-uppercase gen-sett-m-t text-xs"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-settings"
  }), _vm._v("\n                                        General\n                                    ")])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('ul', {
    staticClass: "list-unstyled settings-list m-t-10"
  }, [_c('li', [_c('label', {
    attrs: {
      "for": "status"
    }
  }, [_vm._v("Available")]), _vm._v(" "), _c('span', {
    staticClass: "pull-right"
  }, [_c('input', {
    attrs: {
      "type": "checkbox",
      "id": "status",
      "name": "my-checkbox",
      "checked": ""
    }
  })])]), _vm._v(" "), _c('li', [_c('label', {
    attrs: {
      "for": "email-auth"
    }
  }, [_vm._v("Login with Email")]), _vm._v(" "), _c('span', {
    staticClass: "pull-right"
  }, [_c('input', {
    attrs: {
      "type": "checkbox",
      "id": "email-auth",
      "name": "my-checkbox"
    }
  })])]), _vm._v(" "), _c('li', [_c('label', {
    attrs: {
      "for": "update"
    }
  }, [_vm._v("Auto Update")]), _vm._v(" "), _c('span', {
    staticClass: "pull-right"
  }, [_c('input', {
    attrs: {
      "type": "checkbox",
      "id": "update",
      "name": "my-checkbox"
    }
  })])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('h5', {
    staticClass: "rightsidebar-right-heading text-uppercase text-xs"
  }, [_c('i', {
    staticClass: "fa fa-fw ti-volume"
  }), _vm._v("\n                                        Sound & Notification\n                                    ")])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('ul', {
    staticClass: "list-unstyled settings-list m-t-10"
  }, [_c('li', [_c('label', {
    attrs: {
      "for": "chat-sound"
    }
  }, [_vm._v("Chat Sound")]), _vm._v(" "), _c('span', {
    staticClass: "pull-right"
  }, [_c('input', {
    attrs: {
      "type": "checkbox",
      "id": "chat-sound",
      "name": "my-checkbox",
      "checked": ""
    }
  })])]), _vm._v(" "), _c('li', [_c('label', {
    attrs: {
      "for": "noti-sound"
    }
  }, [_vm._v("Notification Sound")]), _vm._v(" "), _c('span', {
    staticClass: "pull-right"
  }, [_c('input', {
    attrs: {
      "type": "checkbox",
      "id": "noti-sound",
      "name": "my-checkbox"
    }
  })])]), _vm._v(" "), _c('li', [_c('label', {
    attrs: {
      "for": "remain"
    }
  }, [_vm._v("Remainder ")]), _vm._v(" "), _c('span', {
    staticClass: "pull-right"
  }, [_c('input', {
    attrs: {
      "type": "checkbox",
      "id": "remain",
      "name": "my-checkbox",
      "checked": ""
    }
  })])]), _vm._v(" "), _c('li', [_c('label', {
    attrs: {
      "for": "vol"
    }
  }, [_vm._v("Volume")]), _vm._v(" "), _c('input', {
    attrs: {
      "type": "range",
      "id": "vol",
      "min": "0",
      "max": "100",
      "value": "15"
    }
  })])])
}]}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-2ba40cdb", module.exports)
  }
}

/***/ }),

/***/ 839:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('header', {
    staticClass: "header"
  }, [_c('nav', {
    staticClass: "navbar navbar-fixed-top",
    attrs: {
      "role": "navigation"
    }
  }, [_c('router-link', {
    staticClass: "logo",
    attrs: {
      "to": "/"
    }
  }, [_c('img', {
    attrs: {
      "src": __webpack_require__(320),
      "alt": "logo"
    }
  })]), _vm._v(" "), _c('div', [_c('a', {
    staticClass: "navbar-btn sidebar-toggle",
    attrs: {
      "href": "javascript:void(0)",
      "data-toggle": "offcanvas",
      "role": "button"
    },
    on: {
      "click": _vm.toggle_left
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-menu"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "navbar-right"
  }, [_c('ul', {
    staticClass: "nav navbar-nav"
  }, [_vm._m(0), _vm._v(" "), _c('li', [_c('a', {
    staticClass: "toggle-right",
    attrs: {
      "href": "javascript:void(0)"
    },
    on: {
      "click": _vm.toggle_right
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-view-list black"
  }), _vm._v(" "), _c('span', {
    staticClass: "label label-danger"
  }, [_vm._v("9")])])]), _vm._v(" "), _c('li', {
    staticClass: "dropdown user user-menu"
  }, [_c('a', {
    staticClass: "dropdown-toggle padding-user",
    attrs: {
      "href": "#",
      "data-toggle": "dropdown"
    }
  }, [_c('img', {
    staticClass: "img-circle img-responsive pull-left",
    attrs: {
      "src": this.$store.state.user.picture,
      "width": "35",
      "height": "35",
      "alt": "User Image"
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "riot"
  }, [_c('div', [_c('span', {
    staticClass: "user_name_max"
  }, [_vm._v(_vm._s(this.$store.state.user.name))]), _vm._v(" "), _vm._m(1)])])]), _vm._v(" "), _c('ul', {
    staticClass: "dropdown-menu"
  }, [_c('li', {
    staticClass: "user-header"
  }, [_c('img', {
    staticClass: "img-circle",
    attrs: {
      "src": this.$store.state.user.picture,
      "alt": "User Image"
    }
  }), _vm._v(" "), _c('p', {
    staticClass: "user_name_max",
    domProps: {
      "textContent": _vm._s(this.$store.state.user.name)
    }
  })]), _vm._v(" "), _c('li', {
    staticClass: "p-t-3"
  }, [_c('router-link', {
    attrs: {
      "to": "/user_profile",
      "exact": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-user"
  }), _vm._v(" My Profile\n                            ")])], 1), _vm._v(" "), _c('li', {
    attrs: {
      "role": "presentation"
    }
  }), _vm._v(" "), _c('li', [_c('router-link', {
    attrs: {
      "to": "/edit_user",
      "exact": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-settings"
  }), _vm._v(" Account Settings\n                            ")])], 1), _vm._v(" "), _c('li', {
    staticClass: "divider",
    attrs: {
      "role": "presentation"
    }
  }), _vm._v(" "), _c('li', {
    staticClass: "user-footer"
  }, [_c('div', {
    staticClass: "pull-left"
  }, [_c('router-link', {
    attrs: {
      "to": "/lockscreen",
      "exact": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-lock"
  }), _vm._v(" Lock\n                                ")])], 1), _vm._v(" "), _c('div', {
    staticClass: "pull-right"
  }, [_c('router-link', {
    attrs: {
      "to": "/login",
      "exact": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-shift-right"
  }), _vm._v(" Logout\n                                ")])], 1)])])])])])], 1)])
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('li', {
    staticClass: "dropdown messages-menu"
  }, [_c('a', {
    staticClass: "dropdown-toggle",
    attrs: {
      "href": "#",
      "data-toggle": "dropdown"
    }
  }, [_c('i', {
    staticClass: "fa fa-fw ti-email black"
  }), _vm._v(" "), _c('span', {
    staticClass: "label label-success"
  }, [_vm._v("2")])]), _vm._v(" "), _c('ul', {
    staticClass: "dropdown-menu dropdown-messages table-striped"
  }, [_c('li', {
    staticClass: "dropdown-title"
  }, [_vm._v("New Messages")]), _vm._v(" "), _c('li', [_c('a', {
    staticClass: "message striped-col",
    attrs: {
      "href": ""
    }
  }, [_c('img', {
    staticClass: "message-image img-circle",
    attrs: {
      "src": __webpack_require__(260),
      "alt": "avatar-image"
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "message-body"
  }, [_c('strong', [_vm._v("Ernest Kerry")]), _vm._v(" "), _c('br'), _vm._v(" Can we Meet?\n                                    "), _c('br'), _vm._v(" "), _c('small', [_vm._v("Just Now")]), _vm._v(" "), _c('span', {
    staticClass: "label label-success label-mini msg-lable"
  }, [_vm._v("New")])])])]), _vm._v(" "), _c('li', [_c('a', {
    staticClass: "message",
    attrs: {
      "href": ""
    }
  }, [_c('img', {
    staticClass: "message-image img-circle",
    attrs: {
      "src": __webpack_require__(267),
      "alt": "avatar-image"
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "message-body"
  }, [_c('strong', [_vm._v("John")]), _vm._v(" "), _c('br'), _vm._v(" Dont forgot to call...\n                                    "), _c('br'), _vm._v(" "), _c('small', [_vm._v("5 minutes ago")]), _vm._v(" "), _c('span', {
    staticClass: "label label-success label-mini msg-lable"
  }, [_vm._v("New")])])])]), _vm._v(" "), _c('li', [_c('a', {
    staticClass: "message striped-col",
    attrs: {
      "href": ""
    }
  }, [_c('img', {
    staticClass: "message-image img-circle",
    attrs: {
      "src": __webpack_require__(259),
      "alt": "avatar-image"
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "message-body"
  }, [_c('strong', [_vm._v("Wilton Zeph")]), _vm._v(" "), _c('br'), _vm._v(" If there is anything else …\n                                    "), _c('br'), _vm._v(" "), _c('small', [_vm._v("14/10/2014 1:31 pm")])])])]), _vm._v(" "), _c('li', [_c('a', {
    staticClass: "message",
    attrs: {
      "href": ""
    }
  }, [_c('img', {
    staticClass: "message-image img-circle",
    attrs: {
      "src": __webpack_require__(9),
      "alt": "avatar-image"
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "message-body"
  }, [_c('strong', [_vm._v("Jenny Kerry")]), _vm._v(" "), _c('br'), _vm._v(" Let me know when you free\n                                    "), _c('br'), _vm._v(" "), _c('small', [_vm._v("5 days ago")])])])]), _vm._v(" "), _c('li', [_c('a', {
    staticClass: "message striped-col",
    attrs: {
      "href": ""
    }
  }, [_c('img', {
    staticClass: "message-image img-circle",
    attrs: {
      "src": __webpack_require__(242),
      "alt": "avatar-image"
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "message-body"
  }, [_c('strong', [_vm._v("Tony")]), _vm._v(" "), _c('br'), _vm._v(" Let me know when you free\n                                    "), _c('br'), _vm._v(" "), _c('small', [_vm._v("5 days ago")])])])]), _vm._v(" "), _c('li', {
    staticClass: "dropdown-footer"
  }, [_c('a', {
    attrs: {
      "href": "#"
    }
  }, [_vm._v("View All messages")])])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('span', [_c('i', {
    staticClass: "caret"
  })])
}]}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-f4df8e1c", module.exports)
  }
}

/***/ }),

/***/ 877:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(524);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("5f7c719e", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-27913e91\",\"scoped\":false,\"hasInlineConfig\":true}!../../node_modules/sass-loader/lib/loader.js?indentedSyntax!../../node_modules/vue-loader/lib/selector.js?type=styles&index=1!./layout.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-27913e91\",\"scoped\":false,\"hasInlineConfig\":true}!../../node_modules/sass-loader/lib/loader.js?indentedSyntax!../../node_modules/vue-loader/lib/selector.js?type=styles&index=1!./layout.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 878:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(525);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("d70cb5be", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../../node_modules/css-loader/index.js!../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-27913e91\",\"scoped\":false,\"hasInlineConfig\":true}!./metisMenu.css", function() {
     var newContent = require("!!../../../../../node_modules/css-loader/index.js!../../../../../node_modules/vue-loader/lib/style-compiler/index.js?{\"id\":\"data-v-27913e91\",\"scoped\":false,\"hasInlineConfig\":true}!./metisMenu.css");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ })

});