<template>
    <div>
    </div>
</template>
<script>
export default {
    name: "blank",
    mounted: function() {

    },
    destroyed: function() {

    }
}
</script>
