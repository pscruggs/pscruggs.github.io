<template>
    <div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                                <i class="ti-image"></i> Image Filters (Aden - Hudson)
                            </h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12 col-xs-12">
                                <div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2 col-xs-12 text-center">
                                    <figure id="imgfigure1">
                                        <input type="file" class=" dropify" id="filter-1" data-show-remove="false" data-max-file-size="3M" data-allowed-file-extensions="jpg png tif gif" data-default-file="static/img/gallery/full/16.jpg" />
                                    </figure>
                                </div>
                                <div class="col-md-12 col-xs-12 text-center">
                                    <ul class="pagination">
                                        <li data-filter1="aden">
                                            <figure class="aden text-center">
                                                <img class="temp_path1" src="static/img/gallery/full/16.jpg" height="75" alt="aden image">
                                                <span>Aden</span>
                                            </figure>
                                        </li>
                                        <li data-filter1="brannan">
                                            <figure class="brannan text-center">
                                                <img class="temp_path1" src="static/img/gallery/full/16.jpg" height="75" alt="brannan image">
                                                <span>Brannan</span>
                                            </figure>
                                        </li>
                                        <li data-filter1="brooklyn">
                                            <figure class="brooklyn text-center">
                                                <img class="temp_path1" src="static/img/gallery/full/16.jpg" height="75" alt="brooklyn image">
                                                <span>Brooklyn</span>
                                            </figure>
                                        </li>
                                        <li data-filter1="clarendon">
                                            <figure class="clarendon text-center">
                                                <img class="temp_path1" src="static/img/gallery/full/16.jpg" height="75" alt="clarendon image">
                                                <span>Clarendon</span>
                                            </figure>
                                        </li>
                                        <li data-filter1="earlybird">
                                            <figure class="earlybird text-center">
                                                <img class="temp_path1" src="static/img/gallery/full/16.jpg" height="75" alt="earlybird image">
                                                <span class="font-ccc">Earlybird</span>
                                            </figure>
                                        </li>
                                        <li data-filter1="gingham">
                                            <figure class="gingham text-center">
                                                <img class="temp_path1" src="static/img/gallery/full/16.jpg" height="75" alt="gingham image">
                                                <span>Gingham</span>
                                            </figure>
                                        </li>
                                        <li data-filter1="hudson">
                                            <figure class="hudson text-center">
                                                <img class="temp_path1" src="static/img/gallery/full/16.jpg" height="75" alt="hudson image">
                                                <span>Hudson</span>
                                            </figure>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                                <i class="ti-image"></i> Image Filters (Inkwell - Perpetua)
                            </h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12 col-xs-12">
                                <div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2 col-xs-12 text-center">
                                    <figure id="imgfigure2">
                                        <input type="file" class=" dropify" id="filter-2" data-allowed-file-extensions="jpg png tif gif" data-max-file-size="3M" data-default-file="static/img/gallery/full/15.jpg" data-show-remove="false" />
                                    </figure>
                                </div>
                                <div class="col-md-12 col-xs-12 text-center">
                                    <ul class="pagination">
                                        <li data-filter2="inkwell">
                                            <figure class="inkwell text-center">
                                                <img class="temp_path2" src="static/img/gallery/full/15.jpg" height="75" alt="inkwell image">
                                                <span>Inkwell</span>
                                            </figure>
                                        </li>
                                        <li data-filter2="lark">
                                            <figure class="lark text-center">
                                                <img class="temp_path2" src="static/img/gallery/full/15.jpg" height="75" alt="lark image">
                                                <span class="font-ccc">Lark</span>
                                            </figure>
                                        </li>
                                        <li data-filter2="lofi">
                                            <figure class="lofi text-center">
                                                <img class="temp_path2" src="static/img/gallery/full/15.jpg" height="75" alt="lofi image">
                                                <span>Lofi</span>
                                            </figure>
                                        </li>
                                        <li data-filter2="mayfair">
                                            <figure class="mayfair text-center">
                                                <img class="temp_path2" src="static/img/gallery/full/15.jpg" height="75" alt="mayfair image">
                                                <span>Mayfair</span>
                                            </figure>
                                        </li>
                                        <li data-filter2="moon">
                                            <figure class="moon text-center">
                                                <img class="temp_path2" src="static/img/gallery/full/15.jpg" height="75" alt="moon image">
                                                <span>Moon</span>
                                            </figure>
                                        </li>
                                        <li data-filter2="nashville">
                                            <figure class="nashville text-center">
                                                <img class="temp_path2" src="static/img/gallery/full/15.jpg" height="75" alt="nashville image">
                                                <span>Nashville</span>
                                            </figure>
                                        </li>
                                        <li data-filter2="perpetua">
                                            <figure class="perpetua text-center">
                                                <img class="temp_path2" src="static/img/gallery/full/15.jpg" height="75" alt="perpetua image">
                                                <span>Perpetua</span>
                                            </figure>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                                <i class="ti-image"></i> Image Filters (Rise - Xpro2)
                            </h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12 col-xs-12">
                                <div class="col-lg-6 col-lg-offset-3 col-md-8 col-md-offset-2 col-xs-12 text-center">
                                    <figure id="imgfigure3">
                                        <input type="file" class=" dropify" id="filter-3" data-allowed-file-extensions="jpg png tif gif" data-max-file-size="3M" data-default-file="static/img/gallery/full/5.jpg" data-show-remove="false" />
                                    </figure>
                                </div>
                                <div class="col-md-12 col-xs-12 text-center">
                                    <ul class="pagination">
                                        <li data-filter3="rise">
                                            <figure class="rise text-center">
                                                <img class="temp_path3" src="static/img/gallery/full/5.jpg" height="75" alt="rise image">
                                                <span>Rise</span>
                                            </figure>
                                        </li>
                                        <li data-filter3="slumber">
                                            <figure class="slumber text-center">
                                                <img class="temp_path3" src="static/img/gallery/full/5.jpg" height="75" alt="slumber image">
                                                <span>Slumber</span>
                                            </figure>
                                        </li>
                                        <li data-filter3="toaster">
                                            <figure class="toaster text-center">
                                                <img class="temp_path3" src="static/img/gallery/full/5.jpg" height="75" alt="toaster image">
                                                <span class="font-ccc">Toaster</span>
                                            </figure>
                                        </li>
                                        <li data-filter3="valencia">
                                            <figure class="valencia text-center">
                                                <img class="temp_path3" src="static/img/gallery/full/5.jpg" height="75" alt="valencia image">
                                                <span>Valencia</span>
                                            </figure>
                                        </li>
                                        <li data-filter3="walden">
                                            <figure class="walden text-center">
                                                <img class="temp_path3" src="static/img/gallery/full/5.jpg" height="75" alt="walden image">
                                                <span>Walden</span>
                                            </figure>
                                        </li>
                                        <li data-filter3="willow">
                                            <figure class="willow text-center">
                                                <img class="temp_path3" src="static/img/gallery/full/5.jpg" height="75" alt="willow image">
                                                <span>Willow</span>
                                            </figure>
                                        </li>
                                        <li data-filter3="xpro2">
                                            <figure class="xpro2 text-center">
                                                <img class="temp_path3" src="static/img/gallery/full/5.jpg" height="75" alt="xpro2 image">
                                                <span>Xpro2</span>
                                            </figure>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import dropify from "../vendors/dropify/dist/js/dropify.min.js"
export default {
    name: "image_filter",
    mounted: function() {
        "use strict";
        $(document).ready(function() {

            $("[data-filter1]").on('click', function() {
                $("[data-filter1]").removeClass('active_filter');
                $(this).addClass('active_filter');
                $("#imgfigure1").removeClass().addClass($(this).attr('data-filter1'));
            });

            $("[data-filter2]").on('click', function() {
                $("[data-filter2]").removeClass('active_filter');
                $(this).addClass('active_filter');
                $("#imgfigure2").removeClass().addClass($(this).attr('data-filter2'));
            });

            $("[data-filter3]").on('click', function() {
                $("[data-filter3]").removeClass('active_filter');
                $(this).addClass('active_filter');
                $("#imgfigure3").removeClass().addClass($(this).attr('data-filter3'));
            });

            // $('.dropify').dropify();
            $("[data-max-file-size]").dropify({
                error: {
                    'fileSize': 'The file size is too big ({{ value }}B max).'
                }
            });

            //        dynamic img change of all filters on uploading image

            $('#filter-1').on('change', function() {
                var tmppath = URL.createObjectURL(event.target.files[0]);
                $('.temp_path1').attr('src', tmppath);
            });
            $('#filter-2').on('change', function() {
                var tmppath = URL.createObjectURL(event.target.files[0]);
                $('.temp_path2').attr('src', tmppath);
            });
            $('#filter-3').on('change', function() {
                var tmppath = URL.createObjectURL(event.target.files[0]);
                $('.temp_path3').attr('src', tmppath);
            });

        });
    },
    destroyed: function() {

    }
}
</script>
<style src="../vendors/dropify/dist/css/dropify.min.css"></style>
<style src="../vendors/cssgram/source/css/cssgram.min.css"></style>
<style src="../assets/css/custom_css/dropify.css"></style>
<style src="../assets/css/custom_css/image_filters.css"></style>
