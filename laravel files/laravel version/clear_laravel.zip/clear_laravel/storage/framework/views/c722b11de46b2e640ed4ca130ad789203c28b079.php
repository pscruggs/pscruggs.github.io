  <?php $__env->startSection('title'); ?> Draggable Portlets <?php $__env->stopSection(); ?>  <?php $__env->startSection('header_styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/portlet.css')); ?>" /> <?php $__env->stopSection(); ?>  <?php $__env->startSection('page-header'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>Draggable Portlets</h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('index')); ?>">
                <i class="fa fa-fw fa-home"></i> Dashboard
            </a>
        </li>
        <li> Pages</li>
        <li class="active">
            Draggable Portlets
        </li>
    </ol>
</section>
<?php $__env->stopSection(); ?>  <?php $__env->startSection('content'); ?>
<div class="row ui-sortable" id="sortable_portlets">
    <div class="col-md-4 sortable">
        <!-- BEGIN Portlet PORTLET-->
        <div class=" portlet box">
            <div class="portlet-title bg-primary">
                <div class="caption">
                    <i class="ti-menu"></i> Portlet
                </div>
            </div>
            <div class="portlet-body">
                <div>
                    <p>Tom loves Canada. Angela and Tom met. Angela and Tom want to play. Angela and Tom want to jump. Angela and Tom want to yell. Angela and Tom play, jump and yell.
                    </p>
                </div>
            </div>
        </div>
        <!-- END Portlet PORTLET-->
        <!-- BEGIN Portlet PORTLET-->
        <div class=" portlet box">
            <div class="portlet-title bg-success">
                <div class="caption">
                    <i class="ti-menu"></i> Portlet
                </div>
            </div>
            <div class="portlet-body">
                <div>
                    <p>Tom loves Canada. Angela and Tom met. Angela and Tom want to play. Angela and Tom want to jump. Angela and Tom want to yell. Angela and Tom play, jump and yell.
                    </p>
                </div>
            </div>
        </div>
        <!-- END Portlet PORTLET-->
        <!-- BEGIN Portlet PORTLET-->
        <div class=" portlet box">
            <div class="portlet-title bg-info">
                <div class="caption">
                    <i class="ti-menu"></i> Portlet
                </div>
            </div>
            <div class="portlet-body">
                <div>
                    <p>Tom loves Canada. Angela and Tom met. Angela and Tom want to play. Angela and Tom want to jump. Angela and Tom want to yell. Angela and Tom play, jump and yell.
                    </p>
                </div>
            </div>
        </div>
        <!-- END Portlet PORTLET-->
    </div>
    <div class="col-md-4 sortable">
        <!-- BEGIN Portlet PORTLET-->
        <div class=" portlet box">
            <div class="portlet-title bg-danger">
                <div class="caption">
                    <i class="ti-menu"></i> Portlet
                </div>
            </div>
            <div class="portlet-body">
                <div>
                    <p>Tom loves Canada. Angela and Tom met. Angela and Tom want to play. Angela and Tom want to jump. Angela and Tom want to yell. Angela and Tom play, jump and yell.
                    </p>
                </div>
            </div>
        </div>
        <!-- END Portlet PORTLET-->
        <!-- BEGIN Portlet PORTLET-->
        <div class=" portlet box">
            <div class="portlet-title bg-info">
                <div class="caption">
                    <i class="ti-menu"></i> Portlet
                </div>
            </div>
            <div class="portlet-body">
                <div>
                    <p>Tom loves Canada. Angela and Tom met. Angela and Tom want to play. Angela and Tom want to jump. Angela and Tom want to yell. Angela and Tom play, jump and yell.
                    </p>
                </div>
            </div>
        </div>
        <!-- END Portlet PORTLET-->
        <!-- BEGIN Portlet PORTLET-->
        <div class=" portlet box">
            <div class="portlet-title bg-warning">
                <div class="caption">
                    <i class="ti-menu"></i> Portlet
                </div>
            </div>
            <div class="portlet-body">
                <div>
                    <p>Tom loves Canada. Angela and Tom met. Angela and Tom want to play. Angela and Tom want to jump. Angela and Tom want to yell. Angela and Tom play, jump and yell.
                    </p>
                </div>
            </div>
        </div>
        <!-- END Portlet PORTLET-->
    </div>
    <div class="col-md-4 sortable">
        <!-- BEGIN Portlet PORTLET-->
        <div class=" portlet box">
            <div class="portlet-title bg-warning">
                <div class="caption">
                    <i class="ti-menu"></i> Portlet
                </div>
            </div>
            <div class="portlet-body">
                <div>
                    <p>Tom loves Canada. Angela and Tom met. Angela and Tom want to play. Angela and Tom want to jump. Angela and Tom want to yell. Angela and Tom play, jump and yell.
                    </p>
                </div>
            </div>
        </div>
        <!-- END Portlet PORTLET-->
        <!-- BEGIN Portlet PORTLET-->
        <div class=" portlet box">
            <div class="portlet-title bg-primary">
                <div class="caption">
                    <i class="ti-menu"></i> Portlet
                </div>
            </div>
            <div class="portlet-body">
                <div>
                    <p>Tom loves Canada. Angela and Tom met. Angela and Tom want to play. Angela and Tom want to jump. Angela and Tom want to yell. Angela and Tom play, jump and yell.
                    </p>
                </div>
            </div>
        </div>
        <!-- END Portlet PORTLET-->
        <!-- BEGIN Portlet PORTLET-->
        <div class=" portlet box notsort">
            <div class="portlet-title bg-danger">
                <div class="caption">
                    <i class="ti-alert"></i> Non Draggable Portlet
                </div>
            </div>
            <div class="portlet-body">
                <div>
                    <p>Tom loves Canada. Angela and Tom met. Angela and Tom want to play. Angela and Tom want to jump. Angela and Tom want to yell. Angela and Tom play, jump and yell.
                    </p>
                </div>
            </div>
        </div>
        <!-- END Portlet PORTLET-->
    </div>
</div> <?php $__env->stopSection(); ?>  <?php $__env->startSection('footer_scripts'); ?>
<script src="<?php echo e(asset('js/custom_js/draggable_portlets.jsjs/custom_js/draggable_portlets.js')); ?>" type="text/javascript"></script> <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>