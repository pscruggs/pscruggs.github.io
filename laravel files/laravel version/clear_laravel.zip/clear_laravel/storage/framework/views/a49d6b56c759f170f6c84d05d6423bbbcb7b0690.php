  <?php $__env->startSection('title'); ?> Horizontal Menu <?php $__env->stopSection(); ?>  <?php $__env->startSection('header_styles'); ?> <?php $__env->stopSection(); ?>  <?php $__env->startSection('page-header'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>Horizontal Menu</h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('index')); ?>">
                <i class="fa fa-fw fa-home"></i> Dashboard
            </a>
        </li>
        <li> Layouts</li>
        <li class="active">
            Horizontal Menu
        </li>
    </ol>
</section>
<?php $__env->stopSection(); ?>  <?php $__env->startSection('content'); ?> <?php $__env->stopSection(); ?>  <?php $__env->startSection('footer_scripts'); ?> <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/horizontal_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>