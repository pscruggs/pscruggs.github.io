  <?php $__env->startSection('title'); ?> Mini Sidebar <?php $__env->stopSection(); ?>  <?php $__env->startSection('header_styles'); ?>
<link rel="stylesheet" type="text/css" href="css/mini_sidebar.css"> <?php $__env->stopSection(); ?>  <?php $__env->startSection('page-header'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>Mini Sidebar</h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('index')); ?>">
                <i class="fa fa-fw fa-home"></i> Dashboard
            </a>
        </li>
        <li> Layouts</li>
        <li class="active">
            Mini Sidebar
        </li>
    </ol>
</section>
<?php $__env->stopSection(); ?>  <?php $__env->startSection('content'); ?> <?php $__env->stopSection(); ?>  <?php $__env->startSection('footer_scripts'); ?>
<script type="text/javascript" src="js/custom_js/mini_sidebar.js"></script> <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/mini_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>