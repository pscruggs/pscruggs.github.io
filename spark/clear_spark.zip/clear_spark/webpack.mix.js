let mix = require('laravel-mix');
var path = require('path');

/*
 |--------------------------------------------------------------------------
 | Mix Asset Management
 |--------------------------------------------------------------------------
 |
 | Mix provides a clean, fluent API for defining some Webpack build steps
 | for your Laravel application. By default, we are compiling the Sass
 | file for the application as well as bundling up all the JS files.
 |
 */


//source path configuration
var resourcesAssets = 'resources/assets/';
var vendors = resourcesAssets + 'vendors/';
var srcCss = resourcesAssets + 'css/';
var srcJs = resourcesAssets + 'js/';

//destination path configuration
var dest = 'public/';
var destFonts = dest + 'fonts/';
var destCss = dest + 'css/';
var destJs = dest + 'js/';
var destImg = dest + 'img/';
var destVendors = dest + 'vendors/';


// =====paths for vendors
var paths = {
    'select2': vendors + 'select2/dist/',
    'select2BootstrapTheme': vendors + 'select2-bootstrap-theme/dist/'
};

// ========copy images=====
mix.copy(resourcesAssets + 'img', 'public/img');

// ========copy fonts=====
mix.copy(resourcesAssets + 'fonts', 'public/fonts');

// ========copy css=====
mix.copy(resourcesAssets + 'css', "public/css");
// =====copy js===
mix.copy(resourcesAssets + 'js/pages', "public/js");

// ========sweetalert====
mix.copy('node_modules/sweetalert/dist/sweetalert.min.js', 'public/js/sweetalert.min.js');
mix.copy('node_modules/sweetalert/dist/sweetalert.css', 'public/css/sweetalert.css');

//select2
mix.copy(paths.select2 + 'css/select2.min.css', destVendors + 'select2/css');
mix.copy(paths.select2 + 'js/select2.js', destVendors + 'select2/js');
mix.copy(paths.select2BootstrapTheme + 'select2-bootstrap.css', destVendors + 'select2/css');

// ======



// =======mix styles======
// mix.sass('resources/assets/sass/bootstrap/bootstrap.scss', 'public/css');
mix.sass(resourcesAssets + 'sass/custom.scss', 'public/css');
mix.sass(resourcesAssets + 'sass/light_custom.scss', 'public/css');
mix.less(resourcesAssets + 'less/app.less', 'public/css');

// ===compile js
mix.js(resourcesAssets + 'js/app.js', 'public/js');

// ===webpackconfig override
mix.webpackConfig({
    resolve: {
        modules: [
            path.resolve(__dirname, 'vendor/laravel/spark/resources/assets/js'),
            'node_modules'
        ],
        alias: {
            'vue$': 'vue/dist/vue.js'
        }
    }
});
