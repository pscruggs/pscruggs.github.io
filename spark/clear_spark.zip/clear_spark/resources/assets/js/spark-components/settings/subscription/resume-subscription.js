var base = require('settings/subscription/resume-subscription');

Vue.component('spark-resume-subscription', {
    mixins: [base]
});
