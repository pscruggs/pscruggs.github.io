var base = require('navbar/navbar');

Vue.component('spark-navbar', {
    mixins: [base]
});
