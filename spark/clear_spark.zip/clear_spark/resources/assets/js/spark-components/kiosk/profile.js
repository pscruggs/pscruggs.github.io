var base = require('kiosk/profile');

Vue.component('spark-kiosk-profile', {
    mixins: [base]
});
