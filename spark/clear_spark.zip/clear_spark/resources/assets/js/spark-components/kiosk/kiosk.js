var base = require('kiosk/kiosk');

Vue.component('spark-kiosk', {
    mixins: [base]
});
